const _0x5e15e0 = _0xcf30;
(function (_0x93f39d, _0x4efbde) {
    const _0x569f9d = _0xcf30, _0x44c64a = _0x93f39d();
    while (!![]) {
        try {
            const _0x5b072b = -parseInt(_0x569f9d(0x1bd)) / (0x2 * 0xa34 + -0xda * -0xf + -0x212d) + parseInt(_0x569f9d(0x1ba)) / (-0x79f * -0x1 + 0x65 * 0x5f + -0x2d18) + parseInt(_0x569f9d(0x29e)) / (0x83a + -0x1a5 * 0x3 + 0x78 * -0x7) + parseInt(_0x569f9d(0x220)) / (0x5 * -0x121 + -0x215b + 0x2704) * (parseInt(_0x569f9d(0x292)) / (0x1bd6 * -0x1 + 0x1 * -0x1b81 + -0x1bae * -0x2)) + -parseInt(_0x569f9d(0x1b8)) / (0x280 + 0x235a + -0x25d4) + parseInt(_0x569f9d(0x255)) / (-0x20b1 + -0x175 + 0x222d) + -parseInt(_0x569f9d(0x1ce)) / (0x1a99 + 0x7f0 + -0x2281) * (parseInt(_0x569f9d(0x17a)) / (0x2663 + -0x1ac7 * 0x1 + -0xb93));
            if (_0x5b072b === _0x4efbde)
                break;
            else
                _0x44c64a['push'](_0x44c64a['shift']());
        } catch (_0xef6de) {
            _0x44c64a['push'](_0x44c64a['shift']());
        }
    }
}(_0x3fba, 0x19 * -0x682b + 0x5b9a7 + -0x2f * -0x6527));
const {
        default: makeWASocket,
        delay,
        DisconnectReason,
        BufferJSON,
        useMultiFileAuthState
    } = require(_0x5e15e0(0x181) + _0x5e15e0(0x161) + _0x5e15e0(0x20b)), {Boom} = require(_0x5e15e0(0x1f4)), P = require(_0x5e15e0(0x2a5)), {exec} = require(_0x5e15e0(0x265) + _0x5e15e0(0x17e)), express = require(_0x5e15e0(0x264)), {gerar} = require(_0x5e15e0(0x228) + _0x5e15e0(0x1f9) + _0x5e15e0(0x1e2)), app = express(), moment = require(_0x5e15e0(0x222) + _0x5e15e0(0x24a)), fs = require(_0x5e15e0(0x201)), ms = require('ms'), pms = require(_0x5e15e0(0x256)), {config} = require(_0x5e15e0(0x28a) + 'ig');
function _0xcf30(_0x19e6dc, _0x212a3c) {
    const _0x2f1483 = _0x3fba();
    return _0xcf30 = function (_0x1175d0, _0x5c8d1b) {
        _0x1175d0 = _0x1175d0 - (-0x10 * -0x2 + 0x2689 * -0x1 + -0xd39 * -0x3);
        let _0xfd692c = _0x2f1483[_0x1175d0];
        return _0xfd692c;
    }, _0xcf30(_0x19e6dc, _0x212a3c);
}
function _0x3fba() {
    const _0x217a1f = [
        'uto.\x0a\x0a_Qrc',
        '@hapi/boom',
        '*☎️Suporte*',
        'kPinY',
        'ync',
        'vegador...',
        'bot/src/ge',
        '\x20obter\x20o\x20a',
        'sar\x20é\x20só\x20m',
        'xtMessage',
        'IWXvI',
        'MPduj',
        'key',
        '*•Informaç',
        'fs-extra',
        '\x20o\x20comando',
        'RrkhJ',
        'steja\x20clic',
        'xGuVm',
        '####',
        '\x0a⌛Expira\x20e',
        'às\x20*',
        'nomeLoja',
        'pp\x20através',
        'eys',
        'midia',
        'COM\x20SUCESS',
        'te\x20👤',
        '\x20abaixo\x20⤵️\x0a',
        'DD/MM/yyyy',
        'cnvMR',
        'ó\x20poderá\x20g',
        'add',
        'Oeypg',
        'IxVPZ',
        'chada\x20por:',
        '04]*\x20Aplic',
        'ões\x20do\x20log',
        '\x20dias',
        'r\x20outro\x20pe',
        'nOtmN',
        'XGTAq',
        'sREMN',
        '/user.sh\x20',
        'now',
        '40040CJjpMv',
        'indexOf',
        'moment-tim',
        'lia)_\x0a\x0a📌Se',
        'sendPresen',
        'nload\x20do\x20a',
        'hBXRn',
        'msgkey',
        '/etc/megah',
        '*Informaçõ',
        '\x0a*🔐Senha:*',
        'splice',
        'Conexão\x20fe',
        'venceu',
        'creds.upda',
        'log',
        '\x20em\x2024h',
        'app',
        'connection',
        'a\x20de\x201\x20min',
        'mite:*\x201\x0a*',
        'get',
        '/cancel',
        '*Qrcode\x20ex',
        'remoteJid',
        'json',
        'gahbot/src',
        '\x20no\x20privad',
        'bad\x20reques',
        '\x20para\x20faze',
        'RUDhe',
        'listen',
        'peRcW',
        'Conectando',
        'bem\x20seu\x20te',
        '\x0a\x0a########',
        '\x20vontade\x20p',
        '\x0a/app\x0a\x0aDes',
        'r?\x20*Sim*\x20o',
        'ento\x20for\x20i',
        'deu\x20erro',
        '*\x20login\x27s\x20',
        'ezone',
        '/teste.sh\x20',
        'RbiEk',
        'uário:*\x20',
        'eja\x20compra',
        'ZDZQD',
        '):\x0a\x0aMensag',
        'logins',
        'e:*\x20',
        'duto•*\x0a\x0a*🏷️',
        'o,\x20pague\x20o',
        '2441579WdnPgc',
        'parse-ms',
        'e\x20ficará',
        'sendMessag',
        'Premium',
        'o:*\x20',
        'Abrindo\x20na',
        'sh\x20/etc/me',
        'user',
        'Aproveite\x20',
        'm:\x2010\x20min\x0a',
        'o_Paulo',
        'o,\x20pode\x20de',
        '\x0a*[02]*\x20Co',
        'ZVOgz',
        'express',
        'child_proc',
        'n\x2030\x20dias\x20',
        '!*\x20Fique\x20a',
        'zovcT',
        'Você\x20não\x20t',
        'jtDKp',
        'xAOPf',
        'mDYYS',
        'dade:*\x2030\x20',
        'estes.json',
        'bot/data/p',
        'ando...',
        '*[01]*\x20Ger',
        'participan',
        'pzYuX',
        'gGTQP',
        'length',
        'text',
        'bbvGv',
        'u\x20login\x20se',
        'senha',
        'dono',
        'EvGKM',
        'MRkTQ',
        'o\x20de\x20',
        'Pagamento\x20',
        '\x20confirmad',
        'baixo⤵️\x0a\x0a',
        'erificar\x20L',
        'teste',
        'iLUlo',
        'de:*\x0a\x0a🆔Id:',
        'u\x20espere\x20e',
        'tKwGp',
        'available',
        'messages.u',
        '🆔Id:\x20',
        '/root/conf',
        'm\x20pedido\x20e',
        'yCCXY',
        'Olá\x20',
        'UVYcM',
        '...',
        'pushName',
        'JeZtU',
        '515oyGPaq',
        '========',
        'BADEo',
        'er\x20alguma\x20',
        'toLowerCas',
        'Faça\x20o\x20dow',
        'VoonT',
        'error',
        'iKlCQ',
        'MoLGy',
        'aQXRa',
        'es\x20do\x20Qrco',
        '4806576xWIXhf',
        'Você\x20tem\x20*',
        'rá\x20enviado',
        'Validade',
        'GGgCn',
        'valor',
        'ogins\x20🔍\x0a*[',
        'pino',
        'stringify',
        'ScmBY',
        'agos.json',
        '/app',
        'NoSfq',
        'm\x20andament',
        '5|1|2',
        'VDTxX',
        'pp,\x20digite',
        'split',
        '\x0a\x0a🆔@',
        'push',
        'limite',
        'aFzNl',
        'nao',
        'vAHSh',
        '\x0a\x0a📌Caso\x20o\x20',
        'prar!\x0aPara',
        'hora',
        'não',
        '3|7|8|6',
        'in•*\x0a\x0a*👤Us',
        'ceUpdate',
        'pgLfz',
        '\x20seu\x20pagam',
        '\x20do\x20link\x20a',
        'ar\x20teste\x20⌛',
        'SCkre',
        '.update',
        '\x201234\x0a*📲Li',
        'bot/src/ve',
        'o\x20de\x20Brasí',
        'ckets/bail',
        'query',
        'ativo\x20📱\x0a*[',
        'aVnRS',
        'connecting',
        'dentificad',
        'ode\x20copia\x20',
        'expira',
        'tes\x20de\x20com',
        'ste\x20🔥',
        '\x0a\x0a*👤Usuári',
        'pirado:*\x0a\x0a',
        'o\x20abaixo_\x20',
        'ZybOD',
        'EjYeb',
        'psert',
        'e\x20chamar!\x20',
        'BalGn',
        'bot/login',
        'Você\x20tem\x20u',
        'IshOL',
        'PBsVV',
        'das\x20opções',
        '\x0a*📲Limite:',
        'tempo_test',
        '368532GKDTZH',
        'sim',
        'fromMe',
        'bot/data/t',
        'ess',
        'link\x20não\x20e',
        'floor',
        '@whiskeyso',
        'u\x20*Não*',
        'em\x20logins\x20',
        'mprar\x20logi',
        'e\x20meu\x20cont',
        'YfOYO',
        'zqJVC',
        'ara\x20escolh',
        '\x20(31\x20dias)',
        '⌛Validade:',
        'rou\x20um\x20tes',
        '4|2|1|5|0|',
        'includes',
        'dido',
        'pre\x20faça\x20u',
        'Valor:*\x20R$',
        'message',
        'messages',
        'open',
        'sBwPH',
        'close',
        'id:\x20',
        'ksQsb',
        'ndo(a)\x20a\x20*',
        '/pago',
        'hpGIp',
        '*\x20_(horári',
        'te\x20hoje,\x20s',
        'morar\x20cerc',
        'Aguarde...',
        'le\x20expirar',
        'valorLogin',
        'dias\x0a\x0a📌Sem',
        'slice',
        'aDsZz',
        '*\x201\x0a*⌛Vali',
        '@g.us',
        'em:\x20',
        'hdlqB',
        'erar\x20outro',
        'sucess',
        ')\x0a\x0a=======',
        'ável,\x20salv',
        'OxvJm',
        'DzhbI',
        '\x0a*⌛Validad',
        'XDyWt',
        'MFwWB',
        '\x20abaixo:\x0a\x0a',
        'conversati',
        'e\x20cola\x20log',
        'silent',
        'edidos.jso',
        'Tudo\x20certo',
        'lThRz',
        '8937492YbzpBz',
        'ões\x20do\x20pro',
        '3370030izENfQ',
        '05]*\x20Supor',
        'Gerando\x20Qr',
        '1473843xlnqAN',
        'p.net',
        'QLZWG',
        'dade:*\x20',
        'random',
        'America/Sa',
        ',\x20Reconect',
        'writeFileS',
        'Você\x20já\x20ge',
        'readMessag',
        'catch',
        'parse',
        'qrcode',
        'format',
        'XZWoH',
        'wVWtC',
        'CfToM',
        '152gyGNMx',
        '@s.whatsap',
        'WCBwj',
        'lBNkW',
        'HzChC',
        'days',
        'IFOoj',
        'extendedTe',
        '\x0a🏷️Valor:\x20R',
        '31d',
        'code...',
        'CONECTADO\x20',
        '\x20😃,\x20Bem\x20vi',
        '|3|7|11|0|',
        'fVXAa',
        '📆\x0a*[03]*\x20V',
        'itITm',
        '10|4|6|9|8',
        'flXZT',
        'CJWfk',
        'rar',
        'HFtaJ',
        'qUFxu',
        'ato\x20que\x20el',
        'wGOZL',
        'usuario',
        '!\x20Se\x20preci',
        'linkApp',
        'CfQIT',
        '\x20assim\x20que',
        'dMvrP',
        '\x0a\x0aMensagem',
        'nUfyC',
        'readFileSy',
        'm\x20teste\x20an',
        'dEGgH',
        'eZirt'
    ];
    _0x3fba = function () {
        return _0x217a1f;
    };
    return _0x3fba();
}
time = ms('1d'), expiraZ = ms(_0x5e15e0(0x1d7)), d31 = moment['tz'](_0x5e15e0(0x1c2) + _0x5e15e0(0x260))[_0x5e15e0(0x213)](-0xde9 + -0x387 + 0x118f, 'd')[_0x5e15e0(0x1ca)](_0x5e15e0(0x210)), app[_0x5e15e0(0x23f)](0x2d7 * 0x3 + -0x83 * 0x6a + 0x4911), dono = [config[_0x5e15e0(0x27a)] + (_0x5e15e0(0x1cf) + _0x5e15e0(0x1be))], dono2 = '' + config[_0x5e15e0(0x27a)], path = {
    'p': _0x5e15e0(0x228) + _0x5e15e0(0x26f) + _0x5e15e0(0x1b5) + 'n',
    't': _0x5e15e0(0x228) + _0x5e15e0(0x17d) + _0x5e15e0(0x26e),
    'pa': _0x5e15e0(0x228) + _0x5e15e0(0x26f) + _0x5e15e0(0x143)
};
async function checkUser(_0x18fa32) {
    const _0x4fa7e2 = _0x5e15e0, _0x5199a1 = {
            'QLZWG': function (_0x464ef8, _0x482728) {
                return _0x464ef8 < _0x482728;
            },
            'GGgCn': function (_0x2fd8f5, _0x311334) {
                return _0x2fd8f5 == _0x311334;
            }
        };
    pedidos = await JSON[_0x4fa7e2(0x1c8)](fs[_0x4fa7e2(0x1ef) + 'nc'](path['p']));
    for (var _0x517fe1 = 0x3a9 + 0x1b02 + -0x1eab; _0x5199a1[_0x4fa7e2(0x1bf)](_0x517fe1, pedidos[_0x4fa7e2(0x275)]); _0x517fe1++) {
        if (_0x5199a1[_0x4fa7e2(0x2a2)](pedidos[_0x517fe1][_0x4fa7e2(0x25d)], _0x18fa32))
            return !![];
    }
    return ![];
}
async function checkTeste(_0x4a7a01) {
    const _0x3fd28e = _0x5e15e0, _0x2a6033 = {
            'lThRz': function (_0x3bdf3c, _0x38f915) {
                return _0x3bdf3c < _0x38f915;
            },
            'hBXRn': function (_0x253000, _0x2af982) {
                return _0x253000 == _0x2af982;
            },
            'zovcT': function (_0x470897, _0x26b7c9) {
                return _0x470897 > _0x26b7c9;
            }
        };
    testes = await JSON[_0x3fd28e(0x1c8)](fs[_0x3fd28e(0x1ef) + 'nc'](path['t'])), testes = await JSON[_0x3fd28e(0x1c8)](fs[_0x3fd28e(0x1ef) + 'nc'](path['t']));
    for (var _0xfd9f20 = -0x1 * -0x1953 + 0xab1 + -0x2404; _0x2a6033[_0x3fd28e(0x1b7)](_0xfd9f20, testes[_0x3fd28e(0x275)]); _0xfd9f20++) {
        if (_0x2a6033[_0x3fd28e(0x226)](testes[_0xfd9f20][_0x3fd28e(0x25d)], _0x4a7a01)) {
            if (_0x2a6033[_0x3fd28e(0x1b7)](Date[_0x3fd28e(0x21f)](), testes[_0xfd9f20][_0x3fd28e(0x168)]))
                return !![];
            if (_0x2a6033[_0x3fd28e(0x268)](Date[_0x3fd28e(0x21f)](), testes[_0xfd9f20][_0x3fd28e(0x168)]))
                return testes[_0x3fd28e(0x22b)](_0xfd9f20, -0x1bde + -0x654 + 0x2233), await fs[_0x3fd28e(0x1c4) + _0x3fd28e(0x1f7)](path['t'], JSON[_0x3fd28e(0x2a6)](testes)), ![];
        }
    }
    return ![];
}
async function gravarTeste(_0x5b4d5d) {
    const _0x479709 = _0x5e15e0, _0x4e1c0d = {
            'jtDKp': function (_0x27914d, _0x18d22c) {
                return _0x27914d + _0x18d22c;
            }
        };
    testes = await JSON[_0x479709(0x1c8)](fs[_0x479709(0x1ef) + 'nc'](path['t'])), obj = {
        'user': _0x5b4d5d,
        'expira': _0x4e1c0d[_0x479709(0x26a)](Date[_0x479709(0x21f)](), time)
    }, testes[_0x479709(0x14c)](obj), await fs[_0x479709(0x1c4) + _0x479709(0x1f7)](path['t'], JSON[_0x479709(0x2a6)](testes));
}
function ale() {
    const _0x6c1a54 = _0x5e15e0, _0x3ab40d = {
            'XGTAq': function (_0x41cf97, _0x1f03e6) {
                return _0x41cf97 * _0x1f03e6;
            },
            'vAHSh': function (_0x32d8ed, _0x47671f) {
                return _0x32d8ed + _0x47671f;
            }
        };
    return i = 0x8ac7230489e80000, Math[_0x6c1a54(0x180)](_0x3ab40d[_0x6c1a54(0x21c)](Math[_0x6c1a54(0x1c1)](), _0x3ab40d[_0x6c1a54(0x150)](i, -0x1 * -0x3d7 + -0x1a9 * -0x11 + -0x200f)));
}
function repla(_0xa0669a) {
    const _0x5c85e8 = _0x5e15e0;
    return i = _0xa0669a[_0x5c85e8(0x221)]('@'), _0xa0669a[_0x5c85e8(0x1a2)](-0x21be + -0xb01 * -0x3 + 0xbb, i);
}
async function chackPago(_0x239b13) {
    const _0x28f8c6 = _0x5e15e0, _0x53ba9b = {
            'sBwPH': function (_0x2b6c95, _0x3fcf6c) {
                return _0x2b6c95 < _0x3fcf6c;
            },
            'MoLGy': function (_0x354d25, _0x29ac00) {
                return _0x354d25 == _0x29ac00;
            }
        };
    pagos = await JSON[_0x28f8c6(0x1c8)](fs[_0x28f8c6(0x1ef) + 'nc'](path['pa']));
    for (var _0x3e6b71 = -0x7dd + -0x1d8a + -0x19 * -0x17f; _0x53ba9b[_0x28f8c6(0x194)](_0x3e6b71, pagos[_0x28f8c6(0x275)]); _0x3e6b71++) {
        if (_0x53ba9b[_0x28f8c6(0x29b)](pagos[_0x3e6b71][_0x28f8c6(0x25d)], _0x239b13))
            return !![];
    }
    return ![];
}
async function checkLogins(_0x568fa8) {
    const _0x14a94d = _0x5e15e0, _0x3eaacb = {
            'sREMN': function (_0x2b8032, _0x48857c) {
                return _0x2b8032 < _0x48857c;
            },
            'ZybOD': function (_0x2455a0, _0x3daf3b) {
                return _0x2455a0 == _0x3daf3b;
            },
            'eZirt': _0x14a94d(0x18c) + _0x14a94d(0x155),
            'XDyWt': function (_0x33c541, _0x23f8a9) {
                return _0x33c541(_0x23f8a9);
            },
            'aQXRa': function (_0x37230c, _0x187b93) {
                return _0x37230c - _0x187b93;
            },
            'dMvrP': function (_0x1646ff, _0x5a3dac) {
                return _0x1646ff + _0x5a3dac;
            },
            'xAOPf': _0x14a94d(0x219),
            'BalGn': function (_0x55a2b6, _0xdb2e85) {
                return _0x55a2b6 > _0xdb2e85;
            },
            'ksQsb': _0x14a94d(0x22d),
            'hdlqB': _0x14a94d(0x269) + _0x14a94d(0x183) + _0x14a94d(0x259)
        };
    pagos = await JSON[_0x14a94d(0x1c8)](fs[_0x14a94d(0x1ef) + 'nc'](path['pa']));
    for (var _0x435aa1 = 0x842 + -0x16 * -0xe1 + -0x1b98; _0x3eaacb[_0x14a94d(0x21d)](_0x435aa1, pagos[_0x14a94d(0x275)]); _0x435aa1++) {
        if (_0x3eaacb[_0x14a94d(0x16e)](pagos[_0x435aa1][_0x14a94d(0x25d)], _0x568fa8)) {
            logins = pagos[_0x435aa1][_0x14a94d(0x251)], quanti = logins[_0x14a94d(0x275)], tesk = _0x14a94d(0x29f) + '0' + quanti + (_0x14a94d(0x249) + _0x14a94d(0x259));
            for (var _0x435aa1 = 0x1 * -0x25cf + 0x241 * 0x5 + 0x1a8a * 0x1; _0x3eaacb[_0x14a94d(0x21d)](_0x435aa1, logins[_0x14a94d(0x275)]); _0x435aa1++) {
                const _0x45d4df = _0x3eaacb[_0x14a94d(0x1f2)][_0x14a94d(0x14a)]('|');
                let _0x466d59 = -0x9f + -0x19ba + 0x1 * 0x1a59;
                while (!![]) {
                    switch (_0x45d4df[_0x466d59++]) {
                    case '0':
                        exp = _0x3eaacb[_0x14a94d(0x1af)](pms, _0x3eaacb[_0x14a94d(0x29c)](logins[_0x435aa1][_0x14a94d(0x168)], Date[_0x14a94d(0x21f)]()));
                        continue;
                    case '1':
                        limi = logins[_0x435aa1][_0x14a94d(0x14d)];
                        continue;
                    case '2':
                        sen = logins[_0x435aa1][_0x14a94d(0x279)];
                        continue;
                    case '3':
                        exp = _0x3eaacb[_0x14a94d(0x1ec)](exp[_0x14a94d(0x1d3)], _0x3eaacb[_0x14a94d(0x26b)]);
                        continue;
                    case '4':
                        usu = logins[_0x435aa1][_0x14a94d(0x1e7)];
                        continue;
                    case '5':
                        vali = logins[_0x435aa1][_0x14a94d(0x2a1)];
                        continue;
                    case '6':
                        tesk = _0x3eaacb[_0x14a94d(0x1ec)](tesk, _0x14a94d(0x16b) + _0x14a94d(0x25a) + usu + (_0x14a94d(0x22a) + '\x20') + sen + (_0x14a94d(0x178) + '*\x20') + limi + (_0x14a94d(0x1ae) + _0x14a94d(0x252)) + vali + '\x20(' + exp + (_0x14a94d(0x1aa) + _0x14a94d(0x293)));
                        continue;
                    case '7':
                        exps = logins[_0x435aa1][_0x14a94d(0x168)];
                        continue;
                    case '8':
                        if (_0x3eaacb[_0x14a94d(0x172)](Date[_0x14a94d(0x21f)](), exp))
                            exp = _0x3eaacb[_0x14a94d(0x197)];
                        continue;
                    }
                    break;
                }
            }
            return tesk;
        }
    }
    return _0x3eaacb[_0x14a94d(0x1a7)];
}
async function connectToWhatsApp() {
    const _0x22fbbf = _0x5e15e0, _0x5bfcb0 = {
            'flXZT': function (_0x12ad5c, _0x65c45d) {
                return _0x12ad5c == _0x65c45d;
            },
            'gGTQP': _0x22fbbf(0x165),
            'BADEo': _0x22fbbf(0x241) + _0x22fbbf(0x28f),
            'IWXvI': function (_0x102170, _0x3a65f8) {
                return _0x102170 === _0x3a65f8;
            },
            'iKlCQ': _0x22fbbf(0x195),
            'tKwGp': _0x22fbbf(0x22c) + _0x22fbbf(0x216) + '\x20',
            'IFOoj': _0x22fbbf(0x1c3) + _0x22fbbf(0x270),
            'nUfyC': function (_0xb02d1e, _0x2fc546) {
                return _0xb02d1e(_0x2fc546);
            },
            'CfQIT': function (_0x3f3b8a) {
                return _0x3f3b8a();
            },
            'itITm': function (_0x1057b6, _0x4e7174) {
                return _0x1057b6 === _0x4e7174;
            },
            'wVWtC': _0x22fbbf(0x193),
            'qUFxu': _0x22fbbf(0x1d9) + _0x22fbbf(0x20d) + 'O!',
            'cnvMR': function (_0x5e421b, _0x162f39) {
                return _0x5e421b(_0x162f39);
            },
            'IxVPZ': _0x22fbbf(0x228) + _0x22fbbf(0x15f) + 'ri',
            'MRkTQ': _0x22fbbf(0x248),
            'WCBwj': _0x22fbbf(0x299),
            'nOtmN': _0x22fbbf(0x1df) + _0x22fbbf(0x1db) + _0x22fbbf(0x147),
            'lBNkW': function (_0x579ca6, _0x237a23) {
                return _0x579ca6(_0x237a23);
            },
            'YfOYO': function (_0x1d0b9d, _0xbaec1d) {
                return _0x1d0b9d + _0xbaec1d;
            },
            'JeZtU': function (_0x1d843e, _0x10c2e1) {
                return _0x1d843e < _0x10c2e1;
            },
            'MFwWB': function (_0x1f4709, _0x553835) {
                return _0x1f4709 == _0x553835;
            },
            'HzChC': _0x22fbbf(0x1a9),
            'bbvGv': _0x22fbbf(0x25d),
            'zqJVC': function (_0x4c234c) {
                return _0x4c234c();
            },
            'NoSfq': function (_0x58b404, _0x1b401d) {
                return _0x58b404 + _0x1b401d;
            },
            'fVXAa': function (_0x5e3a61, _0x32a904) {
                return _0x5e3a61 + _0x32a904;
            },
            'ZDZQD': _0x22fbbf(0x27e) + _0x22fbbf(0x196),
            'ScmBY': _0x22fbbf(0x27f) + 'o!',
            'aDsZz': _0x22fbbf(0x23c) + 't',
            'EvGKM': function (_0x5e40de, _0x39602b) {
                return _0x5e40de + _0x39602b;
            },
            'kPinY': _0x22fbbf(0x237) + _0x22fbbf(0x16c) + _0x22fbbf(0x289),
            'iLUlo': _0x22fbbf(0x287),
            'PBsVV': _0x22fbbf(0x1a5),
            'EjYeb': _0x22fbbf(0x20c),
            'XZWoH': _0x22fbbf(0x1c5) + _0x22fbbf(0x18b) + _0x22fbbf(0x19c) + _0x22fbbf(0x212) + _0x22fbbf(0x1a8) + _0x22fbbf(0x230),
            'UVYcM': function (_0x40e8e0, _0x37df71) {
                return _0x40e8e0 + _0x37df71;
            },
            'xGuVm': _0x22fbbf(0x282),
            'RUDhe': function (_0x54562c) {
                return _0x54562c();
            },
            'HFtaJ': function (_0x59393a, _0x30aa13) {
                return _0x59393a * _0x30aa13;
            },
            'SCkre': _0x22fbbf(0x25e) + _0x22fbbf(0x242) + _0x22fbbf(0x16a),
            'aFzNl': _0x22fbbf(0x17b),
            'pgLfz': function (_0x48c232, _0x5e18cb) {
                return _0x48c232(_0x5e18cb);
            },
            'CJWfk': _0x22fbbf(0x174) + _0x22fbbf(0x28b) + _0x22fbbf(0x146) + _0x22fbbf(0x254) + _0x22fbbf(0x285) + _0x22fbbf(0x19f) + _0x22fbbf(0x23d) + _0x22fbbf(0x21a) + _0x22fbbf(0x18e),
            'MPduj': function (_0x41022f, _0x1b8cb4) {
                return _0x41022f(_0x1b8cb4);
            },
            'dEGgH': _0x22fbbf(0x1bc) + _0x22fbbf(0x1d8),
            'VDTxX': function (_0x19d862, _0xdf883f, _0x39c921) {
                return _0x19d862(_0xdf883f, _0x39c921);
            },
            'peRcW': _0x22fbbf(0x14f),
            'RrkhJ': _0x22fbbf(0x154),
            'pzYuX': _0x22fbbf(0x1b6) + _0x22fbbf(0x1e8) + _0x22fbbf(0x1fb) + _0x22fbbf(0x171) + '😉',
            'yCCXY': function (_0x52b6b9, _0x249b4a) {
                return _0x52b6b9(_0x249b4a);
            },
            'Oeypg': _0x22fbbf(0x144),
            'wGOZL': _0x22fbbf(0x231),
            'hpGIp': _0x22fbbf(0x19e),
            'VoonT': function (_0x2acccf, _0xa64368) {
                return _0x2acccf(_0xa64368);
            },
            'aVnRS': _0x22fbbf(0x228) + _0x22fbbf(0x173),
            'mDYYS': _0x22fbbf(0x1b4),
            'IshOL': _0x22fbbf(0x22e) + 'te',
            'CfToM': _0x22fbbf(0x232) + _0x22fbbf(0x15d),
            'ZVOgz': _0x22fbbf(0x25b) + _0x22fbbf(0x1f8),
            'DzhbI': _0x22fbbf(0x199),
            'OxvJm': _0x22fbbf(0x236),
            'RbiEk': _0x22fbbf(0x288) + _0x22fbbf(0x170)
        }, {
            state: _0xc9189c,
            saveCreds: _0x162d10
        } = await _0x5bfcb0[_0x22fbbf(0x298)](useMultiFileAuthState, _0x5bfcb0[_0x22fbbf(0x164)]), _0x1c744d = await _0x5bfcb0[_0x22fbbf(0x298)](makeWASocket, {
            'logger': _0x5bfcb0[_0x22fbbf(0x211)](P, { 'level': _0x5bfcb0[_0x22fbbf(0x26c)] }),
            'printQRInTerminal': !![],
            'auth': _0xc9189c,
            'keepAliveIntervalMs': 0x3e80
        });
    _0x1c744d['ev']['on'](_0x5bfcb0[_0x22fbbf(0x175)], _0x162d10), _0x1c744d['ev']['on'](_0x5bfcb0[_0x22fbbf(0x1cd)], async _0xeebe96 => {
        const _0x55bb33 = _0x22fbbf, {
                connection: _0x2472f0,
                lastDisconnect: _0x561db3
            } = _0xeebe96;
        _0x5bfcb0[_0x55bb33(0x1e0)](_0x2472f0, _0x5bfcb0[_0x55bb33(0x274)]) && console[_0x55bb33(0x22f)](_0x5bfcb0[_0x55bb33(0x294)]);
        if (_0x5bfcb0[_0x55bb33(0x1fd)](_0x2472f0, _0x5bfcb0[_0x55bb33(0x29a)]))
            console[_0x55bb33(0x22f)](DisconnectReason), console[_0x55bb33(0x22f)](_0x5bfcb0[_0x55bb33(0x286)], _0x561db3, _0x5bfcb0[_0x55bb33(0x1d4)]), await _0x5bfcb0[_0x55bb33(0x1ee)](delay, -0x2384 + -0x42f * -0x6 + -0x2 * -0xb11), _0x5bfcb0[_0x55bb33(0x1ea)](connectToWhatsApp);
        else {
            if (_0x5bfcb0[_0x55bb33(0x1de)](_0x2472f0, _0x5bfcb0[_0x55bb33(0x1cc)])) {
                console[_0x55bb33(0x22f)](_0x5bfcb0[_0x55bb33(0x1e4)]), await _0x5bfcb0[_0x55bb33(0x211)](delay, -0x1 * 0x26d7 + -0xe6 * -0x1a + 0x1 * 0x2303);
                const {checkStatus: _0x2cde08} = _0x5bfcb0[_0x55bb33(0x211)](require, _0x5bfcb0[_0x55bb33(0x215)]);
            }
        }
    }), console[_0x22fbbf(0x22f)](_0x5bfcb0[_0x22fbbf(0x263)]), app[_0x22fbbf(0x235)](_0x5bfcb0[_0x22fbbf(0x1ad)], async (_0x2a8d08, _0x1917de) => {
        const _0x16a24b = _0x22fbbf, _0x2dc88e = _0x5bfcb0[_0x16a24b(0x21b)][_0x16a24b(0x14a)]('|');
        let _0x110b1a = -0x183f + -0x39 + -0x828 * -0x3;
        while (!![]) {
            switch (_0x2dc88e[_0x110b1a++]) {
            case '0':
                await _0x1c744d[_0x16a24b(0x258) + 'e'](_0x36a3e0, { 'text': _0x16a24b(0x200) + _0x16a24b(0x218) + _0x16a24b(0x156) + _0x16a24b(0x24d) + usuarioV + (_0x16a24b(0x22a) + '\x20') + senha + (_0x16a24b(0x178) + _0x16a24b(0x1a4) + _0x16a24b(0x1c0)) + d31 + _0x16a24b(0x189) }, { 'quoted': pagtoC })[_0x16a24b(0x1c7)](_0x32015c => {
                    const _0x5a8863 = _0x16a24b;
                    console[_0x5a8863(0x22f)](_0x5bfcb0[_0x5a8863(0x27c)]), console[_0x5a8863(0x22f)](_0x32015c), _0x1917de[_0x5a8863(0x239)]({ 'msg': _0x5bfcb0[_0x5a8863(0x1d0)] });
                });
                continue;
            case '1':
                if (await _0x5bfcb0[_0x16a24b(0x1d1)](chackPago, _0x36a3e0)) {
                    pagos = await JSON[_0x16a24b(0x1c8)](fs[_0x16a24b(0x1ef) + 'nc'](path['pa'])), obj = {
                        'usuario': usuarioV,
                        'senha': senha,
                        'limite': 0x1,
                        'Validade': d31,
                        'expira': _0x5bfcb0[_0x16a24b(0x186)](Date[_0x16a24b(0x21f)](), expiraZ)
                    };
                    for (var _0x7121b6 = -0x6c4 * -0x1 + -0x5d1 * 0x2 + 0x4de; _0x5bfcb0[_0x16a24b(0x291)](_0x7121b6, pagos[_0x16a24b(0x275)]); _0x7121b6++) {
                        _0x5bfcb0[_0x16a24b(0x1b0)](pagos[_0x7121b6][_0x16a24b(0x25d)], _0x36a3e0) && (pagos[_0x7121b6][_0x16a24b(0x251)][_0x16a24b(0x14c)](obj), await fs[_0x16a24b(0x1c4) + _0x16a24b(0x1f7)](path['pa'], JSON[_0x16a24b(0x2a6)](pagos)));
                    }
                } else
                    pagos = await JSON[_0x16a24b(0x1c8)](fs[_0x16a24b(0x1ef) + 'nc'](path['pa'])), obj = {
                        'user': _0x36a3e0,
                        'logins': [{
                                'usuario': usuarioV,
                                'senha': senha,
                                'limite': 0x1,
                                'Validade': d31,
                                'expira': _0x5bfcb0[_0x16a24b(0x186)](Date[_0x16a24b(0x21f)](), expiraZ)
                            }]
                    }, pagos[_0x16a24b(0x14c)](obj), await fs[_0x16a24b(0x1c4) + _0x16a24b(0x1f7)](path['pa'], JSON[_0x16a24b(0x2a6)](pagos));
                continue;
            case '2':
                _0x1917de[_0x16a24b(0x239)]({ 'msg': _0x5bfcb0[_0x16a24b(0x1d2)] });
                continue;
            case '3':
                usuarioV = _0x5bfcb0[_0x16a24b(0x186)](_0x5bfcb0[_0x16a24b(0x277)], ('' + _0x5bfcb0[_0x16a24b(0x1ea)](ale))[_0x16a24b(0x1a2)](0x20b9 + 0x1653 + -0x370c, 0x1fd9 + 0x3b * 0x5 + -0x2 * 0x107e));
                continue;
            case '4':
                var {id: _0x16dc13} = _0x2a8d08[_0x16a24b(0x162)];
                continue;
            case '5':
                console[_0x16a24b(0x22f)](_0x36a3e0);
                continue;
            case '6':
                console[_0x16a24b(0x22f)](_0x36a3e0, _0x16dc13);
                continue;
            case '7':
                senha = ('' + _0x5bfcb0[_0x16a24b(0x187)](ale))[_0x16a24b(0x1a2)](-0x250e + -0xf76 * 0x1 + 0x3484, 0x9fb + -0x2 * 0x971 + 0x2f9 * 0x3);
                continue;
            case '8':
                pagtoC = await _0x1c744d[_0x16a24b(0x258) + 'e'](_0x36a3e0, { 'text': _0x5bfcb0[_0x16a24b(0x145)](_0x5bfcb0[_0x16a24b(0x1dc)](_0x5bfcb0[_0x16a24b(0x24f)], _0x16dc13), _0x5bfcb0[_0x16a24b(0x142)]) })[_0x16a24b(0x1c7)](_0x69ba40 => {
                    const _0x1bc20b = _0x16a24b;
                    console[_0x1bc20b(0x22f)](_0x5bfcb0[_0x1bc20b(0x27c)]), console[_0x1bc20b(0x22f)](_0x69ba40), _0x1917de[_0x1bc20b(0x239)]({ 'msg': _0x5bfcb0[_0x1bc20b(0x1d0)] });
                });
                continue;
            case '9':
                if (!_0x36a3e0[_0x16a24b(0x18d)]('@s'))
                    return _0x1917de[_0x16a24b(0x239)]({ 'msg': _0x5bfcb0[_0x16a24b(0x1a3)] });
                continue;
            case '10':
                var {user: _0x36a3e0} = _0x2a8d08[_0x16a24b(0x162)];
                continue;
            case '11':
                _0x5bfcb0[_0x16a24b(0x211)](exec, _0x16a24b(0x25c) + _0x16a24b(0x23a) + _0x16a24b(0x21e) + usuarioV + '\x20' + senha);
                continue;
            }
            break;
        }
    }), app[_0x22fbbf(0x235)](_0x5bfcb0[_0x22fbbf(0x1ac)], async (_0x36657e, _0x58b13f) => {
        const _0x27f788 = _0x22fbbf;
        var {user: _0x1a3f33} = _0x36657e[_0x27f788(0x162)], {id: _0x693068} = _0x36657e[_0x27f788(0x162)];
        if (!_0x1a3f33[_0x27f788(0x18d)]('@s'))
            return _0x58b13f[_0x27f788(0x239)]({ 'msg': _0x5bfcb0[_0x27f788(0x1a3)] });
        await _0x1c744d[_0x27f788(0x258) + 'e'](_0x1a3f33, { 'text': _0x5bfcb0[_0x27f788(0x27b)](_0x5bfcb0[_0x27f788(0x1f6)], _0x693068) })[_0x27f788(0x1c7)](_0x1df434 => console[_0x27f788(0x22f)](_0x1df434));
    }), _0x1c744d['ev']['on'](_0x5bfcb0[_0x22fbbf(0x24c)], async _0x41e3ee => {
        const _0x22fc2b = _0x22fbbf;
        _0x1c744d[_0x22fc2b(0x224) + _0x22fc2b(0x157)](_0x5bfcb0[_0x22fc2b(0x283)]), message = _0x41e3ee[_0x22fc2b(0x192)][-0x57d + -0x2 * 0x631 + 0x11df], msg = message[_0x22fc2b(0x191)], key = message[_0x22fc2b(0x1ff)], fromMe = key[_0x22fc2b(0x17c)];
        if (fromMe)
            return;
        from = key[_0x22fc2b(0x238)], isGroup = from[_0x22fc2b(0x18d)](_0x5bfcb0[_0x22fc2b(0x176)]), jid = isGroup ? key[_0x22fc2b(0x272) + 't'] : from;
        if (isGroup)
            return;
        name = message[_0x22fc2b(0x290)], body = msg[_0x22fc2b(0x1b2) + 'on'] ? msg[_0x22fc2b(0x1b2) + 'on'] : msg[_0x22fc2b(0x1d5) + _0x22fc2b(0x1fc)] ? msg[_0x22fc2b(0x1d5) + _0x22fc2b(0x1fc)][_0x22fc2b(0x276)] : _0x5bfcb0[_0x22fc2b(0x16f)], body = body[_0x22fc2b(0x296) + 'e']();
        async function _0xa52588(_0x14a5dc) {
            const _0xaac137 = _0x22fc2b;
            await _0x1c744d[_0xaac137(0x258) + 'e'](from, { 'text': _0x14a5dc }, { 'quoted': message });
        }
        async function _0x1915f1(_0x2bb582, _0x25dbef) {
            const _0x4b4377 = _0x22fc2b;
            await _0x1c744d[_0x4b4377(0x258) + 'e'](_0x2bb582, { 'text': _0x25dbef });
        }
        if (!isGroup)
            console[_0x22fc2b(0x22f)](_0x22fc2b(0x1ed) + _0x22fc2b(0x23b) + _0x22fc2b(0x27d) + _0x5bfcb0[_0x22fc2b(0x211)](repla, jid) + '\x20(' + name + (_0x22fc2b(0x250) + _0x22fc2b(0x1a6)) + body + (_0x22fc2b(0x243) + _0x22fc2b(0x206)));
        _0x1c744d[_0x22fc2b(0x224) + _0x22fc2b(0x157)](_0x5bfcb0[_0x22fc2b(0x283)], jid), _0x1c744d[_0x22fc2b(0x1c6) + 'es']([key]);
        if (isGroup)
            return;
        switch (body) {
        case '1':
        case '01':
            if (await _0x5bfcb0[_0x22fc2b(0x211)](checkTeste, jid))
                return _0x5bfcb0[_0x22fc2b(0x211)](_0xa52588, _0x5bfcb0[_0x22fc2b(0x1cb)]);
            usuarioT = _0x5bfcb0[_0x22fc2b(0x28e)](_0x5bfcb0[_0x22fc2b(0x205)], ('' + _0x5bfcb0[_0x22fc2b(0x23e)](ale))[_0x22fc2b(0x1a2)](0x1d86 + 0x330 + -0x20b6, -0x4f * -0x20 + -0x50b * -0x3 + 0x18fd * -0x1)), _0x5bfcb0[_0x22fc2b(0x1d1)](exec, _0x22fc2b(0x25c) + _0x22fc2b(0x23a) + _0x22fc2b(0x24b) + usuarioT + '\x20' + _0x5bfcb0[_0x22fc2b(0x1e3)](config[_0x22fc2b(0x179) + 'e'], -0x24ac + 0x2238 + 0x2b0)), tesy = await _0x1c744d[_0x22fc2b(0x258) + 'e'](jid, { 'text': _0x22fc2b(0x200) + _0x22fc2b(0x218) + _0x22fc2b(0x156) + _0x22fc2b(0x24d) + usuarioT + (_0x22fc2b(0x22a) + _0x22fc2b(0x15e) + _0x22fc2b(0x234) + _0x22fc2b(0x18a) + '*\x20') + config[_0x22fc2b(0x179) + 'e'] + 'h' }, { 'quoted': message }), await _0x1c744d[_0x22fc2b(0x258) + 'e'](jid, { 'text': _0x5bfcb0[_0x22fc2b(0x15c)] }, { 'quoted': tesy }), await _0x5bfcb0[_0x22fc2b(0x1ee)](delay, 0x219 * -0xc + 0x18d * -0x1 + -0x98f * -0x3), _0x5bfcb0[_0x22fc2b(0x1ee)](gravarTeste, jid);
            break;
        case '2':
        case '02':
            placa2 = _0x22fc2b(0x200) + _0x22fc2b(0x1b9) + _0x22fc2b(0x253) + _0x22fc2b(0x190) + config[_0x22fc2b(0x1a0)] + (_0x22fc2b(0x178) + _0x22fc2b(0x1a4) + _0x22fc2b(0x26d) + _0x22fc2b(0x1a1) + _0x22fc2b(0x18f) + _0x22fc2b(0x1f0) + _0x22fc2b(0x169) + _0x22fc2b(0x152) + _0x22fc2b(0x1fa) + _0x22fc2b(0x149) + _0x22fc2b(0x202) + _0x22fc2b(0x20f) + _0x22fc2b(0x245) + _0x22fc2b(0x24e) + _0x22fc2b(0x246) + _0x22fc2b(0x182)), _0x5bfcb0[_0x22fc2b(0x1ee)](_0xa52588, placa2);
            break;
        case _0x5bfcb0[_0x22fc2b(0x14e)]:
        case 'si':
        case 'ss':
        case 's':
            if (await _0x5bfcb0[_0x22fc2b(0x158)](checkUser, jid))
                return _0x5bfcb0[_0x22fc2b(0x211)](_0xa52588, _0x5bfcb0[_0x22fc2b(0x1e1)]);
            _0x5bfcb0[_0x22fc2b(0x1fe)](_0xa52588, _0x5bfcb0[_0x22fc2b(0x1f1)]), dados = await _0x5bfcb0[_0x22fc2b(0x148)](gerar, jid, message), placa = _0x22fc2b(0x229) + _0x22fc2b(0x29d) + _0x22fc2b(0x284) + '\x20' + dados['id'] + (_0x22fc2b(0x1d6) + '$') + dados[_0x22fc2b(0x2a3)] + (_0x22fc2b(0x207) + _0x22fc2b(0x25f) + _0x22fc2b(0x208)) + dados[_0x22fc2b(0x153)] + (_0x22fc2b(0x19b) + _0x22fc2b(0x160) + _0x22fc2b(0x223) + _0x22fc2b(0x278) + _0x22fc2b(0x2a0) + _0x22fc2b(0x1eb) + _0x22fc2b(0x159) + _0x22fc2b(0x247) + _0x22fc2b(0x166) + _0x22fc2b(0x261) + _0x22fc2b(0x19d) + _0x22fc2b(0x233) + _0x22fc2b(0x1f3) + _0x22fc2b(0x167) + _0x22fc2b(0x1b3) + _0x22fc2b(0x16d) + '⤵️'), mcode = await _0x1c744d[_0x22fc2b(0x258) + 'e'](dados[_0x22fc2b(0x25d)], { 'text': placa }, { 'quoted': dados[_0x22fc2b(0x227)] }), await _0x1c744d[_0x22fc2b(0x258) + 'e'](dados[_0x22fc2b(0x25d)], { 'text': dados[_0x22fc2b(0x1c9)] }, { 'quoted': mcode });
            break;
        case _0x5bfcb0[_0x22fc2b(0x240)]:
        case _0x5bfcb0[_0x22fc2b(0x203)]:
        case 'no':
        case 'n':
        case 'nn':
            _0x5bfcb0[_0x22fc2b(0x211)](_0xa52588, _0x5bfcb0[_0x22fc2b(0x273)]);
            break;
        case '5':
        case '05':
            await _0x1c744d[_0x22fc2b(0x258) + 'e'](jid, {
                'text': _0x22fc2b(0x1f5) + _0x22fc2b(0x14b) + dono2,
                'mentions': dono
            }, { 'quoted': message });
            break;
        case '3':
        case '03':
            gama = await _0x5bfcb0[_0x22fc2b(0x28c)](checkLogins, jid), await _0x1c744d[_0x22fc2b(0x258) + 'e'](jid, { 'text': gama }, { 'quoted': message });
            break;
        case _0x5bfcb0[_0x22fc2b(0x214)]:
        case _0x5bfcb0[_0x22fc2b(0x1e6)]:
        case '4':
        case '04':
            _0x5bfcb0[_0x22fc2b(0x1ee)](_0xa52588, _0x5bfcb0[_0x22fc2b(0x19a)]), await _0x1c744d[_0x22fc2b(0x258) + 'e'](jid, { 'text': _0x22fc2b(0x297) + _0x22fc2b(0x225) + _0x22fc2b(0x20a) + _0x22fc2b(0x15a) + _0x22fc2b(0x280) + config[_0x22fc2b(0x1e9)] + (_0x22fc2b(0x151) + _0x22fc2b(0x17f) + _0x22fc2b(0x204) + _0x22fc2b(0x1ab) + _0x22fc2b(0x185) + _0x22fc2b(0x1e5) + _0x22fc2b(0x257)) }, { 'quoted': message });
            break;
        default:
            boasvindas = _0x22fc2b(0x28d) + name + (_0x22fc2b(0x1da) + _0x22fc2b(0x198)) + config[_0x22fc2b(0x209)] + (_0x22fc2b(0x267) + _0x22fc2b(0x244) + _0x22fc2b(0x188) + _0x22fc2b(0x295) + _0x22fc2b(0x177) + _0x22fc2b(0x1b1) + _0x22fc2b(0x271) + _0x22fc2b(0x15b) + _0x22fc2b(0x262) + _0x22fc2b(0x184) + _0x22fc2b(0x266) + _0x22fc2b(0x1dd) + _0x22fc2b(0x281) + _0x22fc2b(0x2a4) + _0x22fc2b(0x217) + _0x22fc2b(0x163) + _0x22fc2b(0x1bb) + _0x22fc2b(0x20e)), _0x5bfcb0[_0x22fc2b(0x1fe)](_0xa52588, boasvindas);
        }
    });
}
connectToWhatsApp();