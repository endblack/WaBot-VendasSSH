const _0x4f18ea = _0x1db1;
(function (_0x39e719, _0x283008) {
    const _0x243229 = _0x1db1, _0x2af72e = _0x39e719();
    while (!![]) {
        try {
            const _0x1256ab = parseInt(_0x243229(0x1b2)) / (-0xb35 * -0x2 + -0x207e + 0xa15) + parseInt(_0x243229(0x276)) / (-0x4d0 + 0x55 * -0xa + 0x824) * (-parseInt(_0x243229(0x25c)) / (-0x1 * -0x1c5d + 0x85 * -0x21 + 0x13 * -0x97)) + -parseInt(_0x243229(0x16b)) / (0xc * 0x42 + 0x18de + -0xe * 0x1ff) * (parseInt(_0x243229(0x1b9)) / (0x92 * 0x3 + 0x25f4 + -0xc7 * 0x33)) + -parseInt(_0x243229(0x1d7)) / (-0x245 * 0x6 + 0x126b + 0x1 * -0x4c7) + parseInt(_0x243229(0x278)) / (-0x77 + 0x44a + -0x3cc) * (parseInt(_0x243229(0x20e)) / (-0xb3c * 0x3 + 0x137 * 0x17 + 0x5cb * 0x1)) + parseInt(_0x243229(0x2a0)) / (-0x1495 + 0x67d + -0x1 * -0xe21) + parseInt(_0x243229(0x18e)) / (-0x68e * -0x2 + -0xf33 + 0x221 * 0x1);
            if (_0x1256ab === _0x283008)
                break;
            else
                _0x2af72e['push'](_0x2af72e['shift']());
        } catch (_0x2e2e71) {
            _0x2af72e['push'](_0x2af72e['shift']());
        }
    }
}(_0x2da4, 0x1 * 0xc2361 + -0x2ca1b * -0x1 + -0x610a4));
const {
        default: makeWASocket,
        delay,
        DisconnectReason,
        BufferJSON,
        useMultiFileAuthState
    } = require(_0x4f18ea(0x263) + _0x4f18ea(0x236) + _0x4f18ea(0x2ad)), {Boom} = require(_0x4f18ea(0x1a7)), P = require(_0x4f18ea(0x1bf)), {exec} = require(_0x4f18ea(0x269) + _0x4f18ea(0x22f)), express = require(_0x4f18ea(0x213)), {gerar} = require(_0x4f18ea(0x28e) + _0x4f18ea(0x28a) + _0x4f18ea(0x28f)), app = express(), moment = require(_0x4f18ea(0x15c) + _0x4f18ea(0x2aa)), fs = require(_0x4f18ea(0x1d8)), ms = require('ms'), pms = require(_0x4f18ea(0x27e)), {config} = require(_0x4f18ea(0x279) + 'ig');
function _0x2da4() {
    const _0x58fb47 = [
        'format',
        'ável,\x20salv',
        'WFrmB',
        'FkXin',
        '\x0a\x0a########',
        'jitiy',
        'log',
        'iaiyJ',
        '!\x20Se\x20preci',
        'LaCes',
        'qmDrq',
        '⌛Validade:',
        'steja\x20clic',
        '\x0a*[02]*\x20Co',
        '*Informaçõ',
        'ste\x20🔥',
        'm\x20pedido\x20e',
        'yQvkm',
        '\x0a*🔐Senha:*',
        'NHoxu',
        'mvBrS',
        '@hapi/boom',
        'nao',
        'ato\x20que\x20el',
        '\x20confirmad',
        'ZqXXJ',
        '\x20o\x20comando',
        'bad\x20reques',
        'teste',
        'key',
        'pre\x20faça\x20u',
        '/teste.sh\x20',
        '375931gUHVSP',
        'jmxok',
        '05]*\x20Supor',
        'random',
        'splice',
        'usuario',
        'ozdNo',
        '55vMtnpZ',
        'sh\x20/etc/me',
        'BvJtd',
        '\x0a\x0a🆔@',
        'em\x20logins\x20',
        'erar\x20outro',
        'pino',
        'das\x20opções',
        '\x20em\x2024h',
        'bot/login',
        'bot/src/ve',
        'cpTnk',
        'qdRkB',
        '\x0a🏷️Valor:\x20R',
        'connecting',
        'ões\x20do\x20log',
        'ONjhH',
        'readMessag',
        'connection',
        'EisHr',
        '\x0a\x0a*👤Usuári',
        '/app',
        'aNPFv',
        'dono',
        'slice',
        'obDjn',
        ',\x20Reconect',
        '@s.whatsap',
        'msgkey',
        'sIDYy',
        '852396UgoBKZ',
        'fs-extra',
        '*\x20login\x27s\x20',
        'readFileSy',
        'pIBee',
        'fromMe',
        'SRuRz',
        '\x20vontade\x20p',
        'dido',
        '\x0a⌛Expira\x20e',
        'split',
        'GhoTe',
        'sendMessag',
        '/pago',
        'DIoLQ',
        'dvvRB',
        'te\x20hoje,\x20s',
        'baixo⤵️\x0a\x0a',
        'u\x20*Não*',
        'floor',
        'messages',
        'deu\x20erro',
        'p.net',
        'add',
        'morar\x20cerc',
        'NWbeX',
        'bot/data/t',
        'Você\x20não\x20t',
        '31d',
        'Aproveite\x20',
        '\x0a*⌛Validad',
        'Pagamento\x20',
        'parse',
        'taFan',
        '*•Informaç',
        '\x0a\x0aMensagem',
        'gHWic',
        'Conexão\x20fe',
        'extendedTe',
        'pp,\x20digite',
        'toLowerCas',
        'id:\x20',
        'CxQPi',
        '0|5|4|2|6|',
        'get',
        'NdAGy',
        'o_Paulo',
        'cOVIY',
        'duto•*\x0a\x0a*🏷️',
        '*☎️Suporte*',
        'message',
        '========',
        '):\x0a\x0aMensag',
        'njtTj',
        '*\x20_(horári',
        '2328lHLMpO',
        'length',
        '\x0a/app\x0a\x0aDes',
        'ode\x20copia\x20',
        'participan',
        'express',
        'ndo(a)\x20a\x20*',
        'Tudo\x20certo',
        'CUBzQ',
        'bot/data/p',
        'close',
        'u\x20espere\x20e',
        'push',
        'kPYax',
        'HlcCr',
        '*\x201\x0a*⌛Vali',
        'ões\x20do\x20pro',
        'dias\x0a\x0a📌Sem',
        'CONECTADO\x20',
        'nVWlJ',
        'sNVYp',
        'writeFileS',
        'ó\x20poderá\x20g',
        'valorLogin',
        'ocYWK',
        'o:*\x20',
        'QLSEZ',
        '.update',
        'tempo_test',
        'e:*\x20',
        'sjqUq',
        'NDdMP',
        '🆔Id:\x20',
        'ess',
        'available',
        'n\x2030\x20dias\x20',
        'XwTZa',
        'ar\x20teste\x20⌛',
        'vwBOL',
        'uário:*\x20',
        'ckets/bail',
        'rou\x20um\x20tes',
        'te\x20👤',
        'OwokY',
        'silent',
        'psert',
        'mprar\x20logi',
        'NvJjZ',
        'GPLvd',
        'fJEjB',
        'pirado:*\x0a\x0a',
        'xtMessage',
        'm\x20andament',
        'lQfKa',
        'nload\x20do\x20a',
        'hora',
        'estes.json',
        '\x20seu\x20pagam',
        'COM\x20SUCESS',
        'venceu',
        'includes',
        'limite',
        'DgPqd',
        '\x20para\x20faze',
        'o,\x20pode\x20de',
        '\x0a\x0a📌Caso\x20o\x20',
        'yLJXz',
        'yFHNo',
        'chada\x20por:',
        'bem\x20seu\x20te',
        'às\x20*',
        'DD/MM/yyyy',
        'midia',
        'a\x20de\x201\x20min',
        'fbJLN',
        'aAHNy',
        'SWWnU',
        'TqNbK',
        '399amJdvG',
        'Sdpbp',
        ')\x0a\x0a=======',
        '\x20dias',
        '1|3|7|8',
        'uto.\x0a\x0a_Qrc',
        'ync',
        '@whiskeyso',
        'm:\x2010\x20min\x0a',
        '\x20(31\x20dias)',
        'dentificad',
        'xmhru',
        'dKvCe',
        'child_proc',
        'vegador...',
        'Aguarde...',
        'rá\x20enviado',
        'expira',
        'WeAUG',
        'ogins\x20🔍\x0a*[',
        '/cancel',
        'e\x20cola\x20log',
        'BeUpH',
        '\x20obter\x20o\x20a',
        'r\x20outro\x20pe',
        'BCeYF',
        '13490hkERWb',
        'WOMqa',
        '2646SiWruT',
        '/root/conf',
        'lia)_\x0a\x0a📌Se',
        '!*\x20Fique\x20a',
        'FrTeD',
        'em:\x20',
        'parse-ms',
        'qSaJG',
        'o,\x20pague\x20o',
        'ativo\x20📱\x0a*[',
        '*Qrcode\x20ex',
        'rJZXw',
        'qlWaB',
        'dade:*\x20',
        '\x201234\x0a*📲Li',
        'catch',
        'sucess',
        'linkApp',
        'bot/src/ge',
        'r?\x20*Sim*\x20o',
        'Conectando',
        '\x20abaixo:\x0a\x0a',
        '/etc/megah',
        'rar',
        'er\x20alguma\x20',
        'Você\x20tem\x20u',
        '\x0a*📲Limite:',
        'creds.upda',
        'in•*\x0a\x0a*👤Us',
        'HkESz',
        'uYJRE',
        'zVuRl',
        'indexOf',
        'OlbeO',
        'stringify',
        'days',
        'Abrindo\x20na',
        'query',
        'BLqeM',
        '@g.us',
        '9293814LckAYg',
        'ara\x20escolh',
        'code...',
        'vmwlT',
        '\x20assim\x20que',
        'ALETk',
        '\x20😃,\x20Bem\x20vi',
        'yBBsV',
        'ceUpdate',
        'zqgOw',
        'ezone',
        'gahbot/src',
        'de:*\x0a\x0a🆔Id:',
        'eys',
        'hUrPS',
        'valor',
        'text',
        'America/Sa',
        'senha',
        'FKLPx',
        'es\x20do\x20Qrco',
        'e\x20meu\x20cont',
        'o\x20de\x20Brasí',
        'Você\x20já\x20ge',
        'pushName',
        'erificar\x20L',
        'pp\x20através',
        'edidos.jso',
        '####',
        'Você\x20tem\x20*',
        '*[01]*\x20Ger',
        'ento\x20for\x20i',
        '...',
        'u\x20login\x20se',
        'json',
        'eja\x20compra',
        'jRyzp',
        'm\x20teste\x20an',
        'sar\x20é\x20só\x20m',
        'now',
        'nomeLoja',
        'tes\x20de\x20com',
        'e\x20ficará',
        'moment-tim',
        'Faça\x20o\x20dow',
        'PwgaI',
        'o\x20abaixo_\x20',
        'agos.json',
        'qrcode',
        'HAEna',
        'dade:*\x2030\x20',
        'sim',
        'AhTYR',
        'link\x20não\x20e',
        'messages.u',
        '📆\x0a*[03]*\x20V',
        'efjVP',
        '\x20do\x20link\x20a',
        '235528NFxvWb',
        '\x20no\x20privad',
        'logins',
        'XcJxt',
        'WUkoe',
        'open',
        '/user.sh\x20',
        'conversati',
        'jCvgm',
        'SiyNa',
        'Gerando\x20Qr',
        'o\x20de\x20',
        'ando...',
        'Validade',
        'BMvFY',
        'Premium',
        'remoteJid',
        'error',
        'sendPresen',
        'não',
        'mite:*\x201\x0a*',
        'Olá\x20',
        'uJsyE',
        'user',
        'SwmjT',
        '\x20abaixo\x20⤵️\x0a',
        'listen',
        'Valor:*\x20R$',
        'PeFqu',
        'uCNid',
        '04]*\x20Aplic',
        'prar!\x0aPara',
        'CesNW',
        'CasfS',
        'le\x20expirar',
        '7491020PgjJJj',
        'e\x20chamar!\x20',
        'KSTau',
        'app'
    ];
    _0x2da4 = function () {
        return _0x58fb47;
    };
    return _0x2da4();
}
time = ms('1d'), expiraZ = ms(_0x4f18ea(0x1f3)), d31 = moment['tz'](_0x4f18ea(0x2b1) + _0x4f18ea(0x205))[_0x4f18ea(0x1ee)](-0x1fff + -0xfc9 * 0x2 + -0x3fb * -0x10, 'd')[_0x4f18ea(0x192)](_0x4f18ea(0x255)), app[_0x4f18ea(0x185)](-0x35e4 + -0x5d * 0x7d + -0x141 * -0x65), dono = [config[_0x4f18ea(0x1d0)] + (_0x4f18ea(0x1d4) + _0x4f18ea(0x1ed))], dono2 = '' + config[_0x4f18ea(0x1d0)], path = {
    'p': _0x4f18ea(0x28e) + _0x4f18ea(0x217) + _0x4f18ea(0x2bb) + 'n',
    't': _0x4f18ea(0x28e) + _0x4f18ea(0x1f1) + _0x4f18ea(0x246),
    'pa': _0x4f18ea(0x28e) + _0x4f18ea(0x217) + _0x4f18ea(0x160)
};
async function checkUser(_0x3e7b75) {
    const _0x154e70 = _0x4f18ea, _0x5467f0 = {
            'njtTj': function (_0xad9ff3, _0x272695) {
                return _0xad9ff3 < _0x272695;
            },
            'CUBzQ': function (_0x342259, _0x3558b9) {
                return _0x342259 == _0x3558b9;
            }
        };
    pedidos = await JSON[_0x154e70(0x1f7)](fs[_0x154e70(0x1da) + 'nc'](path['p']));
    for (var _0xccf20d = 0x139 + -0x19 * -0x3 + -0x184; _0x5467f0[_0x154e70(0x20c)](_0xccf20d, pedidos[_0x154e70(0x20f)]); _0xccf20d++) {
        if (_0x5467f0[_0x154e70(0x216)](pedidos[_0xccf20d][_0x154e70(0x182)], _0x3e7b75))
            return !![];
    }
    return ![];
}
async function checkTeste(_0x505610) {
    const _0x3184db = _0x4f18ea, _0x2453ae = {
            'cOVIY': function (_0x12cf6a, _0x3271ba) {
                return _0x12cf6a < _0x3271ba;
            },
            'TqNbK': function (_0x38f6bf, _0x186ac1) {
                return _0x38f6bf == _0x186ac1;
            },
            'XcJxt': function (_0x4c20bb, _0x94760d) {
                return _0x4c20bb < _0x94760d;
            },
            'PwgaI': function (_0x46ed68, _0x42be5b) {
                return _0x46ed68 > _0x42be5b;
            }
        };
    testes = await JSON[_0x3184db(0x1f7)](fs[_0x3184db(0x1da) + 'nc'](path['t'])), testes = await JSON[_0x3184db(0x1f7)](fs[_0x3184db(0x1da) + 'nc'](path['t']));
    for (var _0x33ab2e = 0x2a * 0x16 + -0x1c4 * -0x13 + 0x29 * -0xe8; _0x2453ae[_0x3184db(0x206)](_0x33ab2e, testes[_0x3184db(0x20f)]); _0x33ab2e++) {
        if (_0x2453ae[_0x3184db(0x25b)](testes[_0x33ab2e][_0x3184db(0x182)], _0x505610)) {
            if (_0x2453ae[_0x3184db(0x16e)](Date[_0x3184db(0x158)](), testes[_0x33ab2e][_0x3184db(0x26d)]))
                return !![];
            if (_0x2453ae[_0x3184db(0x15e)](Date[_0x3184db(0x158)](), testes[_0x33ab2e][_0x3184db(0x26d)]))
                return testes[_0x3184db(0x1b6)](_0x33ab2e, 0x1122 + -0xd * -0x1 + -0x2 * 0x897), await fs[_0x3184db(0x223) + _0x3184db(0x262)](path['t'], JSON[_0x3184db(0x29a)](testes)), ![];
        }
    }
    return ![];
}
function _0x1db1(_0x4f9c03, _0x26d6e3) {
    const _0x4607e3 = _0x2da4();
    return _0x1db1 = function (_0x2a813b, _0xf89066) {
        _0x2a813b = _0x2a813b - (-0xb9d + 0x3e7 + 0x90c);
        let _0x47d530 = _0x4607e3[_0x2a813b];
        return _0x47d530;
    }, _0x1db1(_0x4f9c03, _0x26d6e3);
}
async function gravarTeste(_0xfca0cf) {
    const _0xe09f47 = _0x4f18ea, _0x2ace8a = {
            'OwokY': function (_0x1d67bc, _0x16137b) {
                return _0x1d67bc + _0x16137b;
            }
        };
    testes = await JSON[_0xe09f47(0x1f7)](fs[_0xe09f47(0x1da) + 'nc'](path['t'])), obj = {
        'user': _0xfca0cf,
        'expira': _0x2ace8a[_0xe09f47(0x239)](Date[_0xe09f47(0x158)](), time)
    }, testes[_0xe09f47(0x21a)](obj), await fs[_0xe09f47(0x223) + _0xe09f47(0x262)](path['t'], JSON[_0xe09f47(0x29a)](testes));
}
function ale() {
    const _0x129dc7 = _0x4f18ea, _0x5830dd = {
            'SwmjT': function (_0x45abe2, _0x1a3dbf) {
                return _0x45abe2 * _0x1a3dbf;
            },
            'BvJtd': function (_0x153827, _0x594146) {
                return _0x153827 + _0x594146;
            }
        };
    return i = 0x8ac7230489e80000, Math[_0x129dc7(0x1ea)](_0x5830dd[_0x129dc7(0x183)](Math[_0x129dc7(0x1b5)](), _0x5830dd[_0x129dc7(0x1bb)](i, 0x1 * -0x1e31 + 0xf3c + 0x2 * 0x77b)));
}
function repla(_0x2f6c43) {
    const _0x332395 = _0x4f18ea;
    return i = _0x2f6c43[_0x332395(0x298)]('@'), _0x2f6c43[_0x332395(0x1d1)](-0x3 * -0x9cd + -0x279 + -0x1aee, i);
}
async function chackPago(_0xfa1d67) {
    const _0xbc293c = _0x4f18ea, _0x2088e1 = {
            'SWWnU': function (_0x56650c, _0x1b95e8) {
                return _0x56650c < _0x1b95e8;
            },
            'SiyNa': function (_0x8ff048, _0x4f26f7) {
                return _0x8ff048 == _0x4f26f7;
            }
        };
    pagos = await JSON[_0xbc293c(0x1f7)](fs[_0xbc293c(0x1da) + 'nc'](path['pa']));
    for (var _0x315512 = 0x189c + -0x69 * -0x32 + -0x41a * 0xb; _0x2088e1[_0xbc293c(0x25a)](_0x315512, pagos[_0xbc293c(0x20f)]); _0x315512++) {
        if (_0x2088e1[_0xbc293c(0x174)](pagos[_0x315512][_0xbc293c(0x182)], _0xfa1d67))
            return !![];
    }
    return ![];
}
async function checkLogins(_0x227acf) {
    const _0x3f3867 = _0x4f18ea, _0x426b19 = {
            'BeUpH': function (_0x19bf6b, _0x479a0a) {
                return _0x19bf6b < _0x479a0a;
            },
            'ozdNo': function (_0x56dc97, _0x116a71) {
                return _0x56dc97 == _0x116a71;
            },
            'WOMqa': function (_0x1bf147, _0x2dc8c2) {
                return _0x1bf147 < _0x2dc8c2;
            },
            'uYJRE': _0x3f3867(0x202) + _0x3f3867(0x260),
            'cpTnk': function (_0x1a0f03, _0x41caa8) {
                return _0x1a0f03 + _0x41caa8;
            },
            'CasfS': _0x3f3867(0x25f),
            'WeAUG': function (_0x5629fc, _0x3c1839) {
                return _0x5629fc(_0x3c1839);
            },
            'FkXin': function (_0x13350b, _0x33c093) {
                return _0x13350b - _0x33c093;
            },
            'GhoTe': function (_0x28add7, _0x242a24) {
                return _0x28add7 > _0x242a24;
            },
            'Sdpbp': _0x3f3867(0x249),
            'yLJXz': function (_0x51b3cd, _0x486fa9) {
                return _0x51b3cd + _0x486fa9;
            },
            'SRuRz': _0x3f3867(0x1f2) + _0x3f3867(0x1bd) + _0x3f3867(0x17a)
        };
    pagos = await JSON[_0x3f3867(0x1f7)](fs[_0x3f3867(0x1da) + 'nc'](path['pa']));
    for (var _0x14f7a4 = 0xd80 * -0x1 + 0x936 + 0x44a; _0x426b19[_0x3f3867(0x272)](_0x14f7a4, pagos[_0x3f3867(0x20f)]); _0x14f7a4++) {
        if (_0x426b19[_0x3f3867(0x1b8)](pagos[_0x14f7a4][_0x3f3867(0x182)], _0x227acf)) {
            logins = pagos[_0x14f7a4][_0x3f3867(0x16d)], quanti = logins[_0x3f3867(0x20f)], tesk = _0x3f3867(0x2bd) + '0' + quanti + (_0x3f3867(0x1d9) + _0x3f3867(0x17a));
            for (var _0x14f7a4 = 0x2b * 0xe + 0x6ac * 0x1 + -0x7 * 0x14a; _0x426b19[_0x3f3867(0x277)](_0x14f7a4, logins[_0x3f3867(0x20f)]); _0x14f7a4++) {
                const _0x250af8 = _0x426b19[_0x3f3867(0x296)][_0x3f3867(0x1e1)]('|');
                let _0x1df86f = 0xf4a + 0xeb * 0x7 + -0x15b7;
                while (!![]) {
                    switch (_0x250af8[_0x1df86f++]) {
                    case '0':
                        usu = logins[_0x14f7a4][_0x3f3867(0x1b7)];
                        continue;
                    case '1':
                        exp = _0x426b19[_0x3f3867(0x1c4)](exp[_0x3f3867(0x29b)], _0x426b19[_0x3f3867(0x18c)]);
                        continue;
                    case '2':
                        vali = logins[_0x14f7a4][_0x3f3867(0x178)];
                        continue;
                    case '3':
                        exps = logins[_0x14f7a4][_0x3f3867(0x26d)];
                        continue;
                    case '4':
                        limi = logins[_0x14f7a4][_0x3f3867(0x24b)];
                        continue;
                    case '5':
                        sen = logins[_0x14f7a4][_0x3f3867(0x2b2)];
                        continue;
                    case '6':
                        exp = _0x426b19[_0x3f3867(0x26e)](pms, _0x426b19[_0x3f3867(0x195)](logins[_0x14f7a4][_0x3f3867(0x26d)], Date[_0x3f3867(0x158)]()));
                        continue;
                    case '7':
                        if (_0x426b19[_0x3f3867(0x1e2)](Date[_0x3f3867(0x158)](), exp))
                            exp = _0x426b19[_0x3f3867(0x25d)];
                        continue;
                    case '8':
                        tesk = _0x426b19[_0x3f3867(0x250)](tesk, _0x3f3867(0x1cd) + _0x3f3867(0x227) + usu + (_0x3f3867(0x1a4) + '\x20') + sen + (_0x3f3867(0x292) + '*\x20') + limi + (_0x3f3867(0x1f5) + _0x3f3867(0x22b)) + vali + '\x20(' + exp + (_0x3f3867(0x25e) + _0x3f3867(0x20a)));
                        continue;
                    }
                    break;
                }
            }
            return tesk;
        }
    }
    return _0x426b19[_0x3f3867(0x1dd)];
}
async function connectToWhatsApp() {
    const _0x837f99 = _0x4f18ea, _0x1d452a = {
            'qdRkB': function (_0x3b13a6, _0x4b10a6) {
                return _0x3b13a6 == _0x4b10a6;
            },
            'NdAGy': _0x837f99(0x1c7),
            'HAEna': _0x837f99(0x28c) + _0x837f99(0x2c0),
            'FrTeD': function (_0x55101, _0x333dc8) {
                return _0x55101 === _0x333dc8;
            },
            'HlcCr': _0x837f99(0x218),
            'jitiy': _0x837f99(0x1fc) + _0x837f99(0x252) + '\x20',
            'qlWaB': _0x837f99(0x1d3) + _0x837f99(0x177),
            'GPLvd': function (_0x4006af, _0x472c13) {
                return _0x4006af(_0x472c13);
            },
            'efjVP': function (_0x473e1f) {
                return _0x473e1f();
            },
            'lQfKa': _0x837f99(0x170),
            'OlbeO': _0x837f99(0x220) + _0x837f99(0x248) + 'O!',
            'jRyzp': function (_0x2c25ae, _0x20eff8) {
                return _0x2c25ae(_0x20eff8);
            },
            'CesNW': _0x837f99(0x28e) + _0x837f99(0x1c3) + 'ri',
            'sNVYp': _0x837f99(0x1ec),
            'WFrmB': _0x837f99(0x17c),
            'fJEjB': _0x837f99(0x1ad) + 't',
            'yQvkm': function (_0x30f5d0, _0x148af1) {
                return _0x30f5d0 + _0x148af1;
            },
            'hUrPS': _0x837f99(0x1f6) + _0x837f99(0x200),
            'aAHNy': _0x837f99(0x1aa) + 'o!',
            'dKvCe': function (_0x177b85, _0x5bc09f) {
                return _0x177b85 + _0x5bc09f;
            },
            'rJZXw': _0x837f99(0x182),
            'sjqUq': function (_0x3f716c) {
                return _0x3f716c();
            },
            'zVuRl': function (_0x3d863a) {
                return _0x3d863a();
            },
            'WUkoe': function (_0x138592, _0x120aa7) {
                return _0x138592(_0x120aa7);
            },
            'qmDrq': function (_0x1da102, _0x753dee) {
                return _0x1da102(_0x753dee);
            },
            'xmhru': function (_0x1d6941, _0x1bf084) {
                return _0x1d6941 + _0x1bf084;
            },
            'uJsyE': function (_0x149bc7, _0x446299) {
                return _0x149bc7 < _0x446299;
            },
            'iaiyJ': _0x837f99(0x288),
            'DgPqd': function (_0x31694f, _0xbd9bd3) {
                return _0x31694f + _0xbd9bd3;
            },
            'NWbeX': _0x837f99(0x282) + _0x837f99(0x240) + _0x837f99(0x22e),
            'LaCes': _0x837f99(0x230),
            'jCvgm': _0x837f99(0x29f),
            'QLSEZ': _0x837f99(0x256),
            'DIoLQ': function (_0x51ae61, _0x379258) {
                return _0x51ae61(_0x379258);
            },
            'NDdMP': function (_0x573d32, _0x398743) {
                return _0x573d32(_0x398743);
            },
            'ocYWK': _0x837f99(0x2b7) + _0x837f99(0x237) + _0x837f99(0x1e7) + _0x837f99(0x224) + _0x837f99(0x1be) + _0x837f99(0x1c1),
            'zqgOw': function (_0x40218e, _0x59e663) {
                return _0x40218e + _0x59e663;
            },
            'kPYax': _0x837f99(0x1ae),
            'PeFqu': function (_0x575f16) {
                return _0x575f16();
            },
            'fbJLN': function (_0x378207, _0x59daa5) {
                return _0x378207 * _0x59daa5;
            },
            'BLqeM': _0x837f99(0x1f4) + _0x837f99(0x253) + _0x837f99(0x1a1),
            'dvvRB': function (_0x3cf37a, _0x21e0dc) {
                return _0x3cf37a(_0x21e0dc);
            },
            'BMvFY': function (_0x492061, _0x4c9ef4) {
                return _0x492061(_0x4c9ef4);
            },
            'NvJjZ': function (_0x47c95a, _0x3b7c02) {
                return _0x47c95a(_0x3b7c02);
            },
            'aNPFv': _0x837f99(0x164),
            'uCNid': function (_0x1efaac, _0x1a2f57) {
                return _0x1efaac(_0x1a2f57);
            },
            'vwBOL': _0x837f99(0x291) + _0x837f99(0x1a2) + _0x837f99(0x242) + _0x837f99(0x280) + _0x837f99(0x219) + _0x837f99(0x18d) + _0x837f99(0x24d) + _0x837f99(0x274) + _0x837f99(0x1df),
            'yFHNo': function (_0x47701f, _0x25a9ef) {
                return _0x47701f(_0x25a9ef);
            },
            'vmwlT': _0x837f99(0x175) + _0x837f99(0x2a2),
            'taFan': function (_0x16d911, _0x410c03, _0x51bade) {
                return _0x16d911(_0x410c03, _0x51bade);
            },
            'gHWic': _0x837f99(0x1a8),
            'sIDYy': _0x837f99(0x17e),
            'CxQPi': function (_0x1efdfe, _0x236e1a) {
                return _0x1efdfe(_0x236e1a);
            },
            'yBBsV': _0x837f99(0x215) + _0x837f99(0x19a) + _0x837f99(0x157) + _0x837f99(0x18f) + '😉',
            'mvBrS': function (_0x48087d, _0x131fd8) {
                return _0x48087d(_0x131fd8);
            },
            'AhTYR': _0x837f99(0x1ce),
            'HkESz': _0x837f99(0x191),
            'NHoxu': function (_0x294137, _0x284242) {
                return _0x294137(_0x284242);
            },
            'obDjn': _0x837f99(0x26b),
            'ONjhH': function (_0x3762a3, _0x1a72c6) {
                return _0x3762a3(_0x1a72c6);
            },
            'pIBee': _0x837f99(0x28e) + _0x837f99(0x1c2),
            'ZqXXJ': function (_0x2214a2, _0x331666) {
                return _0x2214a2(_0x331666);
            },
            'nVWlJ': _0x837f99(0x23a),
            'qSaJG': _0x837f99(0x293) + 'te',
            'BCeYF': _0x837f99(0x1cb) + _0x837f99(0x229),
            'jmxok': _0x837f99(0x29c) + _0x837f99(0x26a),
            'KSTau': _0x837f99(0x1e4),
            'EisHr': _0x837f99(0x270),
            'ALETk': _0x837f99(0x167) + _0x837f99(0x23b)
        }, {
            state: _0x31092c,
            saveCreds: _0x5ac26e
        } = await _0x1d452a[_0x837f99(0x1c9)](useMultiFileAuthState, _0x1d452a[_0x837f99(0x1db)]), _0x419a9b = await _0x1d452a[_0x837f99(0x1ab)](makeWASocket, {
            'logger': _0x1d452a[_0x837f99(0x179)](P, { 'level': _0x1d452a[_0x837f99(0x221)] }),
            'printQRInTerminal': !![],
            'auth': _0x31092c,
            'keepAliveIntervalMs': 0x3e80
        });
    _0x419a9b['ev']['on'](_0x1d452a[_0x837f99(0x27f)], _0x5ac26e), _0x419a9b['ev']['on'](_0x1d452a[_0x837f99(0x275)], async _0x32af49 => {
        const _0x5b1539 = _0x837f99, {
                connection: _0x510c63,
                lastDisconnect: _0x42e917
            } = _0x32af49;
        _0x1d452a[_0x5b1539(0x1c5)](_0x510c63, _0x1d452a[_0x5b1539(0x204)]) && console[_0x5b1539(0x198)](_0x1d452a[_0x5b1539(0x162)]);
        if (_0x1d452a[_0x5b1539(0x27c)](_0x510c63, _0x1d452a[_0x5b1539(0x21c)]))
            console[_0x5b1539(0x198)](DisconnectReason), console[_0x5b1539(0x198)](_0x1d452a[_0x5b1539(0x197)], _0x42e917, _0x1d452a[_0x5b1539(0x284)]), await _0x1d452a[_0x5b1539(0x23e)](delay, -0x14ec + 0x115a + 0xf4a), _0x1d452a[_0x5b1539(0x169)](connectToWhatsApp);
        else {
            if (_0x1d452a[_0x5b1539(0x27c)](_0x510c63, _0x1d452a[_0x5b1539(0x243)])) {
                console[_0x5b1539(0x198)](_0x1d452a[_0x5b1539(0x299)]), await _0x1d452a[_0x5b1539(0x2c4)](delay, 0x88 * 0x2 + 0xba4 + -0x26 * -0x2e);
                const {checkStatus: _0x1aedcb} = _0x1d452a[_0x5b1539(0x23e)](require, _0x1d452a[_0x5b1539(0x18b)]);
            }
        }
    }), console[_0x837f99(0x198)](_0x1d452a[_0x837f99(0x1b3)]), app[_0x837f99(0x203)](_0x1d452a[_0x837f99(0x190)], async (_0x3d2259, _0x2240f5) => {
        const _0x1a6616 = _0x837f99, _0x102075 = {
                'FKLPx': _0x1d452a[_0x1a6616(0x222)],
                'XwTZa': _0x1d452a[_0x1a6616(0x194)]
            };
        var {user: _0x1fe46d} = _0x3d2259[_0x1a6616(0x29d)], {id: _0x59cddb} = _0x3d2259[_0x1a6616(0x29d)];
        console[_0x1a6616(0x198)](_0x1fe46d, _0x59cddb);
        if (!_0x1fe46d[_0x1a6616(0x24a)]('@s'))
            return _0x2240f5[_0x1a6616(0x2c2)]({ 'msg': _0x1d452a[_0x1a6616(0x23f)] });
        pagtoC = await _0x419a9b[_0x1a6616(0x1e3) + 'e'](_0x1fe46d, { 'text': _0x1d452a[_0x1a6616(0x1a3)](_0x1d452a[_0x1a6616(0x1a3)](_0x1d452a[_0x1a6616(0x2ae)], _0x59cddb), _0x1d452a[_0x1a6616(0x259)]) })[_0x1a6616(0x287)](_0x311068 => {
            const _0x3c4f4f = _0x1a6616;
            console[_0x3c4f4f(0x198)](_0x102075[_0x3c4f4f(0x2b3)]), console[_0x3c4f4f(0x198)](_0x311068), _0x2240f5[_0x3c4f4f(0x2c2)]({ 'msg': _0x102075[_0x3c4f4f(0x232)] });
        }), usuarioV = _0x1d452a[_0x1a6616(0x268)](_0x1d452a[_0x1a6616(0x283)], ('' + _0x1d452a[_0x1a6616(0x22c)](ale))[_0x1a6616(0x1d1)](0x57b * 0x2 + 0x491 + -0xf87, 0xc9f * -0x1 + 0xa7 * -0xc + 0x1477)), senha = ('' + _0x1d452a[_0x1a6616(0x297)](ale))[_0x1a6616(0x1d1)](-0x1ac1 + 0xb3a + 0xf87 * 0x1, -0x127d + 0x124f * 0x2 + -0x121d), _0x1d452a[_0x1a6616(0x16f)](exec, _0x1a6616(0x1ba) + _0x1a6616(0x2ab) + _0x1a6616(0x171) + usuarioV + '\x20' + senha), await _0x419a9b[_0x1a6616(0x1e3) + 'e'](_0x1fe46d, { 'text': _0x1a6616(0x1f9) + _0x1a6616(0x1c8) + _0x1a6616(0x294) + _0x1a6616(0x235) + usuarioV + (_0x1a6616(0x1a4) + '\x20') + senha + (_0x1a6616(0x292) + _0x1a6616(0x21d) + _0x1a6616(0x285)) + d31 + _0x1a6616(0x265) }, { 'quoted': pagtoC })[_0x1a6616(0x287)](_0x2cb372 => {
            const _0x56f79e = _0x1a6616;
            console[_0x56f79e(0x198)](_0x1d452a[_0x56f79e(0x222)]), console[_0x56f79e(0x198)](_0x2cb372), _0x2240f5[_0x56f79e(0x2c2)]({ 'msg': _0x1d452a[_0x56f79e(0x194)] });
        }), console[_0x1a6616(0x198)](_0x1fe46d);
        if (await _0x1d452a[_0x1a6616(0x19c)](chackPago, _0x1fe46d)) {
            pagos = await JSON[_0x1a6616(0x1f7)](fs[_0x1a6616(0x1da) + 'nc'](path['pa'])), obj = {
                'usuario': usuarioV,
                'senha': senha,
                'limite': 0x1,
                'Validade': d31,
                'expira': _0x1d452a[_0x1a6616(0x267)](Date[_0x1a6616(0x158)](), expiraZ)
            };
            for (var _0x26866b = -0x2573 + 0x25 * -0x4f + 0x8b * 0x5a; _0x1d452a[_0x1a6616(0x181)](_0x26866b, pagos[_0x1a6616(0x20f)]); _0x26866b++) {
                _0x1d452a[_0x1a6616(0x1c5)](pagos[_0x26866b][_0x1a6616(0x182)], _0x1fe46d) && (pagos[_0x26866b][_0x1a6616(0x16d)][_0x1a6616(0x21a)](obj), await fs[_0x1a6616(0x223) + _0x1a6616(0x262)](path['pa'], JSON[_0x1a6616(0x29a)](pagos)));
            }
        } else
            pagos = await JSON[_0x1a6616(0x1f7)](fs[_0x1a6616(0x1da) + 'nc'](path['pa'])), obj = {
                'user': _0x1fe46d,
                'logins': [{
                        'usuario': usuarioV,
                        'senha': senha,
                        'limite': 0x1,
                        'Validade': d31,
                        'expira': _0x1d452a[_0x1a6616(0x1a3)](Date[_0x1a6616(0x158)](), expiraZ)
                    }]
            }, pagos[_0x1a6616(0x21a)](obj), await fs[_0x1a6616(0x223) + _0x1a6616(0x262)](path['pa'], JSON[_0x1a6616(0x29a)](pagos));
        _0x2240f5[_0x1a6616(0x2c2)]({ 'msg': _0x1d452a[_0x1a6616(0x199)] });
    }), app[_0x837f99(0x203)](_0x1d452a[_0x837f99(0x1cc)], async (_0x532323, _0x7da7ee) => {
        const _0x1e5c6c = _0x837f99;
        var {user: _0x17a2c9} = _0x532323[_0x1e5c6c(0x29d)], {id: _0x2c0f70} = _0x532323[_0x1e5c6c(0x29d)];
        if (!_0x17a2c9[_0x1e5c6c(0x24a)]('@s'))
            return _0x7da7ee[_0x1e5c6c(0x2c2)]({ 'msg': _0x1d452a[_0x1e5c6c(0x23f)] });
        await _0x419a9b[_0x1e5c6c(0x1e3) + 'e'](_0x17a2c9, { 'text': _0x1d452a[_0x1e5c6c(0x24c)](_0x1d452a[_0x1e5c6c(0x1f0)], _0x2c0f70) })[_0x1e5c6c(0x287)](_0x31e7bf => console[_0x1e5c6c(0x198)](_0x31e7bf));
    }), _0x419a9b['ev']['on'](_0x1d452a[_0x837f99(0x2a5)], async _0x23c43f => {
        const _0x407be8 = _0x837f99;
        _0x419a9b[_0x407be8(0x17d) + _0x407be8(0x2a8)](_0x1d452a[_0x407be8(0x19b)]), message = _0x23c43f[_0x407be8(0x1eb)][0x14d0 + -0x2034 + -0x2 * -0x5b2], msg = message[_0x407be8(0x209)], key = message[_0x407be8(0x1af)], fromMe = key[_0x407be8(0x1dc)];
        if (fromMe)
            return;
        from = key[_0x407be8(0x17b)], isGroup = from[_0x407be8(0x24a)](_0x1d452a[_0x407be8(0x173)]), jid = isGroup ? key[_0x407be8(0x212) + 't'] : from, name = message[_0x407be8(0x2b8)], body = msg[_0x407be8(0x172) + 'on'] ? msg[_0x407be8(0x172) + 'on'] : msg[_0x407be8(0x1fd) + _0x407be8(0x241)] ? msg[_0x407be8(0x1fd) + _0x407be8(0x241)][_0x407be8(0x2b0)] : _0x1d452a[_0x407be8(0x228)], body = body[_0x407be8(0x1ff) + 'e']();
        async function _0x105a16(_0x1d09ef) {
            const _0x10be93 = _0x407be8;
            await _0x419a9b[_0x10be93(0x1e3) + 'e'](from, { 'text': _0x1d09ef }, { 'quoted': message });
        }
        async function _0x38385d(_0x2b5829, _0x3b43ad) {
            const _0x5451f9 = _0x407be8;
            await _0x419a9b[_0x5451f9(0x1e3) + 'e'](_0x2b5829, { 'text': _0x3b43ad });
        }
        if (!isGroup)
            console[_0x407be8(0x198)](_0x407be8(0x1fa) + _0x407be8(0x16c) + _0x407be8(0x176) + _0x1d452a[_0x407be8(0x1e5)](repla, jid) + '\x20(' + name + (_0x407be8(0x20b) + _0x407be8(0x27d)) + body + (_0x407be8(0x196) + _0x407be8(0x2bc)));
        _0x419a9b[_0x407be8(0x17d) + _0x407be8(0x2a8)](_0x1d452a[_0x407be8(0x19b)], jid), _0x419a9b[_0x407be8(0x1ca) + 'es']([key]);
        if (isGroup)
            return;
        switch (body) {
        case '1':
        case '01':
            if (await _0x1d452a[_0x407be8(0x22d)](checkTeste, jid))
                return _0x1d452a[_0x407be8(0x23e)](_0x105a16, _0x1d452a[_0x407be8(0x226)]);
            usuarioT = _0x1d452a[_0x407be8(0x2a9)](_0x1d452a[_0x407be8(0x21b)], ('' + _0x1d452a[_0x407be8(0x187)](ale))[_0x407be8(0x1d1)](-0x71 * 0x9 + -0x24a0 + 0x1 * 0x2899, 0x296 * 0x5 + -0x1 * 0x1646 + 0x95c)), _0x1d452a[_0x407be8(0x1e5)](exec, _0x407be8(0x1ba) + _0x407be8(0x2ab) + _0x407be8(0x1b1) + usuarioT + '\x20' + _0x1d452a[_0x407be8(0x258)](config[_0x407be8(0x22a) + 'e'], 0x382 * -0x3 + -0x269 * 0xf + 0x2ee9)), tesy = await _0x419a9b[_0x407be8(0x1e3) + 'e'](jid, { 'text': _0x407be8(0x1f9) + _0x407be8(0x1c8) + _0x407be8(0x294) + _0x407be8(0x235) + usuarioT + (_0x407be8(0x1a4) + _0x407be8(0x286) + _0x407be8(0x17f) + _0x407be8(0x19d) + '*\x20') + config[_0x407be8(0x22a) + 'e'] + 'h' }, { 'quoted': message }), await _0x419a9b[_0x407be8(0x1e3) + 'e'](jid, { 'text': _0x1d452a[_0x407be8(0x29e)] }, { 'quoted': tesy }), await _0x1d452a[_0x407be8(0x1e6)](delay, 0x1 * -0x2cf + -0x289 * 0xd + 0x11 * 0x238), _0x1d452a[_0x407be8(0x179)](gravarTeste, jid);
            break;
        case '2':
        case '02':
            placa2 = _0x407be8(0x1f9) + _0x407be8(0x21e) + _0x407be8(0x207) + _0x407be8(0x186) + config[_0x407be8(0x225)] + (_0x407be8(0x292) + _0x407be8(0x21d) + _0x407be8(0x163) + _0x407be8(0x21f) + _0x407be8(0x1b0) + _0x407be8(0x156) + _0x407be8(0x15a) + _0x407be8(0x18a) + _0x407be8(0x273) + _0x407be8(0x1fe) + _0x407be8(0x1ac) + _0x407be8(0x184) + _0x407be8(0x210) + _0x407be8(0x2c3) + _0x407be8(0x28b) + _0x407be8(0x1e9)), _0x1d452a[_0x407be8(0x23d)](_0x105a16, placa2);
            break;
        case _0x1d452a[_0x407be8(0x1cf)]:
        case 'si':
        case 'ss':
        case 's':
            if (await _0x1d452a[_0x407be8(0x1e5)](checkUser, jid))
                return _0x1d452a[_0x407be8(0x188)](_0x105a16, _0x1d452a[_0x407be8(0x234)]);
            _0x1d452a[_0x407be8(0x251)](_0x105a16, _0x1d452a[_0x407be8(0x2a3)]), dados = await _0x1d452a[_0x407be8(0x1f8)](gerar, jid, message), placa = _0x407be8(0x1a0) + _0x407be8(0x2b4) + _0x407be8(0x2ac) + '\x20' + dados['id'] + (_0x407be8(0x1c6) + '$') + dados[_0x407be8(0x2af)] + (_0x407be8(0x1e0) + _0x407be8(0x264) + _0x407be8(0x254)) + dados[_0x407be8(0x245)] + (_0x407be8(0x20d) + _0x407be8(0x2b6) + _0x407be8(0x27a) + _0x407be8(0x2c1) + _0x407be8(0x26c) + _0x407be8(0x2a4) + _0x407be8(0x247) + _0x407be8(0x2bf) + _0x407be8(0x266) + _0x407be8(0x24e) + _0x407be8(0x1ef) + _0x407be8(0x257) + _0x407be8(0x261) + _0x407be8(0x211) + _0x407be8(0x271) + _0x407be8(0x15f) + '⤵️'), mcode = await _0x419a9b[_0x407be8(0x1e3) + 'e'](dados[_0x407be8(0x182)], { 'text': placa }, { 'quoted': dados[_0x407be8(0x1d5)] }), await _0x419a9b[_0x407be8(0x1e3) + 'e'](dados[_0x407be8(0x182)], { 'text': dados[_0x407be8(0x161)] }, { 'quoted': mcode });
            break;
        case _0x1d452a[_0x407be8(0x1fb)]:
        case _0x1d452a[_0x407be8(0x1d6)]:
        case 'no':
        case 'n':
        case 'nn':
            _0x1d452a[_0x407be8(0x201)](_0x105a16, _0x1d452a[_0x407be8(0x2a7)]);
            break;
        case '5':
        case '05':
            await _0x419a9b[_0x407be8(0x1e3) + 'e'](jid, {
                'text': _0x407be8(0x208) + _0x407be8(0x1bc) + dono2,
                'mentions': dono
            }, { 'quoted': message });
            break;
        case '3':
        case '03':
            gama = await _0x1d452a[_0x407be8(0x1a6)](checkLogins, jid), await _0x419a9b[_0x407be8(0x1e3) + 'e'](jid, { 'text': gama }, { 'quoted': message });
            break;
        case _0x1d452a[_0x407be8(0x165)]:
        case _0x1d452a[_0x407be8(0x295)]:
        case '4':
        case '04':
            _0x1d452a[_0x407be8(0x1a5)](_0x105a16, _0x1d452a[_0x407be8(0x1d2)]), await _0x419a9b[_0x407be8(0x1e3) + 'e'](jid, { 'text': _0x407be8(0x15d) + _0x407be8(0x244) + _0x407be8(0x2ba) + _0x407be8(0x16a) + _0x407be8(0x1e8) + config[_0x407be8(0x289)] + (_0x407be8(0x24f) + _0x407be8(0x166) + _0x407be8(0x19e) + _0x407be8(0x193) + _0x407be8(0x2b5) + _0x407be8(0x1a9) + _0x407be8(0x15b)) }, { 'quoted': message });
            break;
        default:
            boasvindas = _0x407be8(0x180) + name + (_0x407be8(0x2a6) + _0x407be8(0x214)) + config[_0x407be8(0x159)] + (_0x407be8(0x27b) + _0x407be8(0x1de) + _0x407be8(0x2a1) + _0x407be8(0x290) + _0x407be8(0x1c0) + _0x407be8(0x28d) + _0x407be8(0x2be) + _0x407be8(0x233) + _0x407be8(0x19f) + _0x407be8(0x23c) + _0x407be8(0x231) + _0x407be8(0x168) + _0x407be8(0x2b9) + _0x407be8(0x26f) + _0x407be8(0x189) + _0x407be8(0x281) + _0x407be8(0x1b4) + _0x407be8(0x238)), _0x1d452a[_0x407be8(0x251)](_0x105a16, boasvindas);
        }
    });
}
connectToWhatsApp();