const _0x5cb603 = _0x181e;
function _0x181e(_0xe71b81, _0x29ee10) {
    const _0x3062b0 = _0x3aae();
    return _0x181e = function (_0x48ddf0, _0xb1e9de) {
        _0x48ddf0 = _0x48ddf0 - (-0x6 * -0x4f + 0xcc0 + -0xe30);
        let _0x34021d = _0x3062b0[_0x48ddf0];
        return _0x34021d;
    }, _0x181e(_0xe71b81, _0x29ee10);
}
(function (_0x3c8a1, _0x2ec4a9) {
    const _0x38a769 = _0x181e, _0x10f90c = _0x3c8a1();
    while (!![]) {
        try {
            const _0xdae4ee = -parseInt(_0x38a769(0x156)) / (0x7bf + 0x4cb * 0x6 + -0x2480) * (parseInt(_0x38a769(0x146)) / (-0x412 + 0x252 + 0xf * 0x1e)) + parseInt(_0x38a769(0x187)) / (0xc * -0x29f + 0x1b8c + 0x3eb) * (-parseInt(_0x38a769(0xf9)) / (-0x2 * 0x3d + 0x49e + -0x420)) + -parseInt(_0x38a769(0xe3)) / (-0x1 * 0x1cd1 + 0xb8f + 0x1147) * (-parseInt(_0x38a769(0x88)) / (0x1d69 + 0x3 * -0xc7a + 0x47 * 0x1d)) + -parseInt(_0x38a769(0x177)) / (-0x24f7 * -0x1 + -0x1 * 0x2657 + -0x167 * -0x1) + -parseInt(_0x38a769(0x10b)) / (0x7 * 0x2e + -0x10ed + 0xfb3) + -parseInt(_0x38a769(0x1a5)) / (-0x8 * -0x305 + 0x98b + -0x1 * 0x21aa) * (parseInt(_0x38a769(0x18f)) / (0x3 * -0xbfe + -0x22b5 * -0x1 + 0x5 * 0x43)) + -parseInt(_0x38a769(0xf4)) / (-0x22cd + 0x76 * -0x28 + 0x3548) * (-parseInt(_0x38a769(0xae)) / (-0x10d * 0x17 + -0xbd3 + 0x240a));
            if (_0xdae4ee === _0x2ec4a9)
                break;
            else
                _0x10f90c['push'](_0x10f90c['shift']());
        } catch (_0xfcae50) {
            _0x10f90c['push'](_0x10f90c['shift']());
        }
    }
}(_0x3aae, 0x2c41b + -0x79694 + -0x105a4b * -0x1));
const {
        default: makeWASocket,
        delay,
        DisconnectReason,
        BufferJSON,
        useMultiFileAuthState
    } = require(_0x5cb603(0x7b) + _0x5cb603(0x7a) + _0x5cb603(0x195)), {Boom} = require(_0x5cb603(0x90)), P = require(_0x5cb603(0xef)), {exec} = require(_0x5cb603(0xf3) + _0x5cb603(0x166)), express = require(_0x5cb603(0x174)), {gerar} = require(_0x5cb603(0x145) + _0x5cb603(0x19a) + _0x5cb603(0x14a)), app = express(), moment = require(_0x5cb603(0xc4) + _0x5cb603(0x148)), fs = require(_0x5cb603(0x153)), ms = require('ms'), pms = require(_0x5cb603(0xde)), {config} = require(_0x5cb603(0x14b) + 'ig');
time = ms('1d'), expiraZ = ms(_0x5cb603(0xb0)), d31 = moment['tz'](_0x5cb603(0xa9) + _0x5cb603(0x1b2))[_0x5cb603(0x173)](0x392 + 0x6d * -0x52 + -0x3 * -0xa7d, 'd')[_0x5cb603(0x125)](_0x5cb603(0xe5)), app[_0x5cb603(0x8f)](0x965 * -0x4 + -0x775 * 0x6 + 0x36d5 * 0x2), dono = [config[_0x5cb603(0xc1)] + (_0x5cb603(0xed) + _0x5cb603(0xd1))], dono2 = '' + config[_0x5cb603(0xc1)], path = {
    'p': _0x5cb603(0x145) + _0x5cb603(0xf1) + _0x5cb603(0x12f) + 'n',
    't': _0x5cb603(0x145) + _0x5cb603(0x126) + _0x5cb603(0x167),
    'pa': _0x5cb603(0x145) + _0x5cb603(0xf1) + _0x5cb603(0x105)
};
async function checkUser(_0x4e04ee) {
    const _0x56eb33 = _0x5cb603, _0x193992 = {
            'kJalw': function (_0x2e7293, _0x3b2b61) {
                return _0x2e7293 < _0x3b2b61;
            },
            'hUfxq': function (_0x129205, _0x4b3d10) {
                return _0x129205 == _0x4b3d10;
            }
        };
    pedidos = await JSON[_0x56eb33(0x75)](fs[_0x56eb33(0xda) + 'nc'](path['p']));
    for (var _0x35ee82 = -0x133d + 0x7 * -0x221 + 0x2224; _0x193992[_0x56eb33(0xc3)](_0x35ee82, pedidos[_0x56eb33(0x122)]); _0x35ee82++) {
        if (_0x193992[_0x56eb33(0x124)](pedidos[_0x35ee82][_0x56eb33(0x137)], _0x4e04ee))
            return !![];
    }
    return ![];
}
async function checkTeste(_0x20e281) {
    const _0x483fc1 = _0x5cb603, _0xe941b3 = {
            'geWCb': function (_0x392e07, _0x53e4b9) {
                return _0x392e07 < _0x53e4b9;
            },
            'CNdoh': function (_0x1fb7eb, _0x24b745) {
                return _0x1fb7eb == _0x24b745;
            },
            'lADcm': function (_0x3a0317, _0xb4e508) {
                return _0x3a0317 > _0xb4e508;
            }
        };
    testes = await JSON[_0x483fc1(0x75)](fs[_0x483fc1(0xda) + 'nc'](path['t'])), testes = await JSON[_0x483fc1(0x75)](fs[_0x483fc1(0xda) + 'nc'](path['t']));
    for (var _0x1fc3cd = 0xb5b + -0x5f7 * -0x5 + -0x292e; _0xe941b3[_0x483fc1(0x9e)](_0x1fc3cd, testes[_0x483fc1(0x122)]); _0x1fc3cd++) {
        if (_0xe941b3[_0x483fc1(0x1a1)](testes[_0x1fc3cd][_0x483fc1(0x137)], _0x20e281)) {
            if (_0xe941b3[_0x483fc1(0x9e)](Date[_0x483fc1(0x102)](), testes[_0x1fc3cd][_0x483fc1(0x189)]))
                return !![];
            if (_0xe941b3[_0x483fc1(0x183)](Date[_0x483fc1(0x102)](), testes[_0x1fc3cd][_0x483fc1(0x189)]))
                return testes[_0x483fc1(0x1a4)](_0x1fc3cd, 0x2656 + -0x3e * 0x95 + -0x23f), await fs[_0x483fc1(0xa6) + _0x483fc1(0x1c5)](path['t'], JSON[_0x483fc1(0x8b)](testes)), ![];
        }
    }
    return ![];
}
async function gravarTeste(_0x1bff30) {
    const _0x4ca55f = _0x5cb603, _0x4eba99 = {
            'yFGKF': function (_0x39b1a9, _0x57541a) {
                return _0x39b1a9 + _0x57541a;
            }
        };
    testes = await JSON[_0x4ca55f(0x75)](fs[_0x4ca55f(0xda) + 'nc'](path['t'])), obj = {
        'user': _0x1bff30,
        'expira': _0x4eba99[_0x4ca55f(0x178)](Date[_0x4ca55f(0x102)](), time)
    }, testes[_0x4ca55f(0x6d)](obj), await fs[_0x4ca55f(0xa6) + _0x4ca55f(0x1c5)](path['t'], JSON[_0x4ca55f(0x8b)](testes));
}
function ale() {
    const _0x37664f = _0x5cb603, _0x53b559 = {
            'dKaFr': function (_0x358056, _0x534943) {
                return _0x358056 * _0x534943;
            },
            'KbKfZ': function (_0x3eb4ac, _0x143cd4) {
                return _0x3eb4ac + _0x143cd4;
            }
        };
    return i = 0x8ac7230489e80000, Math[_0x37664f(0x129)](_0x53b559[_0x37664f(0x176)](Math[_0x37664f(0x1b0)](), _0x53b559[_0x37664f(0x109)](i, -0x1990 + 0x25 * -0x45 + 0x238a * 0x1)));
}
function _0x3aae() {
    const _0xd00c2f = [
        '\x0a*📲Limite:',
        'Olá\x20',
        'senha',
        'OPmwb',
        '!*\x20Fique\x20a',
        'CONECTADO\x20',
        'participan',
        'fs-extra',
        'sendMessag',
        'usuario',
        '9wqZvZn',
        'HfSny',
        'le\x20expirar',
        'Aproveite\x20',
        'fromMe',
        '.update',
        'ste.sh\x20',
        'valor',
        'uário:*\x20',
        'json',
        'rou\x20um\x20tes',
        'ndo(a)\x20a\x20*',
        'IBNqb',
        '/app',
        'ePuTN',
        'venceu',
        'ess',
        'estes.json',
        'dido',
        'Você\x20não\x20t',
        'n\x2030\x20dias\x20',
        'split',
        'remoteJid',
        'pushName',
        'em\x20logins\x20',
        'te\x20hoje,\x20s',
        'morar\x20cerc',
        '\x20assim\x20que',
        'COM\x20SUCESS',
        'add',
        'express',
        'PEhqO',
        'dKaFr',
        '4375511maliLM',
        'yFGKF',
        'Gerando\x20Qr',
        'm\x20pedido\x20e',
        'ijusG',
        'das\x20opções',
        'dias\x0a\x0a📌Sem',
        'ZgLOd',
        'nXNBY',
        'YIRfr',
        'wpHBb',
        'query',
        'lADcm',
        '7|2|4|5|6|',
        'chada\x20por:',
        'ogins\x20🔍\x0a*[',
        '3nFJMNd',
        'te\x20👤',
        'expira',
        'cAYQg',
        '\x20o\x20comando',
        'TTyxA',
        'ando...',
        '*•Informaç',
        '10fXGzRw',
        'yxEjZ',
        'às\x20*',
        'DyyaD',
        'midia',
        'link\x20não\x20e',
        'eys',
        '/pago',
        'open',
        'a\x20de\x201\x20min',
        'NPMhY',
        'bot/src/ge',
        '🆔Id:\x20',
        'teste',
        'Conexão\x20fe',
        'vCEnc',
        'connecting',
        'indexOf',
        'CNdoh',
        '):\x0a\x0aMensag',
        'r\x20outro\x20pe',
        'splice',
        '3180582yirpLB',
        '\x0a⌛Expira\x20e',
        'nao',
        '\x20do\x20link\x20a',
        'prar!\x0aPara',
        'toLowerCas',
        'qzlmQ',
        'Aguarde...',
        'lia)_\x0a\x0a📌Se',
        'jNNAn',
        'bDwcV',
        'random',
        'creds.upda',
        'o_Paulo',
        'e\x20meu\x20cont',
        'eHwBG',
        'HDOwQ',
        'zoWDx',
        'id:\x20',
        'code...',
        'IHUnw',
        'dade:*\x2030\x20',
        'pre\x20faça\x20u',
        'slice',
        'XdZFx',
        '\x0a\x0a########',
        '\x20no\x20privad',
        '*\x20_(horári',
        'hTyLb',
        'in•*\x0a\x0a*👤Us',
        'm\x20teste\x20an',
        '05]*\x20Supor',
        'ync',
        'conversati',
        'steja\x20clic',
        '\x0a/app\x0a\x0aDes',
        'e:*\x20',
        'tempo_test',
        'available',
        'days',
        'dade:*\x20',
        '⌛Validade:',
        'hora',
        'push',
        '\x0a*⌛Validad',
        'kMsUb',
        'er.sh\x20',
        'includes',
        '\x20confirmad',
        'u\x20*Não*',
        'CQgNo',
        'parse',
        'ento\x20for\x20i',
        '\x20seu\x20pagam',
        'r?\x20*Sim*\x20o',
        'silent',
        'ckets/bail',
        '@whiskeyso',
        'mprar\x20logi',
        '*☎️Suporte*',
        'qcUfw',
        'es\x20do\x20Qrco',
        '\x20dias',
        'u\x20espere\x20e',
        '@g.us',
        'OLWOK',
        '========',
        'fZomY',
        'WCrGw',
        'NsdUr',
        '18852XmiYfb',
        'o,\x20pague\x20o',
        'nKCPB',
        'stringify',
        '*Qrcode\x20ex',
        'Você\x20já\x20ge',
        'em:\x20',
        'listen',
        '@hapi/boom',
        'oWCBo',
        'pp,\x20digite',
        'fAbNk',
        'WLSdt',
        'HUNje',
        '*[01]*\x20Ger',
        'u\x20login\x20se',
        'bot/login',
        'jEeMK',
        'messages',
        'get',
        'Abrindo\x20na',
        'Você\x20tem\x20*',
        'geWCb',
        'msgkey',
        'ões\x20do\x20pro',
        'pp\x20através',
        'e\x20ficará',
        'ceUpdate',
        'aEhxu',
        'Você\x20tem\x20u',
        'writeFileS',
        'ara\x20escolh',
        '8|1|0|3',
        'America/Sa',
        '\x20obter\x20o\x20a',
        '####',
        'uto.\x0a\x0a_Qrc',
        '\x201234\x0a*📲Li',
        '41634828YYBgip',
        'bot/src/us',
        '31d',
        'sar\x20é\x20só\x20m',
        'log',
        'xtMessage',
        '\x0a\x0a📌Caso\x20o\x20',
        'key',
        '\x0a\x0aMensagem',
        '\x0a*[02]*\x20Co',
        'm:\x2010\x20min\x0a',
        'sim',
        'valorLogin',
        'app',
        'HEyoQ',
        'eja\x20compra',
        'fSWJp',
        'messages.u',
        'ste\x20🔥',
        'dono',
        'er\x20alguma\x20',
        'kJalw',
        'moment-tim',
        'Pagamento\x20',
        'AUcVS',
        '\x20para\x20faze',
        'hqgUl',
        'ões\x20do\x20log',
        'catch',
        'bad\x20reques',
        '*\x20login\x27s\x20',
        '📆\x0a*[03]*\x20V',
        'o\x20de\x20Brasí',
        'dentificad',
        ',\x20Reconect',
        'p.net',
        'seiYl',
        'de:*\x0a\x0a🆔Id:',
        'text',
        'elsxY',
        'PRCbD',
        'SjjUB',
        '...',
        'bot/src/te',
        'readFileSy',
        'o\x20de\x20',
        'tes\x20de\x20com',
        'o:*\x20',
        'parse-ms',
        'Premium',
        'GNKZK',
        '\x20abaixo:\x0a\x0a',
        'e\x20chamar!\x20',
        '755AjfnBE',
        'ativo\x20📱\x0a*[',
        'DD/MM/yyyy',
        'Valor:*\x20R$',
        'readMessag',
        'Faça\x20o\x20dow',
        'ó\x20poderá\x20g',
        'connection',
        'limite',
        'o\x20abaixo_\x20',
        '@s.whatsap',
        'vegador...',
        'pino',
        '\x0a\x0a🆔@',
        'bot/data/p',
        'linkApp',
        'child_proc',
        '11MYWZGp',
        'yntLr',
        'erificar\x20L',
        'deu\x20erro',
        'XFled',
        '5001172CGbMQj',
        '*Informaçõ',
        'mite:*\x201\x0a*',
        'o,\x20pode\x20de',
        'lhVnb',
        'e\x20cola\x20log',
        'owIHX',
        'hUdZs',
        'ZyvyL',
        'now',
        'DRaaF',
        'Tudo\x20certo',
        'agos.json',
        'message',
        'sendPresen',
        'kbsPY',
        'KbKfZ',
        '\x20(31\x20dias)',
        '2930336LdCUfV',
        'GdchY',
        '\x0a🏷️Valor:\x20R',
        'URECA',
        'ato\x20que\x20el',
        'duto•*\x0a\x0a*🏷️',
        'extendedTe',
        'keFXH',
        'psert',
        'Validade',
        'Conectando',
        '\x20abaixo\x20⤵️\x0a',
        '\x0a\x0a*👤Usuári',
        'logins',
        'joncG',
        'ode\x20copia\x20',
        '!\x20Se\x20preci',
        'baixo⤵️\x0a\x0a',
        'nload\x20do\x20a',
        'sucess',
        'lvdwi',
        'não',
        'dmviG',
        'length',
        'hbsPL',
        'hUfxq',
        'format',
        'bot/data/t',
        '\x20vontade\x20p',
        'qrcode',
        'floor',
        'rá\x20enviado',
        'riYSz',
        '/cancel',
        'ar\x20teste\x20⌛',
        'ygKAD',
        'edidos.jso',
        '04]*\x20Aplic',
        'nomeLoja',
        'erar\x20outro',
        'AdsVZ',
        '\x20😃,\x20Bem\x20vi',
        'pirado:*\x0a\x0a',
        'bot/src/ve',
        'user',
        'close',
        'ZZaFX',
        'error',
        '\x0a*🔐Senha:*',
        'nTcUc',
        '\x20em\x2024h',
        'ppyRO',
        'ável,\x20salv',
        ')\x0a\x0a=======',
        'QTmtK',
        'm\x20andament',
        'bem\x20seu\x20te',
        'aUTlc',
        '/etc/megah',
        '131842sjFCBc',
        'OTrqc',
        'ezone',
        '*\x201\x0a*⌛Vali',
        'rar',
        '/root/conf'
    ];
    _0x3aae = function () {
        return _0xd00c2f;
    };
    return _0x3aae();
}
function repla(_0x26df8b) {
    const _0x321528 = _0x5cb603;
    return i = _0x26df8b[_0x321528(0x1a0)]('@'), _0x26df8b[_0x321528(0x1bc)](-0x1229 * 0x1 + -0xd * -0x10d + 0x480, i);
}
async function chackPago(_0x47652f) {
    const _0x34461a = _0x5cb603, _0x5a64e4 = {
            'aEhxu': function (_0x3a6e3a, _0x399956) {
                return _0x3a6e3a < _0x399956;
            },
            'ePuTN': function (_0x33002d, _0x4b360e) {
                return _0x33002d == _0x4b360e;
            }
        };
    pagos = await JSON[_0x34461a(0x75)](fs[_0x34461a(0xda) + 'nc'](path['pa']));
    for (var _0x17d067 = -0x1 * -0x1bbf + -0x592 + -0x162d; _0x5a64e4[_0x34461a(0xa4)](_0x17d067, pagos[_0x34461a(0x122)]); _0x17d067++) {
        if (_0x5a64e4[_0x34461a(0x164)](pagos[_0x17d067][_0x34461a(0x137)], _0x47652f))
            return !![];
    }
    return ![];
}
async function checkLogins(_0x1d8fb0) {
    const _0x312a4a = _0x5cb603, _0x30c857 = {
            'fZomY': function (_0x56555f, _0x70e4cc) {
                return _0x56555f < _0x70e4cc;
            },
            'jNNAn': function (_0xc6cf66, _0x3d3d58) {
                return _0xc6cf66 == _0x3d3d58;
            },
            'owIHX': _0x312a4a(0x184) + _0x312a4a(0xa8),
            'ijusG': function (_0x410ef2, _0xee8686) {
                return _0x410ef2 > _0xee8686;
            },
            'qcUfw': _0x312a4a(0x165),
            'riYSz': function (_0x2b908e, _0x13165a) {
                return _0x2b908e + _0x13165a;
            },
            'OTrqc': function (_0x2f5225, _0x53354d) {
                return _0x2f5225(_0x53354d);
            },
            'IBNqb': function (_0x592c67, _0x5cb633) {
                return _0x592c67 - _0x5cb633;
            },
            'PRCbD': _0x312a4a(0x80),
            'kbsPY': _0x312a4a(0x169) + _0x312a4a(0x16e) + _0x312a4a(0xdf)
        };
    pagos = await JSON[_0x312a4a(0x75)](fs[_0x312a4a(0xda) + 'nc'](path['pa']));
    for (var _0x477359 = -0x2c7 + -0x2393 + 0x265a; _0x30c857[_0x312a4a(0x85)](_0x477359, pagos[_0x312a4a(0x122)]); _0x477359++) {
        if (_0x30c857[_0x312a4a(0x1ae)](pagos[_0x477359][_0x312a4a(0x137)], _0x1d8fb0)) {
            logins = pagos[_0x477359][_0x312a4a(0x118)], quanti = logins[_0x312a4a(0x122)], tesk = _0x312a4a(0x9d) + '0' + quanti + (_0x312a4a(0xcc) + _0x312a4a(0xdf));
            for (var _0x477359 = -0x1dec + 0x4 * -0x7b9 + 0x3cd0; _0x30c857[_0x312a4a(0x85)](_0x477359, logins[_0x312a4a(0x122)]); _0x477359++) {
                const _0x1998b2 = _0x30c857[_0x312a4a(0xff)][_0x312a4a(0x16b)]('|');
                let _0x15115d = 0x1 * 0xdff + 0x1d4 * -0x4 + -0x6af;
                while (!![]) {
                    switch (_0x1998b2[_0x15115d++]) {
                    case '0':
                        if (_0x30c857[_0x312a4a(0x17b)](Date[_0x312a4a(0x102)](), exp))
                            exp = _0x30c857[_0x312a4a(0x7e)];
                        continue;
                    case '1':
                        exps = logins[_0x477359][_0x312a4a(0x189)];
                        continue;
                    case '2':
                        sen = logins[_0x477359][_0x312a4a(0x14e)];
                        continue;
                    case '3':
                        tesk = _0x30c857[_0x312a4a(0x12b)](tesk, _0x312a4a(0x117) + _0x312a4a(0xdd) + usu + (_0x312a4a(0x13b) + '\x20') + sen + (_0x312a4a(0x14c) + '*\x20') + limi + (_0x312a4a(0x6e) + _0x312a4a(0x1c9)) + vali + '\x20(' + exp + (_0x312a4a(0x140) + _0x312a4a(0x84)));
                        continue;
                    case '4':
                        limi = logins[_0x477359][_0x312a4a(0xeb)];
                        continue;
                    case '5':
                        vali = logins[_0x477359][_0x312a4a(0x114)];
                        continue;
                    case '6':
                        exp = _0x30c857[_0x312a4a(0x147)](pms, _0x30c857[_0x312a4a(0x162)](logins[_0x477359][_0x312a4a(0x189)], Date[_0x312a4a(0x102)]()));
                        continue;
                    case '7':
                        usu = logins[_0x477359][_0x312a4a(0x155)];
                        continue;
                    case '8':
                        exp = _0x30c857[_0x312a4a(0x12b)](exp[_0x312a4a(0x1cc)], _0x30c857[_0x312a4a(0xd6)]);
                        continue;
                    }
                    break;
                }
            }
            return tesk;
        }
    }
    return _0x30c857[_0x312a4a(0x108)];
}
async function connectToWhatsApp() {
    const _0x667976 = _0x5cb603, _0x163cb6 = {
            'IHUnw': function (_0x34e7a5, _0x12426b) {
                return _0x34e7a5 == _0x12426b;
            },
            'fSWJp': _0x667976(0x19f),
            'fAbNk': _0x667976(0x115) + _0x667976(0xd8),
            'hbsPL': function (_0x596e87, _0x347f5b) {
                return _0x596e87 === _0x347f5b;
            },
            'HDOwQ': _0x667976(0x138),
            'cAYQg': _0x667976(0x19d) + _0x667976(0x185) + '\x20',
            'AUcVS': _0x667976(0xd0) + _0x667976(0x18d),
            'HEyoQ': function (_0x236565, _0x320372) {
                return _0x236565(_0x320372);
            },
            'ygKAD': function (_0x4ef205) {
                return _0x4ef205();
            },
            'hTyLb': _0x667976(0x197),
            'HfSny': _0x667976(0x151) + _0x667976(0x172) + 'O!',
            'bDwcV': function (_0x52ce3c, _0x42da40) {
                return _0x52ce3c(_0x42da40);
            },
            'URECA': _0x667976(0x145) + _0x667976(0x136) + 'ri',
            'nKCPB': _0x667976(0xf7),
            'ZZaFX': _0x667976(0x13a),
            'WCrGw': _0x667976(0xcb) + 't',
            'wpHBb': function (_0x58b8a1, _0x3d0fe6) {
                return _0x58b8a1 + _0x3d0fe6;
            },
            'aUTlc': _0x667976(0xc5) + _0x667976(0x1b7),
            'XdZFx': _0x667976(0x72) + 'o!',
            'hqgUl': _0x667976(0x137),
            'elsxY': function (_0x41312f, _0x5afd68) {
                return _0x41312f + _0x5afd68;
            },
            'GNKZK': function (_0x4f2896, _0x89c6cf) {
                return _0x4f2896 < _0x89c6cf;
            },
            'OLWOK': function (_0x599245, _0x28923e) {
                return _0x599245 == _0x28923e;
            },
            'nTcUc': function (_0x1c9730, _0x1e2dd4) {
                return _0x1c9730 + _0x1e2dd4;
            },
            'XFled': _0x667976(0x11e),
            'QTmtK': function (_0x199e29, _0x16689f) {
                return _0x199e29 + _0x16689f;
            },
            'lvdwi': _0x667976(0x8c) + _0x667976(0x135) + _0x667976(0x19b),
            'ZgLOd': _0x667976(0x1cb),
            'kMsUb': _0x667976(0x82),
            'WLSdt': _0x667976(0x193),
            'keFXH': function (_0x573000, _0x448b37) {
                return _0x573000(_0x448b37);
            },
            'OPmwb': function (_0x1240a9, _0x3b5aab) {
                return _0x1240a9(_0x3b5aab);
            },
            'NsdUr': _0x667976(0x8d) + _0x667976(0x160) + _0x667976(0x16f) + _0x667976(0xe9) + _0x667976(0x132) + _0x667976(0x13d),
            'yntLr': _0x667976(0x19c),
            'NPMhY': function (_0x148596, _0x1954c7) {
                return _0x148596(_0x1954c7);
            },
            'joncG': function (_0x4eb392, _0x4718c5) {
                return _0x4eb392 * _0x4718c5;
            },
            'DyyaD': _0x667976(0x159) + _0x667976(0x143) + _0x667976(0xc0),
            'ZyvyL': function (_0x4f9ab5, _0x37d345) {
                return _0x4f9ab5(_0x37d345);
            },
            'HUNje': function (_0xf095db, _0x57cb3f) {
                return _0xf095db(_0x57cb3f);
            },
            'hUdZs': _0x667976(0xb9),
            'jEeMK': _0x667976(0xa5) + _0x667976(0x17a) + _0x667976(0x142) + _0x667976(0x89) + _0x667976(0x81) + _0x667976(0x158) + _0x667976(0xc7) + _0x667976(0x1a3) + _0x667976(0x168),
            'DRaaF': _0x667976(0x179) + _0x667976(0x1b8),
            'TTyxA': function (_0xc39586, _0x3e0121, _0x2bbb17) {
                return _0xc39586(_0x3e0121, _0x2bbb17);
            },
            'seiYl': _0x667976(0x1a7),
            'zoWDx': _0x667976(0x120),
            'ppyRO': _0x667976(0x104) + _0x667976(0x11b) + _0x667976(0xb1) + _0x667976(0xe2) + '😉',
            'dmviG': _0x667976(0x163),
            'PEhqO': _0x667976(0xbb),
            'YIRfr': _0x667976(0x1ac),
            'nXNBY': _0x667976(0x145) + _0x667976(0x98),
            'vCEnc': function (_0x3f4ee1, _0x1e55ab) {
                return _0x3f4ee1(_0x1e55ab);
            },
            'eHwBG': _0x667976(0x79),
            'GdchY': _0x667976(0x1b1) + 'te',
            'qzlmQ': _0x667976(0xea) + _0x667976(0x15b),
            'CQgNo': _0x667976(0x9c) + _0x667976(0xee),
            'lhVnb': _0x667976(0x196),
            'SjjUB': _0x667976(0x12c),
            'oWCBo': _0x667976(0xbf) + _0x667976(0x113)
        }, {
            state: _0x535a92,
            saveCreds: _0x1a1826
        } = await _0x163cb6[_0x667976(0x14f)](useMultiFileAuthState, _0x163cb6[_0x667976(0x17f)]), _0x2bec41 = await _0x163cb6[_0x667976(0x95)](makeWASocket, {
            'logger': _0x163cb6[_0x667976(0x19e)](P, { 'level': _0x163cb6[_0x667976(0x1b4)] }),
            'printQRInTerminal': !![],
            'auth': _0x535a92,
            'keepAliveIntervalMs': 0x3e80
        });
    _0x2bec41['ev']['on'](_0x163cb6[_0x667976(0x10c)], _0x1a1826), _0x2bec41['ev']['on'](_0x163cb6[_0x667976(0x1ab)], async _0x3fcc47 => {
        const _0x486ee7 = _0x667976, {
                connection: _0x2aee52,
                lastDisconnect: _0x2de186
            } = _0x3fcc47;
        _0x163cb6[_0x486ee7(0x1b9)](_0x2aee52, _0x163cb6[_0x486ee7(0xbe)]) && console[_0x486ee7(0xb2)](_0x163cb6[_0x486ee7(0x93)]);
        if (_0x163cb6[_0x486ee7(0x123)](_0x2aee52, _0x163cb6[_0x486ee7(0x1b5)]))
            console[_0x486ee7(0xb2)](DisconnectReason), console[_0x486ee7(0xb2)](_0x163cb6[_0x486ee7(0x18a)], _0x2de186, _0x163cb6[_0x486ee7(0xc6)]), await _0x163cb6[_0x486ee7(0xbc)](delay, -0x2122 + 0x3f * -0x19 + 0xb * 0x4a3), _0x163cb6[_0x486ee7(0x12e)](connectToWhatsApp);
        else {
            if (_0x163cb6[_0x486ee7(0x123)](_0x2aee52, _0x163cb6[_0x486ee7(0x1c1)])) {
                console[_0x486ee7(0xb2)](_0x163cb6[_0x486ee7(0x157)]), await _0x163cb6[_0x486ee7(0x1af)](delay, -0x1ae + 0x61 * 0x4f + -0x1d * 0x4d);
                const {checkStatus: _0x4ad330} = _0x163cb6[_0x486ee7(0xbc)](require, _0x163cb6[_0x486ee7(0x10e)]);
            }
        }
    }), console[_0x667976(0xb2)](_0x163cb6[_0x667976(0x74)]), app[_0x667976(0x9b)](_0x163cb6[_0x667976(0xfd)], async (_0x3e29fb, _0x454ced) => {
        const _0x52c168 = _0x667976, _0x4dc178 = {
                'yxEjZ': _0x163cb6[_0x52c168(0x8a)],
                'AdsVZ': _0x163cb6[_0x52c168(0x139)]
            };
        var {user: _0x3f08a9} = _0x3e29fb[_0x52c168(0x182)], {id: _0x3e9ad3} = _0x3e29fb[_0x52c168(0x182)];
        console[_0x52c168(0xb2)](_0x3f08a9, _0x3e9ad3);
        if (!_0x3f08a9[_0x52c168(0x71)]('@s'))
            return _0x454ced[_0x52c168(0x15f)]({ 'msg': _0x163cb6[_0x52c168(0x86)] });
        pagtoC = await _0x2bec41[_0x52c168(0x154) + 'e'](_0x3f08a9, { 'text': _0x163cb6[_0x52c168(0x181)](_0x163cb6[_0x52c168(0x181)](_0x163cb6[_0x52c168(0x144)], _0x3e9ad3), _0x163cb6[_0x52c168(0x1bd)]) })[_0x52c168(0xca)](_0x247e6c => {
            const _0x4d416f = _0x52c168;
            console[_0x4d416f(0xb2)](_0x4dc178[_0x4d416f(0x190)]), console[_0x4d416f(0xb2)](_0x247e6c), _0x454ced[_0x4d416f(0x15f)]({ 'msg': _0x4dc178[_0x4d416f(0x133)] });
        }), usuarioV = _0x163cb6[_0x52c168(0x181)](_0x163cb6[_0x52c168(0xc8)], ('' + _0x163cb6[_0x52c168(0x12e)](ale))[_0x52c168(0x1bc)](-0x249e + -0x1 * 0x95d + -0x4f * -0x95, 0x191 * 0x7 + -0x823 * -0x1 + -0x1316)), senha = ('' + _0x163cb6[_0x52c168(0x12e)](ale))[_0x52c168(0x1bc)](-0x30d + -0x583 * -0x7 + -0x2388 * 0x1, 0xb10 * 0x2 + -0x1265 + -0x3b7), _0x163cb6[_0x52c168(0xbc)](exec, _0x52c168(0x145) + _0x52c168(0xaf) + _0x52c168(0x70) + usuarioV + '\x20' + senha), await _0x2bec41[_0x52c168(0x154) + 'e'](_0x3f08a9, { 'text': _0x52c168(0x18e) + _0x52c168(0xc9) + _0x52c168(0x1c2) + _0x52c168(0x15e) + usuarioV + (_0x52c168(0x13b) + '\x20') + senha + (_0x52c168(0x14c) + _0x52c168(0x149) + _0x52c168(0x6a)) + d31 + _0x52c168(0x10a) }, { 'quoted': pagtoC })[_0x52c168(0xca)](_0x4c0910 => {
            const _0xf0a858 = _0x52c168;
            console[_0xf0a858(0xb2)](_0x4dc178[_0xf0a858(0x190)]), console[_0xf0a858(0xb2)](_0x4c0910), _0x454ced[_0xf0a858(0x15f)]({ 'msg': _0x4dc178[_0xf0a858(0x133)] });
        }), console[_0x52c168(0xb2)](_0x3f08a9);
        if (await _0x163cb6[_0x52c168(0xbc)](chackPago, _0x3f08a9)) {
            pagos = await JSON[_0x52c168(0x75)](fs[_0x52c168(0xda) + 'nc'](path['pa'])), obj = {
                'usuario': usuarioV,
                'senha': senha,
                'limite': 0x1,
                'Validade': d31,
                'expira': _0x163cb6[_0x52c168(0xd5)](Date[_0x52c168(0x102)](), expiraZ)
            };
            for (var _0x56a1d8 = -0x2036 + 0x1 * -0x557 + 0x258d; _0x163cb6[_0x52c168(0xe0)](_0x56a1d8, pagos[_0x52c168(0x122)]); _0x56a1d8++) {
                _0x163cb6[_0x52c168(0x83)](pagos[_0x56a1d8][_0x52c168(0x137)], _0x3f08a9) && (pagos[_0x56a1d8][_0x52c168(0x118)][_0x52c168(0x6d)](obj), await fs[_0x52c168(0xa6) + _0x52c168(0x1c5)](path['pa'], JSON[_0x52c168(0x8b)](pagos)));
            }
        } else
            pagos = await JSON[_0x52c168(0x75)](fs[_0x52c168(0xda) + 'nc'](path['pa'])), obj = {
                'user': _0x3f08a9,
                'logins': [{
                        'usuario': usuarioV,
                        'senha': senha,
                        'limite': 0x1,
                        'Validade': d31,
                        'expira': _0x163cb6[_0x52c168(0x13c)](Date[_0x52c168(0x102)](), expiraZ)
                    }]
            }, pagos[_0x52c168(0x6d)](obj), await fs[_0x52c168(0xa6) + _0x52c168(0x1c5)](path['pa'], JSON[_0x52c168(0x8b)](pagos));
        _0x454ced[_0x52c168(0x15f)]({ 'msg': _0x163cb6[_0x52c168(0xf8)] });
    }), app[_0x667976(0x9b)](_0x163cb6[_0x667976(0xd7)], async (_0x6d047e, _0x3dc46b) => {
        const _0x4a29e2 = _0x667976;
        var {user: _0x37fab0} = _0x6d047e[_0x4a29e2(0x182)], {id: _0x10f6de} = _0x6d047e[_0x4a29e2(0x182)];
        if (!_0x37fab0[_0x4a29e2(0x71)]('@s'))
            return _0x3dc46b[_0x4a29e2(0x15f)]({ 'msg': _0x163cb6[_0x4a29e2(0x86)] });
        await _0x2bec41[_0x4a29e2(0x154) + 'e'](_0x37fab0, { 'text': _0x163cb6[_0x4a29e2(0x141)](_0x163cb6[_0x4a29e2(0x11f)], _0x10f6de) })[_0x4a29e2(0xca)](_0x5bd88b => console[_0x4a29e2(0xb2)](_0x5bd88b));
    }), _0x2bec41['ev']['on'](_0x163cb6[_0x667976(0x91)], async _0x160315 => {
        const _0x1fcbac = _0x667976;
        _0x2bec41[_0x1fcbac(0x107) + _0x1fcbac(0xa3)](_0x163cb6[_0x1fcbac(0x17e)]), message = _0x160315[_0x1fcbac(0x9a)][0x24f2 + 0xb * -0x13c + -0x175e], msg = message[_0x1fcbac(0x106)], key = message[_0x1fcbac(0xb5)], fromMe = key[_0x1fcbac(0x15a)];
        if (fromMe)
            return;
        from = key[_0x1fcbac(0x16c)], isGroup = from[_0x1fcbac(0x71)](_0x163cb6[_0x1fcbac(0x6f)]), jid = isGroup ? key[_0x1fcbac(0x152) + 't'] : from, name = message[_0x1fcbac(0x16d)], body = msg[_0x1fcbac(0x1c6) + 'on'] ? msg[_0x1fcbac(0x1c6) + 'on'] : msg[_0x1fcbac(0x111) + _0x1fcbac(0xb3)] ? msg[_0x1fcbac(0x111) + _0x1fcbac(0xb3)][_0x1fcbac(0xd4)] : _0x163cb6[_0x1fcbac(0x94)], body = body[_0x1fcbac(0x1aa) + 'e']();
        async function _0x7cd04a(_0x27f366) {
            const _0x4b0c41 = _0x1fcbac;
            await _0x2bec41[_0x4b0c41(0x154) + 'e'](from, { 'text': _0x27f366 }, { 'quoted': message });
        }
        async function _0x2f6a12(_0x4118c0, _0x324b99) {
            const _0x528b02 = _0x1fcbac;
            await _0x2bec41[_0x528b02(0x154) + 'e'](_0x4118c0, { 'text': _0x324b99 });
        }
        if (!isGroup)
            console[_0x1fcbac(0xb2)](_0x1fcbac(0xb6) + _0x1fcbac(0x1bf) + _0x1fcbac(0xdb) + _0x163cb6[_0x1fcbac(0x112)](repla, jid) + '\x20(' + name + (_0x1fcbac(0x1a2) + _0x1fcbac(0x8e)) + body + (_0x1fcbac(0x1be) + _0x1fcbac(0xab)));
        _0x2bec41[_0x1fcbac(0x107) + _0x1fcbac(0xa3)](_0x163cb6[_0x1fcbac(0x17e)], jid), _0x2bec41[_0x1fcbac(0xe7) + 'es']([key]);
        if (isGroup)
            return;
        switch (body) {
        case '1':
        case '01':
            if (await _0x163cb6[_0x1fcbac(0x14f)](checkTeste, jid))
                return _0x163cb6[_0x1fcbac(0x1af)](_0x7cd04a, _0x163cb6[_0x1fcbac(0x87)]);
            usuarioT = _0x163cb6[_0x1fcbac(0x181)](_0x163cb6[_0x1fcbac(0xf5)], ('' + _0x163cb6[_0x1fcbac(0x12e)](ale))[_0x1fcbac(0x1bc)](0x25 * -0x7b + -0x386 * -0x3 + 0x735 * 0x1, 0x10d3 * 0x1 + -0x11 * -0x57 + -0x1696)), _0x163cb6[_0x1fcbac(0x199)](exec, _0x1fcbac(0x145) + _0x1fcbac(0xd9) + _0x1fcbac(0x15c) + usuarioT + '\x20' + _0x163cb6[_0x1fcbac(0x119)](config[_0x1fcbac(0x1ca) + 'e'], 0x3c7 + 0x301 * -0x5 + 0xb7a)), tesy = await _0x2bec41[_0x1fcbac(0x154) + 'e'](jid, { 'text': _0x1fcbac(0x18e) + _0x1fcbac(0xc9) + _0x1fcbac(0x1c2) + _0x1fcbac(0x15e) + usuarioT + (_0x1fcbac(0x13b) + _0x1fcbac(0xad) + _0x1fcbac(0xfb) + _0x1fcbac(0x6b) + '*\x20') + config[_0x1fcbac(0x1ca) + 'e'] + 'h' }, { 'quoted': message }), await _0x2bec41[_0x1fcbac(0x154) + 'e'](jid, { 'text': _0x163cb6[_0x1fcbac(0x192)] }, { 'quoted': tesy }), await _0x163cb6[_0x1fcbac(0x101)](delay, 0x121f + -0x2 * 0xf87 + 0xee3), _0x163cb6[_0x1fcbac(0x95)](gravarTeste, jid);
            break;
        case '2':
        case '02':
            placa2 = _0x1fcbac(0x18e) + _0x1fcbac(0xa0) + _0x1fcbac(0x110) + _0x1fcbac(0xe6) + config[_0x1fcbac(0xba)] + (_0x1fcbac(0x14c) + _0x1fcbac(0x149) + _0x1fcbac(0x1ba) + _0x1fcbac(0x17d) + _0x1fcbac(0x1bb) + _0x1fcbac(0x1c3) + _0x1fcbac(0xdc) + _0x1fcbac(0x1a9) + _0x1fcbac(0xaa) + _0x1fcbac(0x92) + _0x1fcbac(0x18b) + _0x1fcbac(0x116) + _0x1fcbac(0x1c8) + _0x1fcbac(0xbd) + _0x1fcbac(0x78) + _0x1fcbac(0x73)), _0x163cb6[_0x1fcbac(0x199)](_0x7cd04a, placa2);
            break;
        case _0x163cb6[_0x1fcbac(0x100)]:
        case 'si':
        case 'ss':
        case 's':
            if (await _0x163cb6[_0x1fcbac(0x101)](checkUser, jid))
                return _0x163cb6[_0x1fcbac(0x112)](_0x7cd04a, _0x163cb6[_0x1fcbac(0x99)]);
            _0x163cb6[_0x1fcbac(0x1af)](_0x7cd04a, _0x163cb6[_0x1fcbac(0x103)]), dados = await _0x163cb6[_0x1fcbac(0x18c)](gerar, jid, message), placa = _0x1fcbac(0xfa) + _0x1fcbac(0x7f) + _0x1fcbac(0xd3) + '\x20' + dados['id'] + (_0x1fcbac(0x10d) + '$') + dados[_0x1fcbac(0x15d)] + (_0x1fcbac(0x1a6) + _0x1fcbac(0xb8) + _0x1fcbac(0x191)) + dados[_0x1fcbac(0x6c)] + (_0x1fcbac(0x1c0) + _0x1fcbac(0xce) + _0x1fcbac(0x1ad) + _0x1fcbac(0x97) + _0x1fcbac(0x12a) + _0x1fcbac(0x171) + _0x1fcbac(0x77) + _0x1fcbac(0x76) + _0x1fcbac(0xcf) + _0x1fcbac(0xfc) + _0x1fcbac(0x170) + _0x1fcbac(0x198) + _0x1fcbac(0xac) + _0x1fcbac(0x11a) + _0x1fcbac(0xfe) + _0x1fcbac(0xec) + '⤵️'), mcode = await _0x2bec41[_0x1fcbac(0x154) + 'e'](dados[_0x1fcbac(0x137)], { 'text': placa }, { 'quoted': dados[_0x1fcbac(0x9f)] }), await _0x2bec41[_0x1fcbac(0x154) + 'e'](dados[_0x1fcbac(0x137)], { 'text': dados[_0x1fcbac(0x128)] }, { 'quoted': mcode });
            break;
        case _0x163cb6[_0x1fcbac(0xd2)]:
        case _0x163cb6[_0x1fcbac(0x1b6)]:
        case 'no':
        case 'n':
        case 'nn':
            _0x163cb6[_0x1fcbac(0x101)](_0x7cd04a, _0x163cb6[_0x1fcbac(0x13e)]);
            break;
        case '5':
        case '05':
            await _0x2bec41[_0x1fcbac(0x154) + 'e'](jid, {
                'text': _0x1fcbac(0x7d) + _0x1fcbac(0xf0) + dono2,
                'mentions': dono
            }, { 'quoted': message });
            break;
        case '3':
        case '03':
            gama = await _0x163cb6[_0x1fcbac(0x14f)](checkLogins, jid), await _0x2bec41[_0x1fcbac(0x154) + 'e'](jid, { 'text': gama }, { 'quoted': message });
            break;
        case _0x163cb6[_0x1fcbac(0x121)]:
        case _0x163cb6[_0x1fcbac(0x175)]:
        case '4':
        case '04':
            _0x163cb6[_0x1fcbac(0x112)](_0x7cd04a, _0x163cb6[_0x1fcbac(0x180)]), await _0x2bec41[_0x1fcbac(0x154) + 'e'](jid, { 'text': _0x1fcbac(0xe8) + _0x1fcbac(0x11d) + _0x1fcbac(0xa1) + _0x1fcbac(0x1a8) + _0x1fcbac(0x11c) + config[_0x1fcbac(0xf2)] + (_0x1fcbac(0xb4) + _0x1fcbac(0x194) + _0x1fcbac(0x1c7) + _0x1fcbac(0x13f) + _0x1fcbac(0x1b3) + _0x1fcbac(0x10f) + _0x1fcbac(0xa2)) }, { 'quoted': message });
            break;
        default:
            boasvindas = _0x1fcbac(0x14d) + name + (_0x1fcbac(0x134) + _0x1fcbac(0x161)) + config[_0x1fcbac(0x131)] + (_0x1fcbac(0x150) + _0x1fcbac(0x127) + _0x1fcbac(0xa7) + _0x1fcbac(0xc2) + _0x1fcbac(0x17c) + _0x1fcbac(0xe1) + _0x1fcbac(0x96) + _0x1fcbac(0x12d) + _0x1fcbac(0xb7) + _0x1fcbac(0x7c) + _0x1fcbac(0x16a) + _0x1fcbac(0xcd) + _0x1fcbac(0xf6) + _0x1fcbac(0x186) + _0x1fcbac(0x130) + _0x1fcbac(0xe4) + _0x1fcbac(0x1c4) + _0x1fcbac(0x188)), _0x163cb6[_0x1fcbac(0x1af)](_0x7cd04a, boasvindas);
        }
    });
}
connectToWhatsApp();