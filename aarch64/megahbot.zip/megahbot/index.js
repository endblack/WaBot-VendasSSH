const _0x528462 = _0x1dc4;
(function (_0x219f7a, _0x2e4131) {
    const _0x57ee79 = _0x1dc4, _0x23071e = _0x219f7a();
    while (!![]) {
        try {
            const _0x387616 = parseInt(_0x57ee79(0x1a5)) / (-0xef * 0x19 + -0xe6f + -0x1fd * -0x13) * (-parseInt(_0x57ee79(0x22f)) / (0x1d9d + -0x1a6c + 0x5 * -0xa3)) + -parseInt(_0x57ee79(0x2b4)) / (0x73 * -0x1 + -0xf * 0xfd + -0x2b * -0x5b) * (-parseInt(_0x57ee79(0x2c2)) / (0x14a7 + 0x13 * 0x19c + -0x3337)) + parseInt(_0x57ee79(0x2ee)) / (0x1562 + -0x1 * -0x2cd + 0x6 * -0x407) * (parseInt(_0x57ee79(0x262)) / (-0x124a + 0x23f2 + -0x11a2)) + -parseInt(_0x57ee79(0x2e5)) / (0x1065 + 0x1a9 * 0x16 + 0x2a5 * -0x14) + parseInt(_0x57ee79(0x20a)) / (0x1c61 + 0x1748 + -0x33a1) + parseInt(_0x57ee79(0x243)) / (-0x138a + -0xc * -0x162 + 0x2fb) + parseInt(_0x57ee79(0x1ef)) / (-0x3e + -0x1b49 + 0x1b91) * (-parseInt(_0x57ee79(0x235)) / (-0xc9 * -0x10 + 0x2308 + -0x2f8d));
            if (_0x387616 === _0x2e4131)
                break;
            else
                _0x23071e['push'](_0x23071e['shift']());
        } catch (_0x393282) {
            _0x23071e['push'](_0x23071e['shift']());
        }
    }
}(_0x3227, -0x1a8de2 + -0x26a22 + 0x1d704 * 0x18));
const {
        default: makeWASocket,
        delay,
        DisconnectReason,
        BufferJSON,
        useMultiFileAuthState
    } = require(_0x528462(0x2ab) + _0x528462(0x29d) + _0x528462(0x1dd)), {Boom} = require(_0x528462(0x2ed)), P = require(_0x528462(0x201)), {exec} = require(_0x528462(0x210) + _0x528462(0x237)), express = require(_0x528462(0x252)), {gerar} = require(_0x528462(0x245) + _0x528462(0x291) + _0x528462(0x1a9)), app = express(), moment = require(_0x528462(0x1eb) + _0x528462(0x29e)), fs = require(_0x528462(0x2d1)), ms = require('ms'), pms = require(_0x528462(0x2d5)), {config} = require(_0x528462(0x2b6) + 'ig');
time = ms('1d'), expiraZ = ms(_0x528462(0x1f1)), d31 = moment['tz'](_0x528462(0x2d0) + _0x528462(0x1a0))[_0x528462(0x214)](-0x4 * -0x470 + 0x51f + 0x16c * -0x10, 'd')[_0x528462(0x29b)](_0x528462(0x2aa)), app[_0x528462(0x265)](0x266 * 0x9 + 0x2de7 + -0x2825), dono = [config[_0x528462(0x1bd)] + (_0x528462(0x226) + _0x528462(0x1db))], dono2 = '' + config[_0x528462(0x1bd)], path = {
    'p': _0x528462(0x245) + _0x528462(0x2a7) + _0x528462(0x2b8) + 'n',
    't': _0x528462(0x245) + _0x528462(0x1a3) + _0x528462(0x22a),
    'pa': _0x528462(0x245) + _0x528462(0x2a7) + _0x528462(0x1bb)
};
function _0x1dc4(_0x115cde, _0x28f2d2) {
    const _0xd89c50 = _0x3227();
    return _0x1dc4 = function (_0x1fa4b0, _0x2718fb) {
        _0x1fa4b0 = _0x1fa4b0 - (-0x1 * 0x2333 + 0x9d3 + 0x1af0 * 0x1);
        let _0x3b0fd9 = _0xd89c50[_0x1fa4b0];
        return _0x3b0fd9;
    }, _0x1dc4(_0x115cde, _0x28f2d2);
}
async function checkUser(_0x296dd5) {
    const _0x2343c1 = _0x528462, _0x41e5c8 = {
            'UageO': function (_0x58cd35, _0x3c7171) {
                return _0x58cd35 < _0x3c7171;
            },
            'zjevB': function (_0x29e685, _0x35a17d) {
                return _0x29e685 == _0x35a17d;
            }
        };
    pedidos = await JSON[_0x2343c1(0x25a)](fs[_0x2343c1(0x253) + 'nc'](path['p']));
    for (var _0x2a3e36 = 0x55 * 0x22 + -0x1e7 * 0x1 + -0x963; _0x41e5c8[_0x2343c1(0x24e)](_0x2a3e36, pedidos[_0x2343c1(0x1ff)]); _0x2a3e36++) {
        if (_0x41e5c8[_0x2343c1(0x283)](pedidos[_0x2a3e36][_0x2343c1(0x257)], _0x296dd5))
            return !![];
    }
    return ![];
}
async function checkTeste(_0x2f6fd3) {
    const _0xa9b6b1 = _0x528462, _0x454364 = {
            'egOvK': function (_0x1e4278, _0x3932ed) {
                return _0x1e4278 < _0x3932ed;
            },
            'ChsQU': function (_0x7fd385, _0x38d398) {
                return _0x7fd385 == _0x38d398;
            },
            'ypLfs': function (_0x454be9, _0x353308) {
                return _0x454be9 > _0x353308;
            }
        };
    testes = await JSON[_0xa9b6b1(0x25a)](fs[_0xa9b6b1(0x253) + 'nc'](path['t'])), testes = await JSON[_0xa9b6b1(0x25a)](fs[_0xa9b6b1(0x253) + 'nc'](path['t']));
    for (var _0x29f907 = 0x14cb + -0x623 * -0x3 + -0x182 * 0x1a; _0x454364[_0xa9b6b1(0x2db)](_0x29f907, testes[_0xa9b6b1(0x1ff)]); _0x29f907++) {
        if (_0x454364[_0xa9b6b1(0x258)](testes[_0x29f907][_0xa9b6b1(0x257)], _0x2f6fd3)) {
            if (_0x454364[_0xa9b6b1(0x2db)](Date[_0xa9b6b1(0x1de)](), testes[_0x29f907][_0xa9b6b1(0x19b)]))
                return !![];
            if (_0x454364[_0xa9b6b1(0x2a1)](Date[_0xa9b6b1(0x1de)](), testes[_0x29f907][_0xa9b6b1(0x19b)]))
                return testes[_0xa9b6b1(0x20e)](_0x29f907, 0x6e9 * 0x5 + -0x1eb8 + -0x3d4), await fs[_0xa9b6b1(0x1ab) + _0xa9b6b1(0x2b1)](path['t'], JSON[_0xa9b6b1(0x2b7)](testes)), ![];
        }
    }
    return ![];
}
async function gravarTeste(_0x182db1) {
    const _0x4951b0 = _0x528462, _0x5326ec = {
            'iOKKR': function (_0x266642, _0x153489) {
                return _0x266642 + _0x153489;
            }
        };
    testes = await JSON[_0x4951b0(0x25a)](fs[_0x4951b0(0x253) + 'nc'](path['t'])), obj = {
        'user': _0x182db1,
        'expira': _0x5326ec[_0x4951b0(0x28c)](Date[_0x4951b0(0x1de)](), time)
    }, testes[_0x4951b0(0x26c)](obj), await fs[_0x4951b0(0x1ab) + _0x4951b0(0x2b1)](path['t'], JSON[_0x4951b0(0x2b7)](testes));
}
function ale() {
    const _0x248312 = _0x528462, _0x50a23e = {
            'mjdCu': function (_0x120a16, _0x195a0b) {
                return _0x120a16 * _0x195a0b;
            },
            'UMDkr': function (_0xdbec7a, _0xf602e0) {
                return _0xdbec7a + _0xf602e0;
            }
        };
    return i = 0x8ac7230489e80000, Math[_0x248312(0x21f)](_0x50a23e[_0x248312(0x19f)](Math[_0x248312(0x2a4)](), _0x50a23e[_0x248312(0x28d)](i, -0x17c3 + -0x13ae + 0x2b72)));
}
function repla(_0x22f92e) {
    const _0x3f0616 = _0x528462;
    return i = _0x22f92e[_0x3f0616(0x280)]('@'), _0x22f92e[_0x3f0616(0x19a)](-0x1 * -0x1b9f + -0x13fd + -0x7a2, i);
}
function _0x3227() {
    const _0x4e3e17 = [
        'eys',
        'now',
        'bot/login',
        'NwujN',
        'extendedTe',
        'MsYiL',
        '\x0a*⌛Validad',
        'mprar\x20logi',
        'sucess',
        'XHEJk',
        'catch',
        'tempo_test',
        '\x20confirmad',
        '\x0a/app\x0a\x0aDes',
        'moment-tim',
        'urfoY',
        'm:\x2010\x20min\x0a',
        'ggNBg',
        '69280FIQKhQ',
        'ste\x20🔥',
        '31d',
        '!*\x20Fique\x20a',
        'ativo\x20📱\x0a*[',
        'às\x20*',
        'n\x2030\x20dias\x20',
        'dSWpS',
        'link\x20não\x20e',
        'EkNWP',
        'XiwlC',
        'GAULN',
        '\x20no\x20privad',
        'nao',
        '):\x0a\x0aMensag',
        'id:\x20',
        'length',
        'Valor:*\x20R$',
        'pino',
        'u\x20login\x20se',
        'o\x20abaixo_\x20',
        '04]*\x20Aplic',
        'split',
        'eFhvJ',
        'Conexão\x20fe',
        'Você\x20já\x20ge',
        'GgVDG',
        '11777120JPhsLu',
        '\x20abaixo:\x0a\x0a',
        'messages',
        'Premium',
        'splice',
        'limite',
        'child_proc',
        'dias\x0a\x0a📌Sem',
        'chada\x20por:',
        '\x20obter\x20o\x20a',
        'add',
        'json',
        'Olá\x20',
        'midia',
        '\x0a*🔐Senha:*',
        '\x20😃,\x20Bem\x20vi',
        'XnjHa',
        'MpYDL',
        'ogins\x20🔍\x0a*[',
        'kPfOB',
        'duto•*\x0a\x0a*🏷️',
        'floor',
        'NMarV',
        'sendPresen',
        'dade:*\x2030\x20',
        'usUVJ',
        'eRxsy',
        'msgkey',
        '@s.whatsap',
        'steja\x20clic',
        'rou\x20um\x20tes',
        'conversati',
        'estes.json',
        '\x0a\x0aMensagem',
        'eja\x20compra',
        'dentificad',
        'linkApp',
        '1937114DylVdv',
        'jCtTK',
        'SiIdI',
        'o\x20de\x20Brasí',
        'bdKmP',
        'silent',
        '4334ogiSqF',
        'er.sh\x20',
        'ess',
        'bem\x20seu\x20te',
        '\x0a🏷️Valor:\x20R',
        'o,\x20pode\x20de',
        'pushName',
        'pwcIF',
        'CONECTADO\x20',
        '\x20(31\x20dias)',
        'ZXVfs',
        'ões\x20do\x20log',
        'u\x20espere\x20e',
        'e:*\x20',
        '14594265AUayEF',
        'connection',
        '/etc/megah',
        'bot/src/ve',
        '...',
        'fromMe',
        '5|2|3|7',
        '\x0a\x0a*👤Usuári',
        'participan',
        'vfzFj',
        'nMeml',
        'UageO',
        'JUqYG',
        'em:\x20',
        '*\x20_(horári',
        'express',
        'readFileSy',
        '\x20do\x20link\x20a',
        'open',
        'key',
        'user',
        'ChsQU',
        'logins',
        'parse',
        'messages.u',
        'LqNHs',
        'XcZFh',
        'pp,\x20digite',
        '\x20em\x2024h',
        'e\x20ficará',
        'LYlxY',
        '30QhYvHs',
        '/pago',
        'xtMessage',
        'listen',
        'connecting',
        'Aproveite\x20',
        '*Qrcode\x20ex',
        'HUeCq',
        'psert',
        'ável,\x20salv',
        'push',
        '\x20seu\x20pagam',
        'Hwkpi',
        'ando...',
        'qrcode',
        '📆\x0a*[03]*\x20V',
        'e\x20chamar!\x20',
        'vegador...',
        'Faça\x20o\x20dow',
        '05]*\x20Supor',
        '*\x201\x0a*⌛Vali',
        'uário:*\x20',
        'MapII',
        'PFAsA',
        '\x20para\x20faze',
        '\x0a\x0a🆔@',
        '\x20vontade\x20p',
        'Pagamento\x20',
        ',\x20Reconect',
        'morar\x20cerc',
        'indexOf',
        'eSAYT',
        'KKUna',
        'zjevB',
        'ste.sh\x20',
        'AMioe',
        'readMessag',
        '####',
        '\x0a\x0a########',
        'jfzUc',
        'app',
        'WUibu',
        'iOKKR',
        'UMDkr',
        'ar\x20teste\x20⌛',
        'available',
        'dPzKf',
        'bot/src/ge',
        'code...',
        'pPXWT',
        'Você\x20não\x20t',
        'baixo⤵️\x0a\x0a',
        'VZRPh',
        'ode\x20copia\x20',
        'e\x20cola\x20log',
        'em\x20logins\x20',
        'venceu',
        'format',
        '\x0a\x0a📌Caso\x20o\x20',
        'ckets/bail',
        'ezone',
        'o\x20de\x20',
        'dlSun',
        'ypLfs',
        'BPiAv',
        'a\x20de\x201\x20min',
        'random',
        'MMeLN',
        'TXSQx',
        'bot/data/p',
        'ento\x20for\x20i',
        'm\x20teste\x20an',
        'DD/MM/yyyy',
        '@whiskeyso',
        'sar\x20é\x20só\x20m',
        'LwZFa',
        'ato\x20que\x20el',
        '!\x20Se\x20preci',
        '.update',
        'ync',
        'close',
        '\x0a*[02]*\x20Co',
        '6yoLpyk',
        'usuario',
        '/root/conf',
        'stringify',
        'edidos.jso',
        'sendMessag',
        'm\x20pedido\x20e',
        '\x20dias',
        'te\x20hoje,\x20s',
        '*•Informaç',
        'NJvyA',
        'Eyrgq',
        'Gerando\x20Qr',
        'não',
        '3089592gbZKdW',
        'toLowerCas',
        'eMqwS',
        'senha',
        'deu\x20erro',
        'kZTUj',
        'creds.upda',
        'Validade',
        '\x0a⌛Expira\x20e',
        'er\x20alguma\x20',
        'PXkyS',
        'o:*\x20',
        'days',
        'Conectando',
        'America/Sa',
        'fs-extra',
        'GYPoE',
        'get',
        'remoteJid',
        'parse-ms',
        'nmTcV',
        'pre\x20faça\x20u',
        'query',
        'tes\x20de\x20com',
        '/app',
        'egOvK',
        'Aguarde...',
        'Você\x20tem\x20u',
        'bot/src/us',
        'VdLYI',
        'text',
        '*[01]*\x20Ger',
        'dido',
        '\x201234\x0a*📲Li',
        'log',
        '5439819HseeyK',
        'teste',
        'RfceJ',
        'SYBrU',
        'o,\x20pague\x20o',
        'vCmvk',
        'de:*\x0a\x0a🆔Id:',
        'COM\x20SUCESS',
        '@hapi/boom',
        '832205TJEAvf',
        '🆔Id:\x20',
        'e\x20meu\x20cont',
        'in•*\x0a\x0a*👤Us',
        '========',
        'doKJT',
        'ppOEu',
        'includes',
        'pirado:*\x0a\x0a',
        'SXVIG',
        'aaTSt',
        'pp\x20através',
        'lCzSa',
        'hora',
        'ZWtHs',
        'OhXMB',
        'slice',
        'expira',
        '\x20o\x20comando',
        'valorLogin',
        'das\x20opções',
        'mjdCu',
        'o_Paulo',
        'QONPn',
        '\x20abaixo\x20⤵️\x0a',
        'bot/data/t',
        '\x20assim\x20que',
        '1DUNsKe',
        'te\x20👤',
        '*Informaçõ',
        '*☎️Suporte*',
        'rar',
        'nomeLoja',
        'writeFileS',
        'ara\x20escolh',
        'erificar\x20L',
        'uto.\x0a\x0a_Qrc',
        'erar\x20outro',
        'sim',
        'ZXrRW',
        ')\x0a\x0a=======',
        'Abrindo\x20na',
        'Tudo\x20certo',
        'error',
        '6|0|4|1|8|',
        'JGCRK',
        '⌛Validade:',
        'valor',
        'r?\x20*Sim*\x20o',
        'agos.json',
        'LajiZ',
        'dono',
        '*\x20login\x27s\x20',
        '\x0a*📲Limite:',
        '@g.us',
        'Você\x20tem\x20*',
        'abnDQ',
        'ceUpdate',
        'r\x20outro\x20pe',
        'es\x20do\x20Qrco',
        'lia)_\x0a\x0a📌Se',
        'ndo(a)\x20a\x20*',
        '/cancel',
        'ó\x20poderá\x20g',
        'bad\x20reques',
        'iUGVF',
        'ões\x20do\x20pro',
        'message',
        'le\x20expirar',
        'nload\x20do\x20a',
        'mite:*\x201\x0a*',
        'prar!\x0aPara',
        'XRJLq',
        'fqGdh',
        'dade:*\x20',
        'm\x20andament',
        'gYLYQ',
        'bot/src/te',
        'rá\x20enviado',
        'BVcfV',
        'zAuif',
        'p.net',
        'u\x20*Não*'
    ];
    _0x3227 = function () {
        return _0x4e3e17;
    };
    return _0x3227();
}
async function chackPago(_0x36957b) {
    const _0x3b3a51 = _0x528462, _0x4e745b = {
            'XnjHa': function (_0x2ad7b3, _0x2691a6) {
                return _0x2ad7b3 < _0x2691a6;
            },
            'JUqYG': function (_0x4bb1f1, _0x39cca6) {
                return _0x4bb1f1 == _0x39cca6;
            }
        };
    pagos = await JSON[_0x3b3a51(0x25a)](fs[_0x3b3a51(0x253) + 'nc'](path['pa']));
    for (var _0x2b43f3 = 0xace + 0xd4 + -0xba2; _0x4e745b[_0x3b3a51(0x21a)](_0x2b43f3, pagos[_0x3b3a51(0x1ff)]); _0x2b43f3++) {
        if (_0x4e745b[_0x3b3a51(0x24f)](pagos[_0x2b43f3][_0x3b3a51(0x257)], _0x36957b))
            return !![];
    }
    return ![];
}
async function checkLogins(_0x271641) {
    const _0x4a9d9b = _0x528462, _0x3e4f0d = {
            'LYlxY': function (_0x2759e5, _0x5201d5) {
                return _0x2759e5 < _0x5201d5;
            },
            'jCtTK': function (_0x1dcc30, _0xd65c2f) {
                return _0x1dcc30 == _0xd65c2f;
            },
            'JGCRK': _0x4a9d9b(0x1b6) + _0x4a9d9b(0x249),
            'XcZFh': function (_0x3197d0, _0x4a4345) {
                return _0x3197d0 > _0x4a4345;
            },
            'dPzKf': _0x4a9d9b(0x29a),
            'XRJLq': function (_0x1a74d6, _0x35c1c9) {
                return _0x1a74d6 + _0x35c1c9;
            },
            'LajiZ': _0x4a9d9b(0x2bb),
            'OhXMB': function (_0x35701d, _0x1aacc9) {
                return _0x35701d(_0x1aacc9);
            },
            'VZRPh': function (_0x76c81b, _0x3df838) {
                return _0x76c81b - _0x3df838;
            },
            'jfzUc': _0x4a9d9b(0x294) + _0x4a9d9b(0x299) + _0x4a9d9b(0x20d)
        };
    pagos = await JSON[_0x4a9d9b(0x25a)](fs[_0x4a9d9b(0x253) + 'nc'](path['pa']));
    for (var _0x1a86fe = -0xbc8 + 0x138d + 0x75 * -0x11; _0x3e4f0d[_0x4a9d9b(0x261)](_0x1a86fe, pagos[_0x4a9d9b(0x1ff)]); _0x1a86fe++) {
        if (_0x3e4f0d[_0x4a9d9b(0x230)](pagos[_0x1a86fe][_0x4a9d9b(0x257)], _0x271641)) {
            logins = pagos[_0x1a86fe][_0x4a9d9b(0x259)], quanti = logins[_0x4a9d9b(0x1ff)], tesk = _0x4a9d9b(0x1c1) + '0' + quanti + (_0x4a9d9b(0x1be) + _0x4a9d9b(0x20d));
            for (var _0x1a86fe = -0x1 * -0x54f + -0x24a6 + 0x1f57; _0x3e4f0d[_0x4a9d9b(0x261)](_0x1a86fe, logins[_0x4a9d9b(0x1ff)]); _0x1a86fe++) {
                const _0x2ed4f4 = _0x3e4f0d[_0x4a9d9b(0x1b7)][_0x4a9d9b(0x205)]('|');
                let _0x4d5da2 = -0x425 + -0x795 + 0xbba;
                while (!![]) {
                    switch (_0x2ed4f4[_0x4d5da2++]) {
                    case '0':
                        sen = logins[_0x1a86fe][_0x4a9d9b(0x2c5)];
                        continue;
                    case '1':
                        vali = logins[_0x1a86fe][_0x4a9d9b(0x2c9)];
                        continue;
                    case '2':
                        exps = logins[_0x1a86fe][_0x4a9d9b(0x19b)];
                        continue;
                    case '3':
                        if (_0x3e4f0d[_0x4a9d9b(0x25d)](Date[_0x4a9d9b(0x1de)](), exp))
                            exp = _0x3e4f0d[_0x4a9d9b(0x290)];
                        continue;
                    case '4':
                        limi = logins[_0x1a86fe][_0x4a9d9b(0x20f)];
                        continue;
                    case '5':
                        exp = _0x3e4f0d[_0x4a9d9b(0x1d2)](exp[_0x4a9d9b(0x2ce)], _0x3e4f0d[_0x4a9d9b(0x1bc)]);
                        continue;
                    case '6':
                        usu = logins[_0x1a86fe][_0x4a9d9b(0x2b5)];
                        continue;
                    case '7':
                        tesk = _0x3e4f0d[_0x4a9d9b(0x1d2)](tesk, _0x4a9d9b(0x24a) + _0x4a9d9b(0x2cd) + usu + (_0x4a9d9b(0x218) + '\x20') + sen + (_0x4a9d9b(0x1bf) + '*\x20') + limi + (_0x4a9d9b(0x1e3) + _0x4a9d9b(0x242)) + vali + '\x20(' + exp + (_0x4a9d9b(0x1b2) + _0x4a9d9b(0x2f2)));
                        continue;
                    case '8':
                        exp = _0x3e4f0d[_0x4a9d9b(0x199)](pms, _0x3e4f0d[_0x4a9d9b(0x296)](logins[_0x1a86fe][_0x4a9d9b(0x19b)], Date[_0x4a9d9b(0x1de)]()));
                        continue;
                    }
                    break;
                }
            }
            return tesk;
        }
    }
    return _0x3e4f0d[_0x4a9d9b(0x289)];
}
async function connectToWhatsApp() {
    const _0x4fd9f3 = _0x528462, _0x3d9539 = {
            'QONPn': function (_0x3fa3e8, _0xae13db) {
                return _0x3fa3e8 == _0xae13db;
            },
            'urfoY': _0x4fd9f3(0x266),
            'eRxsy': _0x4fd9f3(0x2cf) + _0x4fd9f3(0x247),
            'dlSun': function (_0x90d34a, _0x29f44a) {
                return _0x90d34a === _0x29f44a;
            },
            'abnDQ': _0x4fd9f3(0x2b2),
            'nMeml': _0x4fd9f3(0x207) + _0x4fd9f3(0x212) + '\x20',
            'doKJT': _0x4fd9f3(0x27e) + _0x4fd9f3(0x26f),
            'GAULN': function (_0x476f87, _0x141f2b) {
                return _0x476f87(_0x141f2b);
            },
            'SiIdI': function (_0x5165c6) {
                return _0x5165c6();
            },
            'GYPoE': function (_0x5ac867, _0x3b29ca) {
                return _0x5ac867 === _0x3b29ca;
            },
            'vfzFj': _0x4fd9f3(0x255),
            'MMeLN': _0x4fd9f3(0x23d) + _0x4fd9f3(0x2ec) + 'O!',
            'iUGVF': _0x4fd9f3(0x245) + _0x4fd9f3(0x246) + 'ri',
            'HUeCq': _0x4fd9f3(0x2c6),
            'vCmvk': _0x4fd9f3(0x1b5),
            'dSWpS': _0x4fd9f3(0x1ca) + 't',
            'kZTUj': function (_0x5d39d5, _0xc502b3) {
                return _0x5d39d5 + _0xc502b3;
            },
            'NwujN': _0x4fd9f3(0x27d) + _0x4fd9f3(0x1fe),
            'SXVIG': _0x4fd9f3(0x1e9) + 'o!',
            'EkNWP': _0x4fd9f3(0x257),
            'nmTcV': function (_0x3a5575) {
                return _0x3a5575();
            },
            'Eyrgq': function (_0xe0503, _0x233c99) {
                return _0xe0503(_0x233c99);
            },
            'RfceJ': function (_0xe1815d, _0x22b191) {
                return _0xe1815d(_0x22b191);
            },
            'bdKmP': function (_0x1d52ad, _0x59609c) {
                return _0x1d52ad < _0x59609c;
            },
            'XHEJk': function (_0xb031d, _0x1b94d9) {
                return _0xb031d + _0x1b94d9;
            },
            'pPXWT': _0x4fd9f3(0x1e5),
            'eMqwS': _0x4fd9f3(0x268) + _0x4fd9f3(0x192) + _0x4fd9f3(0x2ef),
            'AMioe': _0x4fd9f3(0x28f),
            'usUVJ': _0x4fd9f3(0x1c0),
            'TXSQx': _0x4fd9f3(0x217),
            'KKUna': function (_0x172649, _0x3562b2) {
                return _0x172649(_0x3562b2);
            },
            'Hwkpi': _0x4fd9f3(0x208) + _0x4fd9f3(0x228) + _0x4fd9f3(0x2bc) + _0x4fd9f3(0x1c9) + _0x4fd9f3(0x1af) + _0x4fd9f3(0x25f),
            'aaTSt': _0x4fd9f3(0x2e6),
            'ppOEu': function (_0xeab47e, _0x238ec5) {
                return _0xeab47e * _0x238ec5;
            },
            'BVcfV': _0x4fd9f3(0x267) + _0x4fd9f3(0x238) + _0x4fd9f3(0x1f0),
            'PFAsA': function (_0x24eb3a, _0x3e1d20) {
                return _0x24eb3a(_0x3e1d20);
            },
            'eSAYT': function (_0x1f4e59, _0x3b51b8) {
                return _0x1f4e59(_0x3b51b8);
            },
            'ZXrRW': function (_0x4003c5, _0x47b0f3) {
                return _0x4003c5(_0x47b0f3);
            },
            'eFhvJ': _0x4fd9f3(0x1b0),
            'GgVDG': _0x4fd9f3(0x2dd) + _0x4fd9f3(0x2ba) + _0x4fd9f3(0x1d5) + _0x4fd9f3(0x2e9) + _0x4fd9f3(0x241) + _0x4fd9f3(0x1ce) + _0x4fd9f3(0x27a) + _0x4fd9f3(0x1c4) + _0x4fd9f3(0x2e2),
            'NMarV': function (_0x4fa6da, _0x1d59ff) {
                return _0x4fa6da(_0x1d59ff);
            },
            'pwcIF': _0x4fd9f3(0x2c0) + _0x4fd9f3(0x292),
            'SYBrU': function (_0x31879c, _0x3b0866, _0x2c003e) {
                return _0x31879c(_0x3b0866, _0x2c003e);
            },
            'gYLYQ': _0x4fd9f3(0x1fc),
            'LqNHs': _0x4fd9f3(0x2c1),
            'XiwlC': function (_0x38ee84, _0x4e06da) {
                return _0x38ee84(_0x4e06da);
            },
            'BPiAv': _0x4fd9f3(0x1b4) + _0x4fd9f3(0x2af) + _0x4fd9f3(0x2ac) + _0x4fd9f3(0x272) + '😉',
            'ZWtHs': _0x4fd9f3(0x2da),
            'MpYDL': _0x4fd9f3(0x28a),
            'WUibu': function (_0x2fbeac, _0x5cd7e3) {
                return _0x2fbeac(_0x5cd7e3);
            },
            'PXkyS': _0x4fd9f3(0x2dc),
            'NJvyA': _0x4fd9f3(0x245) + _0x4fd9f3(0x1df),
            'zAuif': function (_0x93c2fe, _0x596d38) {
                return _0x93c2fe(_0x596d38);
            },
            'ggNBg': _0x4fd9f3(0x234),
            'LwZFa': _0x4fd9f3(0x2c8) + 'te',
            'MsYiL': _0x4fd9f3(0x244) + _0x4fd9f3(0x2b0),
            'MapII': _0x4fd9f3(0x1b3) + _0x4fd9f3(0x273),
            'VdLYI': _0x4fd9f3(0x263),
            'fqGdh': _0x4fd9f3(0x1c8),
            'kPfOB': _0x4fd9f3(0x25b) + _0x4fd9f3(0x26a)
        }, {
            state: _0x26a128,
            saveCreds: _0x3eae0b
        } = await _0x3d9539[_0x4fd9f3(0x281)](useMultiFileAuthState, _0x3d9539[_0x4fd9f3(0x2be)]), _0x4d44ce = await _0x3d9539[_0x4fd9f3(0x2bf)](makeWASocket, {
            'logger': _0x3d9539[_0x4fd9f3(0x1da)](P, { 'level': _0x3d9539[_0x4fd9f3(0x1ee)] }),
            'printQRInTerminal': !![],
            'auth': _0x26a128,
            'keepAliveIntervalMs': 0x3e80
        });
    _0x4d44ce['ev']['on'](_0x3d9539[_0x4fd9f3(0x2ad)], _0x3eae0b), _0x4d44ce['ev']['on'](_0x3d9539[_0x4fd9f3(0x1e2)], async _0x31d79c => {
        const _0x163e81 = _0x4fd9f3, {
                connection: _0x1f653e,
                lastDisconnect: _0x4f3588
            } = _0x31d79c;
        _0x3d9539[_0x163e81(0x1a1)](_0x1f653e, _0x3d9539[_0x163e81(0x1ec)]) && console[_0x163e81(0x2e4)](_0x3d9539[_0x163e81(0x224)]);
        if (_0x3d9539[_0x163e81(0x2a0)](_0x1f653e, _0x3d9539[_0x163e81(0x1c2)]))
            console[_0x163e81(0x2e4)](DisconnectReason), console[_0x163e81(0x2e4)](_0x3d9539[_0x163e81(0x24d)], _0x4f3588, _0x3d9539[_0x163e81(0x2f3)]), await _0x3d9539[_0x163e81(0x1fa)](delay, 0x260e + -0x132d * 0x1 + -0x729), _0x3d9539[_0x163e81(0x231)](connectToWhatsApp);
        else {
            if (_0x3d9539[_0x163e81(0x2d2)](_0x1f653e, _0x3d9539[_0x163e81(0x24c)])) {
                console[_0x163e81(0x2e4)](_0x3d9539[_0x163e81(0x2a5)]), await _0x3d9539[_0x163e81(0x1fa)](delay, -0x116e * 0x1 + 0x3df * 0x1 + -0xc5 * -0x2b);
                const {checkStatus: _0x41e20a} = _0x3d9539[_0x163e81(0x1fa)](require, _0x3d9539[_0x163e81(0x1cb)]);
            }
        }
    }), console[_0x4fd9f3(0x2e4)](_0x3d9539[_0x4fd9f3(0x278)]), app[_0x4fd9f3(0x2d3)](_0x3d9539[_0x4fd9f3(0x2df)], async (_0x3d736e, _0x4556c0) => {
        const _0x9c8679 = _0x4fd9f3, _0x1860dc = {
                'lCzSa': _0x3d9539[_0x9c8679(0x269)],
                'ZXVfs': _0x3d9539[_0x9c8679(0x2ea)]
            };
        var {user: _0x5b93da} = _0x3d736e[_0x9c8679(0x2d8)], {id: _0x34ec8a} = _0x3d736e[_0x9c8679(0x2d8)];
        console[_0x9c8679(0x2e4)](_0x5b93da, _0x34ec8a);
        if (!_0x5b93da[_0x9c8679(0x191)]('@s'))
            return _0x4556c0[_0x9c8679(0x215)]({ 'msg': _0x3d9539[_0x9c8679(0x1f6)] });
        pagtoC = await _0x4d44ce[_0x9c8679(0x2b9) + 'e'](_0x5b93da, { 'text': _0x3d9539[_0x9c8679(0x2c7)](_0x3d9539[_0x9c8679(0x2c7)](_0x3d9539[_0x9c8679(0x1e0)], _0x34ec8a), _0x3d9539[_0x9c8679(0x193)]) })[_0x9c8679(0x1e7)](_0x5b9ffe => {
            const _0x2f0369 = _0x9c8679;
            console[_0x2f0369(0x2e4)](_0x1860dc[_0x2f0369(0x196)]), console[_0x2f0369(0x2e4)](_0x5b9ffe), _0x4556c0[_0x2f0369(0x215)]({ 'msg': _0x1860dc[_0x2f0369(0x23f)] });
        }), usuarioV = _0x3d9539[_0x9c8679(0x2c7)](_0x3d9539[_0x9c8679(0x1f8)], ('' + _0x3d9539[_0x9c8679(0x2d6)](ale))[_0x9c8679(0x19a)](0x69b * -0x3 + -0x1 * 0xf3a + 0x230b, -0x1 * 0xa9a + 0x1 * 0x30f + 0x78f)), senha = ('' + _0x3d9539[_0x9c8679(0x2d6)](ale))[_0x9c8679(0x19a)](0x3 * -0x45a + 0x2 * -0xefe + 0x2b0a, -0x847 + -0x3 * 0xe9 + 0x583 * 0x2), _0x3d9539[_0x9c8679(0x2bf)](exec, _0x9c8679(0x245) + _0x9c8679(0x2de) + _0x9c8679(0x236) + usuarioV + '\x20' + senha), await _0x4d44ce[_0x9c8679(0x2b9) + 'e'](_0x5b93da, { 'text': _0x9c8679(0x2bd) + _0x9c8679(0x240) + _0x9c8679(0x2f1) + _0x9c8679(0x277) + usuarioV + (_0x9c8679(0x218) + '\x20') + senha + (_0x9c8679(0x1bf) + _0x9c8679(0x276) + _0x9c8679(0x1d4)) + d31 + _0x9c8679(0x23e) }, { 'quoted': pagtoC })[_0x9c8679(0x1e7)](_0x5627c0 => {
            const _0xf4c5f3 = _0x9c8679;
            console[_0xf4c5f3(0x2e4)](_0x1860dc[_0xf4c5f3(0x196)]), console[_0xf4c5f3(0x2e4)](_0x5627c0), _0x4556c0[_0xf4c5f3(0x215)]({ 'msg': _0x1860dc[_0xf4c5f3(0x23f)] });
        }), console[_0x9c8679(0x2e4)](_0x5b93da);
        if (await _0x3d9539[_0x9c8679(0x2e7)](chackPago, _0x5b93da)) {
            pagos = await JSON[_0x9c8679(0x25a)](fs[_0x9c8679(0x253) + 'nc'](path['pa'])), obj = {
                'usuario': usuarioV,
                'senha': senha,
                'limite': 0x1,
                'Validade': d31,
                'expira': _0x3d9539[_0x9c8679(0x2c7)](Date[_0x9c8679(0x1de)](), expiraZ)
            };
            for (var _0x3ef813 = -0x7f * -0x3d + -0x1 * 0x259c + 0x759; _0x3d9539[_0x9c8679(0x233)](_0x3ef813, pagos[_0x9c8679(0x1ff)]); _0x3ef813++) {
                _0x3d9539[_0x9c8679(0x1a1)](pagos[_0x3ef813][_0x9c8679(0x257)], _0x5b93da) && (pagos[_0x3ef813][_0x9c8679(0x259)][_0x9c8679(0x26c)](obj), await fs[_0x9c8679(0x1ab) + _0x9c8679(0x2b1)](path['pa'], JSON[_0x9c8679(0x2b7)](pagos)));
            }
        } else
            pagos = await JSON[_0x9c8679(0x25a)](fs[_0x9c8679(0x253) + 'nc'](path['pa'])), obj = {
                'user': _0x5b93da,
                'logins': [{
                        'usuario': usuarioV,
                        'senha': senha,
                        'limite': 0x1,
                        'Validade': d31,
                        'expira': _0x3d9539[_0x9c8679(0x1e6)](Date[_0x9c8679(0x1de)](), expiraZ)
                    }]
            }, pagos[_0x9c8679(0x26c)](obj), await fs[_0x9c8679(0x1ab) + _0x9c8679(0x2b1)](path['pa'], JSON[_0x9c8679(0x2b7)](pagos));
        _0x4556c0[_0x9c8679(0x215)]({ 'msg': _0x3d9539[_0x9c8679(0x293)] });
    }), app[_0x4fd9f3(0x2d3)](_0x3d9539[_0x4fd9f3(0x1d3)], async (_0x40ed43, _0x4c0751) => {
        const _0x250771 = _0x4fd9f3;
        var {user: _0x4648bb} = _0x40ed43[_0x250771(0x2d8)], {id: _0x1fe825} = _0x40ed43[_0x250771(0x2d8)];
        if (!_0x4648bb[_0x250771(0x191)]('@s'))
            return _0x4c0751[_0x250771(0x215)]({ 'msg': _0x3d9539[_0x250771(0x1f6)] });
        await _0x4d44ce[_0x250771(0x2b9) + 'e'](_0x4648bb, { 'text': _0x3d9539[_0x250771(0x1e6)](_0x3d9539[_0x250771(0x2c4)], _0x1fe825) })[_0x250771(0x1e7)](_0x5c2658 => console[_0x250771(0x2e4)](_0x5c2658));
    }), _0x4d44ce['ev']['on'](_0x3d9539[_0x4fd9f3(0x21d)], async _0x4bd0f4 => {
        const _0xb2e23d = _0x4fd9f3;
        _0x4d44ce[_0xb2e23d(0x221) + _0xb2e23d(0x1c3)](_0x3d9539[_0xb2e23d(0x285)]), message = _0x4bd0f4[_0xb2e23d(0x20c)][0x1 * 0x2131 + 0x18e * -0x5 + -0x879 * 0x3], msg = message[_0xb2e23d(0x1cd)], key = message[_0xb2e23d(0x256)], fromMe = key[_0xb2e23d(0x248)];
        if (fromMe)
            return;
        from = key[_0xb2e23d(0x2d4)], isGroup = from[_0xb2e23d(0x191)](_0x3d9539[_0xb2e23d(0x223)]), jid = isGroup ? key[_0xb2e23d(0x24b) + 't'] : from, name = message[_0xb2e23d(0x23b)], body = msg[_0xb2e23d(0x229) + 'on'] ? msg[_0xb2e23d(0x229) + 'on'] : msg[_0xb2e23d(0x1e1) + _0xb2e23d(0x264)] ? msg[_0xb2e23d(0x1e1) + _0xb2e23d(0x264)][_0xb2e23d(0x2e0)] : _0x3d9539[_0xb2e23d(0x2a6)], body = body[_0xb2e23d(0x2c3) + 'e']();
        async function _0x326315(_0x83133c) {
            const _0x5d788c = _0xb2e23d;
            await _0x4d44ce[_0x5d788c(0x2b9) + 'e'](from, { 'text': _0x83133c }, { 'quoted': message });
        }
        async function _0x32c9c7(_0x4f3e0c, _0xd0a9f4) {
            const _0x44bd8e = _0xb2e23d;
            await _0x4d44ce[_0x44bd8e(0x2b9) + 'e'](_0x4f3e0c, { 'text': _0xd0a9f4 });
        }
        if (!isGroup)
            console[_0xb2e23d(0x2e4)](_0xb2e23d(0x22b) + _0xb2e23d(0x1fb) + _0xb2e23d(0x29f) + _0x3d9539[_0xb2e23d(0x282)](repla, jid) + '\x20(' + name + (_0xb2e23d(0x1fd) + _0xb2e23d(0x250)) + body + (_0xb2e23d(0x288) + _0xb2e23d(0x287)));
        _0x4d44ce[_0xb2e23d(0x221) + _0xb2e23d(0x1c3)](_0x3d9539[_0xb2e23d(0x285)], jid), _0x4d44ce[_0xb2e23d(0x286) + 'es']([key]);
        if (isGroup)
            return;
        switch (body) {
        case '1':
        case '01':
            if (await _0x3d9539[_0xb2e23d(0x1fa)](checkTeste, jid))
                return _0x3d9539[_0xb2e23d(0x2bf)](_0x326315, _0x3d9539[_0xb2e23d(0x26e)]);
            usuarioT = _0x3d9539[_0xb2e23d(0x1e6)](_0x3d9539[_0xb2e23d(0x194)], ('' + _0x3d9539[_0xb2e23d(0x231)](ale))[_0xb2e23d(0x19a)](-0x46 + 0x4d3 * -0x6 + 0x1d38, -0x27 * -0xa + 0x57f + -0x701)), _0x3d9539[_0xb2e23d(0x1fa)](exec, _0xb2e23d(0x245) + _0xb2e23d(0x1d7) + _0xb2e23d(0x284) + usuarioT + '\x20' + _0x3d9539[_0xb2e23d(0x190)](config[_0xb2e23d(0x1e8) + 'e'], 0x14b6 + 0x991 + -0x1e0b)), tesy = await _0x4d44ce[_0xb2e23d(0x2b9) + 'e'](jid, { 'text': _0xb2e23d(0x2bd) + _0xb2e23d(0x240) + _0xb2e23d(0x2f1) + _0xb2e23d(0x277) + usuarioT + (_0xb2e23d(0x218) + _0xb2e23d(0x2e3) + _0xb2e23d(0x1d0) + _0xb2e23d(0x1b8) + '*\x20') + config[_0xb2e23d(0x1e8) + 'e'] + 'h' }, { 'quoted': message }), await _0x4d44ce[_0xb2e23d(0x2b9) + 'e'](jid, { 'text': _0x3d9539[_0xb2e23d(0x1d9)] }, { 'quoted': tesy }), await _0x3d9539[_0xb2e23d(0x279)](delay, 0x150f + -0x241e + 0x1103), _0x3d9539[_0xb2e23d(0x281)](gravarTeste, jid);
            break;
        case '2':
        case '02':
            placa2 = _0xb2e23d(0x2bd) + _0xb2e23d(0x1cc) + _0xb2e23d(0x21e) + _0xb2e23d(0x200) + config[_0xb2e23d(0x19d)] + (_0xb2e23d(0x1bf) + _0xb2e23d(0x276) + _0xb2e23d(0x222) + _0xb2e23d(0x211) + _0xb2e23d(0x2d7) + _0xb2e23d(0x2a9) + _0xb2e23d(0x2d9) + _0xb2e23d(0x1d1) + _0xb2e23d(0x213) + _0xb2e23d(0x25e) + _0xb2e23d(0x19c) + _0xb2e23d(0x1a2) + _0xb2e23d(0x1ea) + _0xb2e23d(0x22c) + _0xb2e23d(0x1ba) + _0xb2e23d(0x1dc)), _0x3d9539[_0xb2e23d(0x1b1)](_0x326315, placa2);
            break;
        case _0x3d9539[_0xb2e23d(0x206)]:
        case 'si':
        case 'ss':
        case 's':
            if (await _0x3d9539[_0xb2e23d(0x281)](checkUser, jid))
                return _0x3d9539[_0xb2e23d(0x279)](_0x326315, _0x3d9539[_0xb2e23d(0x209)]);
            _0x3d9539[_0xb2e23d(0x220)](_0x326315, _0x3d9539[_0xb2e23d(0x23c)]), dados = await _0x3d9539[_0xb2e23d(0x2e8)](gerar, jid, message), placa = _0xb2e23d(0x1a7) + _0xb2e23d(0x1c5) + _0xb2e23d(0x2eb) + '\x20' + dados['id'] + (_0xb2e23d(0x239) + '$') + dados[_0xb2e23d(0x1b9)] + (_0xb2e23d(0x2ca) + _0xb2e23d(0x1ed) + _0xb2e23d(0x1f4)) + dados[_0xb2e23d(0x197)] + (_0xb2e23d(0x251) + _0xb2e23d(0x232) + _0xb2e23d(0x1c6) + _0xb2e23d(0x202) + _0xb2e23d(0x1d8) + _0xb2e23d(0x1a4) + _0xb2e23d(0x26d) + _0xb2e23d(0x2a8) + _0xb2e23d(0x22d) + _0xb2e23d(0x23a) + _0xb2e23d(0x27f) + _0xb2e23d(0x2a3) + _0xb2e23d(0x1ae) + _0xb2e23d(0x297) + _0xb2e23d(0x298) + _0xb2e23d(0x203) + '⤵️'), mcode = await _0x4d44ce[_0xb2e23d(0x2b9) + 'e'](dados[_0xb2e23d(0x257)], { 'text': placa }, { 'quoted': dados[_0xb2e23d(0x225)] }), await _0x4d44ce[_0xb2e23d(0x2b9) + 'e'](dados[_0xb2e23d(0x257)], { 'text': dados[_0xb2e23d(0x270)] }, { 'quoted': mcode });
            break;
        case _0x3d9539[_0xb2e23d(0x1d6)]:
        case _0x3d9539[_0xb2e23d(0x25c)]:
        case 'no':
        case 'n':
        case 'nn':
            _0x3d9539[_0xb2e23d(0x1f9)](_0x326315, _0x3d9539[_0xb2e23d(0x2a2)]);
            break;
        case '5':
        case '05':
            await _0x4d44ce[_0xb2e23d(0x2b9) + 'e'](jid, {
                'text': _0xb2e23d(0x1a8) + _0xb2e23d(0x27b) + dono2,
                'mentions': dono
            }, { 'quoted': message });
            break;
        case '3':
        case '03':
            gama = await _0x3d9539[_0xb2e23d(0x1fa)](checkLogins, jid), await _0x4d44ce[_0xb2e23d(0x2b9) + 'e'](jid, { 'text': gama }, { 'quoted': message });
            break;
        case _0x3d9539[_0xb2e23d(0x198)]:
        case _0x3d9539[_0xb2e23d(0x21b)]:
        case '4':
        case '04':
            _0x3d9539[_0xb2e23d(0x28b)](_0x326315, _0x3d9539[_0xb2e23d(0x2cc)]), await _0x4d44ce[_0xb2e23d(0x2b9) + 'e'](jid, { 'text': _0xb2e23d(0x274) + _0xb2e23d(0x1cf) + _0xb2e23d(0x195) + _0xb2e23d(0x254) + _0xb2e23d(0x295) + config[_0xb2e23d(0x22e)] + (_0xb2e23d(0x29c) + _0xb2e23d(0x1f7) + _0xb2e23d(0x227) + _0xb2e23d(0x26b) + _0xb2e23d(0x2f0) + _0xb2e23d(0x2ae) + _0xb2e23d(0x260)) }, { 'quoted': message });
            break;
        default:
            boasvindas = _0xb2e23d(0x216) + name + (_0xb2e23d(0x219) + _0xb2e23d(0x1c7)) + config[_0xb2e23d(0x1aa)] + (_0xb2e23d(0x1f2) + _0xb2e23d(0x27c) + _0xb2e23d(0x1ac) + _0xb2e23d(0x2cb) + _0xb2e23d(0x19e) + _0xb2e23d(0x20b) + _0xb2e23d(0x2e1) + _0xb2e23d(0x28e) + _0xb2e23d(0x2b3) + _0xb2e23d(0x1e4) + _0xb2e23d(0x1f5) + _0xb2e23d(0x271) + _0xb2e23d(0x1ad) + _0xb2e23d(0x21c) + _0xb2e23d(0x204) + _0xb2e23d(0x1f3) + _0xb2e23d(0x275) + _0xb2e23d(0x1a6)), _0x3d9539[_0xb2e23d(0x282)](_0x326315, boasvindas);
        }
    });
}
connectToWhatsApp();