const _0x679046 = _0x46d4;
(function (_0x513cc9, _0x54d15e) {
    const _0x47559a = _0x46d4, _0x4d6aa0 = _0x513cc9();
    while (!![]) {
        try {
            const _0x41b9fc = parseInt(_0x47559a(0x24f)) / (0x17d1 + -0x2 * -0x12be + -0x2 * 0x1ea6) + -parseInt(_0x47559a(0x263)) / (0x1c73 + 0xe3e + -0x2aaf) * (parseInt(_0x47559a(0x21b)) / (-0x6e8 + 0x1 * -0x8c1 + 0xfac)) + parseInt(_0x47559a(0x206)) / (0x4 * 0x5ab + -0x2e * -0x75 + -0x2bae) * (-parseInt(_0x47559a(0x1fa)) / (-0x1 * 0x7f7 + 0x7f * 0x49 + -0x1c3b)) + -parseInt(_0x47559a(0x267)) / (0x1361 + 0x4 * -0x31d + 0x13 * -0x5d) + parseInt(_0x47559a(0x244)) / (-0x5e4 + 0x1 * 0x1acf + 0xe * -0x17e) + -parseInt(_0x47559a(0x23f)) / (0x1b * -0xf3 + 0x2041 * 0x1 + -0x1a6 * 0x4) * (parseInt(_0x47559a(0x240)) / (0x5b9 + -0x1dd * -0x1 + 0x1 * -0x78d)) + parseInt(_0x47559a(0x231)) / (-0x1ba9 + -0x1c * 0x83 + 0x2a07) * (parseInt(_0x47559a(0x239)) / (-0xe5f + -0x1ecb + 0x2d35));
            if (_0x41b9fc === _0x54d15e)
                break;
            else
                _0x4d6aa0['push'](_0x4d6aa0['shift']());
        } catch (_0x5e7707) {
            _0x4d6aa0['push'](_0x4d6aa0['shift']());
        }
    }
}(_0x25ce, 0x5ca99 + 0x2f318 + -0x447c1));
const axios = require(_0x679046(0x1f5)), fs = require(_0x679046(0x1ff)), ms = require('ms'), {config} = require(_0x679046(0x20e) + 'ig'), moment = require(_0x679046(0x20d) + _0x679046(0x223));
token = '' + config[_0x679046(0x261)], hoje = moment['tz'](_0x679046(0x22e) + _0x679046(0x242))[_0x679046(0x201)](_0x679046(0x23b)), horario = moment['tz'](_0x679046(0x22e) + _0x679046(0x242))[_0x679046(0x201)](_0x679046(0x241)), console[_0x679046(0x203)](_0x679046(0x20f) + 'm\x20' + hoje + _0x679046(0x217) + horario + (_0x679046(0x25e) + ')')), expira = ms(_0x679046(0x20a)), path = {
    'p': _0x679046(0x260) + _0x679046(0x1f4) + _0x679046(0x238) + 'n',
    't': _0x679046(0x260) + _0x679046(0x20c) + _0x679046(0x205),
    'pa': _0x679046(0x260) + _0x679046(0x1f4) + _0x679046(0x22c)
};
function _0x46d4(_0x388952, _0x2f7b14) {
    const _0x1fc648 = _0x25ce();
    return _0x46d4 = function (_0x229175, _0x17efff) {
        _0x229175 = _0x229175 - (0x1290 + 0x1fcf + 0x306b * -0x1);
        let _0x39f1ba = _0x1fc648[_0x229175];
        return _0x39f1ba;
    }, _0x46d4(_0x388952, _0x2f7b14);
}
function delay(_0x5d1add) {
    return new Promise(_0x3aff3d => setTimeout(_0x3aff3d, _0x5d1add * (0xe03 + 0x2 * -0x37c + 0x323 * -0x1)));
}
async function gerar(_0x2845b2, _0x555c2b) {
    const _0x262f14 = _0x679046, _0x450f9d = {
            'xJNyD': _0x262f14(0x250) + _0x262f14(0x259),
            'qruHf': _0x262f14(0x22e) + _0x262f14(0x242),
            'HZWpq': _0x262f14(0x241),
            'SVxrS': function (_0x3e9ad3, _0x1d5395) {
                return _0x3e9ad3 + _0x1d5395;
            },
            'xlwEf': _0x262f14(0x251),
            'EIsOa': _0x262f14(0x208) + _0x262f14(0x215),
            'XcFMv': function (_0x59375a, _0x2afe02) {
                return _0x59375a(_0x2afe02);
            },
            'uHDGP': _0x262f14(0x209),
            'teFQw': _0x262f14(0x22b) + _0x262f14(0x25c) + _0x262f14(0x228) + _0x262f14(0x23c),
            'fVnpR': _0x262f14(0x21c) + _0x262f14(0x214),
            'UYbgj': _0x262f14(0x252),
            'aslMR': _0x262f14(0x24b),
            'YSHNf': _0x262f14(0x257) + _0x262f14(0x200),
            'moPJD': _0x262f14(0x24a),
            'FfALe': _0x262f14(0x224),
            'sbBEI': _0x262f14(0x254),
            'AExat': _0x262f14(0x229) + '0',
            'VCYnS': _0x262f14(0x213),
            'Yyqnx': _0x262f14(0x21f) + _0x262f14(0x220) + 's',
            'VGeZb': _0x262f14(0x1f6),
            'fxaWJ': _0x262f14(0x25d),
            'CVnxB': _0x262f14(0x1fe),
            'adfXc': function (_0x3f5159, _0x2c330b) {
                return _0x3f5159 + _0x2c330b;
            }
        }, _0x533098 = _0x450f9d[_0x262f14(0x264)][_0x262f14(0x265)]('|');
    let _0x5d399e = -0xfda + -0x1da + 0x16 * 0xce;
    while (!![]) {
        switch (_0x533098[_0x5d399e++]) {
        case '0':
            pedidos[_0x262f14(0x232)](obj);
            continue;
        case '1':
            return obj;
        case '2':
            resul = requestP[_0x262f14(0x211)];
            continue;
        case '3':
            pedidos = await JSON[_0x262f14(0x249)](fs[_0x262f14(0x204) + 'nc'](path['p']));
            continue;
        case '4':
            m102 = moment['tz'](_0x450f9d[_0x262f14(0x202)])[_0x262f14(0x230)](0x9 * -0x209 + -0x263a + -0xb51 * -0x5, 'm')[_0x262f14(0x201)](_0x450f9d[_0x262f14(0x258)]);
            continue;
        case '5':
            await fs[_0x262f14(0x1fb) + _0x262f14(0x262)](path['p'], JSON[_0x262f14(0x226)](pedidos));
            continue;
        case '6':
            m10 = moment['tz'](_0x450f9d[_0x262f14(0x202)])[_0x262f14(0x230)](0x570 + -0x1d82 + -0x607 * -0x4, 'm')[_0x262f14(0x201)](_0x450f9d[_0x262f14(0x23e)](_0x450f9d[_0x262f14(0x23e)](_0x450f9d[_0x262f14(0x25a)], 'T'), _0x450f9d[_0x262f14(0x25b)]));
            continue;
        case '7':
            requestP = await _0x450f9d[_0x262f14(0x237)](axios, {
                'method': _0x450f9d[_0x262f14(0x23d)],
                'url': _0x450f9d[_0x262f14(0x233)],
                'headers': {
                    'Content-Type': _0x450f9d[_0x262f14(0x21e)],
                    'Authorization': _0x262f14(0x1fd) + token
                },
                'data': {
                    'transaction_amount': config[_0x262f14(0x255)],
                    'date_of_expiration': m10,
                    'description': _0x450f9d[_0x262f14(0x216)],
                    'payment_method_id': _0x450f9d[_0x262f14(0x22d)],
                    'payer': {
                        'email': _0x450f9d[_0x262f14(0x235)],
                        'first_name': _0x450f9d[_0x262f14(0x1f9)],
                        'last_name': _0x450f9d[_0x262f14(0x253)],
                        'identification': {
                            'type': _0x450f9d[_0x262f14(0x25f)],
                            'number': _0x450f9d[_0x262f14(0x218)]
                        },
                        'address': {
                            'zip_code': _0x450f9d[_0x262f14(0x227)],
                            'street_name': _0x450f9d[_0x262f14(0x24c)],
                            'street_number': _0x450f9d[_0x262f14(0x248)],
                            'neighborhood': _0x450f9d[_0x262f14(0x222)],
                            'city': _0x450f9d[_0x262f14(0x266)],
                            'federal_unit': 'SP'
                        }
                    }
                }
            });
            continue;
        case '8':
            obj = {
                'id': resul['id'],
                'user': _0x2845b2,
                'msgkey': _0x555c2b,
                'status': resul[_0x262f14(0x24e)],
                'valor': resul[_0x262f14(0x1f8) + _0x262f14(0x212)],
                'qrcode': resul[_0x262f14(0x210) + _0x262f14(0x245)][_0x262f14(0x1f8) + _0x262f14(0x22a)][_0x262f14(0x23a)],
                'link': resul[_0x262f14(0x210) + _0x262f14(0x245)][_0x262f14(0x1f8) + _0x262f14(0x22a)][_0x262f14(0x21a)],
                'hora': m102,
                'expira': _0x450f9d[_0x262f14(0x24d)](Date[_0x262f14(0x20b)](), expira)
            };
            continue;
        }
        break;
    }
}
async function verificar(_0xd8a215) {
    const _0x3b2b8e = _0x679046, _0x2bad75 = {
            'QppvG': function (_0x23b83a, _0x51d673) {
                return _0x23b83a(_0x51d673);
            },
            'LHMmw': _0x3b2b8e(0x1fc),
            'flOaJ': function (_0x5316c7, _0x37bd76) {
                return _0x5316c7 + _0x37bd76;
            },
            'KArcQ': _0x3b2b8e(0x22b) + _0x3b2b8e(0x25c) + _0x3b2b8e(0x228) + _0x3b2b8e(0x22f)
        };
    return dados = await _0x2bad75[_0x3b2b8e(0x247)](axios, {
        'method': _0x2bad75[_0x3b2b8e(0x219)],
        'url': _0x2bad75[_0x3b2b8e(0x1f7)](_0x2bad75[_0x3b2b8e(0x243)], _0xd8a215),
        'headers': { 'Authorization': _0x3b2b8e(0x1fd) + token }
    }), resul = dados[_0x3b2b8e(0x211)], obj = {
        'id': resul['id'],
        'status': resul[_0x3b2b8e(0x24e)]
    }, obj;
}
function _0x25ce() {
    const _0x4b18d1 = [
        'i.mercadop',
        'Bonfim',
        '\x20(Brasília',
        'sbBEI',
        '/etc/megah',
        'token_mp',
        'ync',
        '30qucbwp',
        'xJNyD',
        'split',
        'CVnxB',
        '2147862ELvkqP',
        'bot/data/p',
        'axios',
        '3003',
        'flOaJ',
        'transactio',
        'moPJD',
        '35oyKOkt',
        'writeFileS',
        'GET',
        'Bearer\x20',
        'Osasco',
        'fs-extra',
        '@gmail.com',
        'format',
        'qruHf',
        'log',
        'readFileSy',
        'estes.json',
        '332188RRTaYX',
        'fFmId',
        'HH:mm:ss.0',
        'POST',
        '10m',
        'now',
        'bot/data/t',
        'moment-tim',
        '/root/conf',
        'Ativando\x20e',
        'point_of_i',
        'data',
        'n_amount',
        '06233200',
        'n/json',
        '00z:00',
        'UYbgj',
        '\x20ás\x20',
        'AExat',
        'LHMmw',
        'ticket_url',
        '12387mjmJOz',
        'applicatio',
        'YHQUN',
        'fVnpR',
        'Av.\x20das\x20Na',
        'ções\x20Unida',
        'cancelled',
        'fxaWJ',
        'ezone',
        'LISBOA',
        'exports',
        'stringify',
        'VCYnS',
        'ago.com/v1',
        '0874654777',
        'n_data',
        'https://ap',
        'agos.json',
        'aslMR',
        'America/Sa',
        '/payments/',
        'add',
        '20YCBUod',
        'push',
        'teFQw',
        'LUlfB',
        'YSHNf',
        'TjtQU',
        'XcFMv',
        'edidos.jso',
        '5896759pFUJts',
        'qr_code',
        'DD/MM/yyyy',
        '/payments',
        'uHDGP',
        'SVxrS',
        '895880vNiiau',
        '9XGEFka',
        'HH:mm',
        'o_Paulo',
        'KArcQ',
        '1587096nUSAbo',
        'nteraction',
        'PUT',
        'QppvG',
        'VGeZb',
        'parse',
        'JAQUELINE',
        'pix',
        'Yyqnx',
        'adfXc',
        'status',
        '106696qYCNgQ',
        '6|4|7|2|8|',
        'yyyy-MM-DD',
        'Login\x20SSH',
        'FfALe',
        'CPF',
        'valorLogin',
        'wwFdm',
        'desgosto01',
        'HZWpq',
        '3|0|5|1',
        'xlwEf',
        'EIsOa'
    ];
    _0x25ce = function () {
        return _0x4b18d1;
    };
    return _0x25ce();
}
async function cancelar(_0x526efb) {
    const _0x4597d8 = _0x679046, _0xee0dda = {
            'TjtQU': function (_0x2f6978, _0x450e4e) {
                return _0x2f6978(_0x450e4e);
            },
            'YHQUN': _0x4597d8(0x246),
            'fFmId': function (_0x5ef96d, _0x5d33cd) {
                return _0x5ef96d + _0x5d33cd;
            },
            'wwFdm': _0x4597d8(0x22b) + _0x4597d8(0x25c) + _0x4597d8(0x228) + _0x4597d8(0x22f),
            'LUlfB': _0x4597d8(0x221)
        };
    return dados = await _0xee0dda[_0x4597d8(0x236)](axios, {
        'method': _0xee0dda[_0x4597d8(0x21d)],
        'url': _0xee0dda[_0x4597d8(0x207)](_0xee0dda[_0x4597d8(0x256)], _0x526efb),
        'data': { 'status': _0xee0dda[_0x4597d8(0x234)] },
        'headers': { 'Authorization': _0x4597d8(0x1fd) + token }
    }), resul = dados[_0x4597d8(0x211)], obj = {
        'id': resul['id'],
        'status': resul[_0x4597d8(0x24e)]
    }, obj;
}
module[_0x679046(0x225)] = {
    'delay': delay,
    'gerar': gerar,
    'verificar': verificar,
    'cancelar': cancelar
};