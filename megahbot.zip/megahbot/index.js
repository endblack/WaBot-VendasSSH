const {default: makeWASocket, delay, DisconnectReason, BufferJSON, useMultiFileAuthState } = require('@whiskeysockets/baileys')
const { Boom } = require('@hapi/boom')
const P = require("pino")
const { exec } = require('child_process')
const express = require("express")
const {gerar} = require("/etc/megahbot/src/gerar")
const app = express()
const moment = require("moment-timezone")
const fs = require("fs-extra")
const ms = require("ms")
const pms = require("parse-ms")
const { config } = require("/root/config")

time = ms(`1d`)
expiraZ = ms("31d")
d31 = moment.tz("America/Sao_Paulo").add(31,"d").format("DD/MM/yyyy")

app.listen(7000)
dono = [`${config.dono}@s.whatsapp.net`]
dono2 = `${config.dono}`

path = {
  p: "/etc/megahbot/data/pedidos.json",
  t: "/etc/megahbot/data/testes.json",
  pa: "/etc/megahbot/data/pagos.json"
}
//##### FUNÇÕES ######
async function checkUser(user) {
  pedidos = await JSON.parse(fs.readFileSync(path.p))
  for (var i = 0; i < pedidos.length; i++) {
    if (pedidos[i].user == user) return true
  }
  return false
}
async function checkTeste(user) {
  testes = await JSON.parse(fs.readFileSync(path.t))
  testes = await JSON.parse(fs.readFileSync(path.t))
  for (var i = 0; i < testes.length; i++) {
    if(testes[i].user == user) {
      if(Date.now() < testes[i].expira) {
        return true
      }
      if(Date.now() > testes[i].expira) {
        testes.splice(i,1)
        await fs.writeFileSync(path.t, JSON.stringify(testes))
        return false
      }
    }
  }
  return false
}
async function gravarTeste(user) {
  testes = await JSON.parse(fs.readFileSync(path.t))
  obj = {
    user: user,
    expira: Date.now()+time
  }
  testes.push(obj)
  await fs.writeFileSync(path.t, JSON.stringify(testes))
}
function ale() {
  i = 10000000000000000000
  return Math.floor(Math.random()*(i+1))
}
function repla(num) {
  i = num.indexOf("@")
  return num.slice(0,i)
}
async function chackPago(user) {
  pagos = await JSON.parse(fs.readFileSync(path.pa))
  for (var i = 0; i < pagos.length; i++) {
    if(pagos[i].user == user) {
      return true
    }
  }
  return false
}
async function checkLogins(user) {
  pagos = await JSON.parse(fs.readFileSync(path.pa))
  for (var i = 0; i < pagos.length; i++) {
    if(pagos[i].user == user) {
      logins = pagos[i].logins
      quanti = logins.length
      tesk = `Você tem *0${quanti}* login's Premium`
      for (var i = 0; i < logins.length; i++) {
        usu = logins[i].usuario
        sen = logins[i].senha
        limi = logins[i].limite
        vali = logins[i].Validade
        exp = pms(logins[i].expira-Date.now())
        exp = exp.days+" dias"
        exps = logins[i].expira
        if (Date.now() > exp) exp = "venceu"
        tesk = tesk+`\n\n*👤Usuário:* ${usu}\n*🔐Senha:* ${sen}\n*📲Limite:* ${limi}\n*⌛Validade:* ${vali} (${exp})\n\n===============`
      }
      return tesk
    }
  }
  return "Você não tem logins Premium"
}
//###################

async function connectToWhatsApp () {
    const { state, saveCreds } = await useMultiFileAuthState('login')
    const client = await makeWASocket({
        logger: P({ level: 'silent' }),
        printQRInTerminal: true,
        auth: state,
        keepAliveIntervalMs: 16000
    })
    client.ev.on('creds.update', saveCreds)
    
    client.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update
        //console.log(connection)
        if(connection == "connecting") {
          console.log("Conectando...")
        }
        if(connection === 'close') {
            //const shouldReconnect = (lastDisconnect.error in Boom).output.statusCode !== DisconnectReason.loggedOut
            console.log(DisconnectReason)
            console.log('Conexão fechada por: ', lastDisconnect, ', Reconectando...')
            // reconnect if not logged out
                await delay(3000)
                connectToWhatsApp()
        } else if(connection === 'open') {
            console.log('CONECTADO COM SUCESSO!')
            await delay(5000)
            const { checkStatus } = require("/etc/megahbot/src/veri")
        }
    })
    console.log("Abrindo navegador...")
    //#### WEB SERVER #######
    app.get("/pago", async (req, res) => {
      var { user } = req.query
      var { id } = req.query
      console.log(user, id)
      if(!user.includes("@s")) return res.json({msg: "bad request"})
      pagtoC = await client.sendMessage(user, {text: "Pagamento id: "+id+" confirmado!"}).catch(e => {
        console.log("deu erro")
        console.log(e)
        res.json({msg: "error"})
      })
      usuarioV = "user"+`${ale()}`.slice(0,4)
      senha = `${ale()}`.slice(0,4)
      exec(`sh /etc/megahbot/src/user.sh ${usuarioV} ${senha}`)
      await client.sendMessage(user, {text: `*•Informações do login•*\n\n*👤Usuário:* ${usuarioV}\n*🔐Senha:* ${senha}\n*📲Limite:* 1\n*⌛Validade:* ${d31} (31 dias)`}, {quoted: pagtoC}).catch(e => {
        console.log("deu erro")
        console.log(e)
        res.json({msg: "error"})
      })
      console.log(user)
      if(await chackPago(user)) {
        pagos = await JSON.parse(fs.readFileSync(path.pa))
        obj = {
          usuario: usuarioV,
          senha: senha,
          limite: 1,
          Validade: d31,
          expira: Date.now()+expiraZ
        }
        for (var i = 0; i < pagos.length; i++) {
          if(pagos[i].user == user) {
            pagos[i].logins.push(obj)
            await fs.writeFileSync(path.pa, JSON.stringify(pagos))
          }
        }
      } else {
        pagos = await JSON.parse(fs.readFileSync(path.pa))
        obj = {
          user: user,
          logins: [{
            usuario: usuarioV,
            senha: senha,
            limite: 1,
            Validade: d31,
            expira: Date.now()+expiraZ
          }]
        }
        pagos.push(obj)
        await fs.writeFileSync(path.pa, JSON.stringify(pagos))
      }
        res.json({msg: "sucess"})
    })
    app.get("/cancel", async (req, res) => {
      var { user } = req.query
      var { id } = req.query
      if(!user.includes("@s")) return res.json({msg: "bad request"})
      await client.sendMessage(user, {text: "*Qrcode expirado:*\n\n🆔Id: "+id}).catch(e => console.log(e))
    })
    //######
    //###### RECEBENDO MENSAGENS #####
    client.ev.on('messages.upsert', async m => {
        //console.log(m.messages)
        client.sendPresenceUpdate('available')
        message = m.messages[0]
        msg = message.message
        //console.log(message)
        key = message.key
        fromMe = key.fromMe
        if (fromMe) return
        from = key.remoteJid
        isGroup = from.includes("@g.us")
        jid = isGroup ? key.participant : from
        name = message.pushName
        body = msg.conversation ? msg.conversation : msg.extendedTextMessage ? msg.extendedTextMessage.text : "midia"
        body = body.toLowerCase()
        //###### FUNÇÕES BÁSICAS #######
        async function reply(text) {
          await client.sendMessage(from, {text: text}, {quoted: message})
        }
        async function reply2(pv, text) {
          await client.sendMessage(pv, {text: text})
        }
        
        if(!isGroup) console.log(`\n\nMensagem no privado de ${repla(jid)} (${name}):\n\nMensagem: ${body}\n\n############`)
        //if(isGroup) console.log(`############\n\nMensagem em grupo de ${repla(jid)} (${name}):\n\nMensagem: ${body}\n\n############`)
        
        client.sendPresenceUpdate('available', jid)
        client.readMessages([key])
        //###### ENTRADAS ########
        if (isGroup) return
        switch (body) {
          case "1":
          case "01":
            if(await checkTeste(jid)) return reply("Você já gerou um teste hoje, só poderá gerar outro em 24h")
            usuarioT = "teste"+`${ale()}`.slice(0,4)
            exec(`sh /etc/megahbot/src/teste.sh ${usuarioT} ${config.tempo_teste*60}`)
            tesy = await client.sendMessage(jid, {text: `*•Informações do login•*\n\n*👤Usuário:* ${usuarioT}\n*🔐Senha:* 1234\n*📲Limite:* 1\n*⌛Validade:* ${config.tempo_teste}h`}, {quoted: message})
            await client.sendMessage(jid, {text: "Aproveite bem seu teste 🔥"}, {quoted: tesy})
            await delay(500)
            gravarTeste(jid)
            // code
            break;
          case "2":
          case "02":
          placa2 = `*•Informações do produto•*

*🏷️Valor:* R$${config.valorLogin}
*📲Limite:* 1
*⌛Validade:* 30 dias

📌Sempre faça um teste antes de comprar!
Para obter o app, digite o comando abaixo ⤵️

/app

Deseja comprar? *Sim* ou *Não*`
reply(placa2)
            break;
          case "sim":
          case "si":
          case "ss":
          case "s":
            if (await checkUser(jid)) return reply("Você tem um pedido em andamento, pague ou espere ele expirar para fazer outro pedido")
            reply("Gerando Qrcode...")
            dados = await gerar(jid, message)
            placa = `*Informações do Qrcode:*

🆔Id: ${dados.id}
🏷️Valor: R$${dados.valor}
⌛Expira em: 10 min\nàs *${dados.hora}* _(horário de Brasília)_

📌Seu login será enviado assim que seu pagamento for identificado, pode demorar cerca de 1 minuto.

_Qrcode copia e cola logo abaixo_ ⤵️`
            //console.log(dados)
            mcode = await client.sendMessage(dados.user, {text: placa}, {quoted: dados.msgkey})
            await client.sendMessage(dados.user, {text: dados.qrcode}, {quoted: mcode})
            break;
          case "nao":
          case "não":
          case "no":
          case "n":
          case "nn":
          reply("Tudo certo! Se precisar é só me chamar! 😉")
            break;
          case "5":
          case "05":
            await client.sendMessage(jid, {text: `*☎️Suporte*\n\n🆔@${dono2}`, mentions: dono}, {quoted: message})
            break;
          case "3":
          case "03":
            gama = await checkLogins(jid)
            await client.sendMessage(jid, {text: gama}, {quoted: message})
            //reply(gama)
            break;
          case "/app":
          case "app":
          case "4":
          case "04":
          reply("Aguarde...")
          await client.sendMessage(jid, {text: `Faça o download do app através do link abaixo⤵️\n\n${config.linkApp}\n\n📌Caso o link não esteja clicável, salve meu contato que ele ficará`}, {quoted: message})
            break;
                    
          default:
          boasvindas = `Olá ${name} 😃, Bem vindo(a) a *${config.nomeLoja}!* Fique a vontade para escolher alguma das opções abaixo:\n\n*[01]* Gerar teste ⌛\n*[02]* Comprar login 30 dias 📆\n*[03]* Verificar Logins 🔍\n*[04]* Aplicativo 📱\n*[05]* Suporte 👤`
          reply(boasvindas)
            // code
        } //switch
    })
}
// run in main file
connectToWhatsApp()