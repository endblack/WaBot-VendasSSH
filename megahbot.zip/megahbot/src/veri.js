const axios = require("axios")
const fs = require("fs-extra")
const {gerar, verificar, cancelar} = require("/etc/megahbot/gerar")
const {delay} = require('@whiskeysockets/baileys')

path = {
  p: "/etc/megahbot/data/pedidos.json",
  t: "/etc/megahbot/data/testes.json",
  pa: "/etc/megahbot/data/pagos.json"
}

console.log("Iniciando verificação de pagamentos...")
async function checkStatus() {
  pedidos = await JSON.parse(fs.readFileSync(path.p))
  //console.log("Total de pedidos: "+pedidos.length)
  
  for (var i = 0; i < pedidos.length; i++) {
    pedidos = await JSON.parse(fs.readFileSync(path.p))
    //console.log(pedidos[i])
    status = await verificar(pedidos[i].id)
    //console.log(status)
    if (status.status == "approved") {
      console.log("Enviando login id "+status.id)
      env = await axios("http://localhost:7000/pago?user="+pedidos[i].user+"&id="+pedidos[i].id)
      console.log(env.data)
      if (env.data.msg == "sucess") {
        pedidos.splice(i,1)
        await fs.writeFileSync(path.p, JSON.stringify(pedidos))
      } else {console.log("Erro ao enviar id "+status.id)}
    }
    /*if (status.status == "cancelled") {
      console.log("Removendo id "+status.id)
      axios("http://localhost:7000/cancel?user="+pedidos[i].user+"&id="+pedidos[i].id)
      pedidos.splice(i,1)
      await fs.writeFileSync(path.p, JSON.stringify(pedidos))
      console.log("Removido com sucesso! "+status.id)
    }*/
    if (pedidos.length > 0 && Date.now() > pedidos[i].expira || status.status == "cancelled") {
      console.log("Expirou, removendo id: "+pedidos[i].id)
      axios("http://localhost:7000/cancel?user="+pedidos[i].user+"&id="+pedidos[i].id)
      pedidos.splice(i,1)
      await fs.writeFileSync(path.p, JSON.stringify(pedidos))
      console.log("Removido com sucesso! "+status.id)
    }
    await delay(500)
  }
    //console.log("Espere 10 segundos...")
    await delay(10*1000)
    checkStatus()
    //console.log("Recomeçando")
}
checkStatus()

module.exports = {
  checkStatus
}